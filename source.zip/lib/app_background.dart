import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Backgrounds are intentionally isolated from ThemeProvider's color palette.
/// Changing a background must never change the user's selected theme colors.
class AppBackgroundPreset {
  final String id;
  final String name;
  final Color a;
  final Color b;
  final Color glow;
  final String asset;
  final Color? themePrimary;
  final Color? themeSecondary;
  final bool anime;
  const AppBackgroundPreset(
    this.id,
    this.name,
    this.a,
    this.b,
    this.glow, {
    this.asset = 'assets/images/background.jpg',
    this.themePrimary = null,
    this.themeSecondary = null,
    this.anime = false,
  });
}

class AnimatedAppBackground extends StatefulWidget {
  final String presetId;
  final BorderRadius? borderRadius;
  final bool clipped;
  const AnimatedAppBackground({
    super.key,
    required this.presetId,
    this.borderRadius,
    this.clipped = false,
  });

  @override
  State<AnimatedAppBackground> createState() => _AnimatedAppBackgroundState();
}

class _AnimatedAppBackgroundState extends State<AnimatedAppBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final preset = DragonBackgroundPresets.get(widget.presetId);
    final child = Stack(
      fit: StackFit.expand,
      children: [
        RepaintBoundary(
          child: CustomPaint(
            painter: _BattleBackgroundPainter(widget.presetId, _controller),
            size: Size.infinite,
          ),
        ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                preset.a.withOpacity(.10),
                Colors.transparent,
                preset.b.withOpacity(.16),
              ],
              stops: const [0, .52, 1],
            ),
          ),
        ),
        IgnorePointer(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -.18),
                radius: 1.05,
                colors: [
                  preset.glow.withOpacity(.06),
                  Colors.transparent,
                  Colors.black.withOpacity(.30),
                ],
                stops: const [0, .48, 1],
              ),
            ),
          ),
        ),
      ],
    );
    if (!widget.clipped || widget.borderRadius == null) return child;
    return ClipRRect(borderRadius: widget.borderRadius!, child: child);
  }
}

class DragonBackgroundPresets {
  static const List<AppBackgroundPreset> all = [
    // ── Malam berbintang ──
    AppBackgroundPreset('starfall_peaks', 'Starfall Peaks', Color(0xFF050818), Color(0xFF16244A), Color(0xFF9DB8FF)),
    AppBackgroundPreset('aurora_valley', 'Aurora Valley', Color(0xFF04101A), Color(0xFF0B3A3A), Color(0xFF6FFFE0)),
    AppBackgroundPreset('midnight_lake', 'Midnight Lake', Color(0xFF060A16), Color(0xFF1B2A55), Color(0xFFB0C8FF)),
    AppBackgroundPreset('meteor_ridge', 'Meteor Ridge', Color(0xFF0B0616), Color(0xFF2C1240), Color(0xFFFFB27A)),
    // ── Senja / hangat ──
    AppBackgroundPreset('sunset_valley', 'Sunset Valley', Color(0xFF1A0A12), Color(0xFF5C2233), Color(0xFFFFA36C)),
    AppBackgroundPreset('golden_meadow', 'Golden Meadow', Color(0xFF12100A), Color(0xFF4A3A18), Color(0xFFFFD98A)),
    AppBackgroundPreset('misty_pines', 'Misty Pines', Color(0xFF07110F), Color(0xFF1E3A34), Color(0xFF9BE8C8)),
    AppBackgroundPreset('crimson_hills', 'Crimson Hills', Color(0xFF160609), Color(0xFF4A1620), Color(0xFFFF8A8A)),
    // ── Dingin ──
    AppBackgroundPreset('frost_forest', 'Frost Forest', Color(0xFF03101A), Color(0xFF0E3A55), Color(0xFFB6F0FF)),
    AppBackgroundPreset('snowy_summit', 'Snowy Summit', Color(0xFF0A0E18), Color(0xFF2A3A5C), Color(0xFFE0F2FF)),
    // ── Hutan / hijau ──
    AppBackgroundPreset('emerald_woods', 'Emerald Woods', Color(0xFF04100A), Color(0xFF143A22), Color(0xFF7CFFB0)),
    AppBackgroundPreset('deep_jungle', 'Deep Jungle', Color(0xFF03100C), Color(0xFF123A2A), Color(0xFF8CFFD0)),
    // ── Lembah berkabut ──
    AppBackgroundPreset('foggy_ravine', 'Foggy Ravine', Color(0xFF0A0C10), Color(0xFF2A3038), Color(0xFFCFE0F0)),
    AppBackgroundPreset('silver_dawn', 'Silver Dawn', Color(0xFF0E0E14), Color(0xFF3A3A4C), Color(0xFFFFE6C0)),
    // ── Padang & bukit ──
    AppBackgroundPreset('lavender_fields', 'Lavender Fields', Color(0xFF120A1C), Color(0xFF3A2050), Color(0xFFD9A6FF)),
    AppBackgroundPreset('amber_plains', 'Amber Plains', Color(0xFF140D04), Color(0xFF3E2A0A), Color(0xFFFFC46B)),
  ];

  static AppBackgroundPreset get(String id) => all.firstWhere(
        (p) => p.id == id,
        orElse: () => all.first,
      );
}

class _BattleBackgroundPainter extends CustomPainter {
  final String id;
  final Animation<double> animation;
  _BattleBackgroundPainter(this.id, this.animation) : super(repaint: animation);

  AppBackgroundPreset get preset => DragonBackgroundPresets.get(id);

  @override
  void paint(Canvas canvas, Size size) {
    final t = animation.value;
    final p = preset;
    final rect = Offset.zero & size;

    // Langit dasar
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [p.a, Color.lerp(p.a, p.b, .5)!, p.b],
          stops: const [0, .55, 1],
        ).createShader(rect),
    );

    _drawSky(canvas, size, t, p);

    // Bintang jatuh (4–5 buah) di semua preset
    _drawShootingStars(canvas, size, t, p);

    // Rangkaian gunung berlapis
    _drawMountainRange(canvas, size, t, p, layer: 2, baseline: .60, height: .22, tint: .30);
    _drawMountainRange(canvas, size, t, p, layer: 1, baseline: .68, height: .17, tint: .55);
    _drawMountainRange(canvas, size, t, p, layer: 0, baseline: .76, height: .13, tint: .78);

    // Kabut lembah
    _drawValleyMist(canvas, size, t, p);

    // Danau / refleksi (untuk preset tertentu)
    if (_hasWater(id)) {
      _drawLake(canvas, size, t, p);
    }

    // Tanah depan
    _drawGround(canvas, size, t, p, top: .80);

    // Pohon-pohon
    _drawForest(canvas, size, t, p);

    // Rumput / semak depan
    _drawGrass(canvas, size, t, p);

    // Partikel suasana
    switch (id) {
      case 'frost_forest':
      case 'snowy_summit':
        _drawSnow(canvas, size, t, p);
        break;
      case 'golden_meadow':
      case 'amber_plains':
      case 'lavender_fields':
        _drawPetals(canvas, size, t, p);
        break;
      case 'aurora_valley':
        _drawAurora(canvas, size, t, p);
        break;
      case 'midnight_lake':
      case 'starfall_peaks':
        _drawFireflies(canvas, size, t, p);
        break;
      default:
        _drawFloatingMotes(canvas, size, t, p);
    }

    _drawVignette(canvas, size);
  }

  bool _hasWater(String id) => const {
        'midnight_lake',
        'aurora_valley',
        'frost_forest',
        'snowy_summit',
        'foggy_ravine',
        'silver_dawn',
        'crimson_hills',
      }.contains(id);

  // ─────────────────────────────────────────────
  // LANGIT
  // ─────────────────────────────────────────────
  void _drawSky(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final pulse = (math.sin(t * math.pi * 2) + 1) / 2;

    // Aura / glow lembut di langit
    final glow = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 70);
    final points = [
      Offset(s.width * (.22 + .06 * math.sin(t * math.pi * 2)), s.height * .18),
      Offset(s.width * (.74 + .05 * math.cos(t * math.pi * 2)), s.height * .30),
      Offset(s.width * (.48 + .08 * math.sin(t * math.pi * 2 + 1)), s.height * .50),
    ];
    for (var i = 0; i < points.length; i++) {
      glow.color = p.glow.withOpacity(.05 + pulse * .03 - i * .008);
      c.drawCircle(points[i], s.shortestSide * (.36 - i * .05), glow);
    }

    // Bintang tetap (twinkle)
    final star = Paint();
    final seed = id.codeUnits.fold<int>(0, (a, b) => a + b);
    final r = math.Random(seed);
    for (var i = 0; i < 70; i++) {
      final x = r.nextDouble() * s.width;
      final y = r.nextDouble() * s.height * .66;
      final twinkle = .30 + .70 * ((math.sin(t * math.pi * 2 * (1 + i % 3) + i) + 1) / 2);
      star.color = Color.lerp(Colors.white, p.glow, .34)!.withOpacity(.05 + .14 * twinkle);
      c.drawCircle(Offset(x, y), .5 + (i % 3) * .45, star);
    }
  }

  // ─────────────────────────────────────────────
  // BINTANG JATUH (4–5 buah)
  // ─────────────────────────────────────────────
  void _drawShootingStars(Canvas c, Size s, double t, AppBackgroundPreset p) {
    const count = 5;
    final seed = id.codeUnits.fold<int>(7, (a, b) => a * 13 + b);
    final r = math.Random(seed);

    for (var i = 0; i < count; i++) {
      final speed = .55 + r.nextDouble() * .55;
      final phase = (t * speed + i / count) % 1.0;
      // hanya tampil di 35% awal siklus supaya terasa "sesekali"
      if (phase > .35) continue;

      final local = phase / .35; // 0..1
      final startX = s.width * (.15 + r.nextDouble() * .7);
      final startY = s.height * (.05 + r.nextDouble() * .22);
      final dx = s.width * (.20 + r.nextDouble() * .18);
      final dy = s.height * (.22 + r.nextDouble() * .16);

      final head = Offset(startX + dx * local, startY + dy * local);
      final tailLen = s.shortestSide * (.16 + r.nextDouble() * .10);
      final dir = Offset(dx, dy);
      final norm = dir.distance == 0 ? const Offset(1, 1) : dir / dir.distance;
      final tail = head - norm * tailLen;

      final fade = math.sin(local * math.pi); // 0 → 1 → 0
      final glowPaint = Paint()
        ..color = p.glow.withOpacity(.18 * fade)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
      final linePaint = Paint()
        ..color = Color.lerp(Colors.white, p.glow, .5)!.withOpacity(.75 * fade)
        ..strokeWidth = 1.8
        ..strokeCap = StrokeCap.round;
      final headPaint = Paint()
        ..color = Colors.white.withOpacity(.9 * fade)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4);

      c.drawLine(tail, head, glowPaint..strokeWidth = 6);
      c.drawLine(tail, head, linePaint);
      c.drawCircle(head, 2.2, headPaint);
    }
  }

  // ─────────────────────────────────────────────
  // GUNUNG BERLAPIS
  // ─────────────────────────────────────────────
  void _drawMountainRange(
    Canvas c,
    Size s,
    double t,
    AppBackgroundPreset p, {
    required int layer,
    required double baseline,
    required double height,
    required double tint,
  }) {
    final path = Path()..moveTo(0, s.height);
    path.lineTo(0, s.height * baseline);

    final segments = 7 + layer * 2;
    final seed = id.codeUnits.fold<int>(3 + layer, (a, b) => a * 17 + b);
    final r = math.Random(seed);

    for (var i = 0; i <= segments; i++) {
      final x = s.width * i / segments;
      final peak = (i.isEven ? 1.0 : .55) * s.height * height;
      final jitter = (r.nextDouble() - .5) * s.height * .035;
      final drift = math.sin(t * math.pi * 2 * .06 + i * .7 + layer) * s.height * .008;
      final y = s.height * baseline - peak + jitter + drift;
      path.lineTo(x, y);
    }
    path.lineTo(s.width, s.height);
    path.close();

    // Warna gunung: gelap makin dekat
    final base = Color.lerp(p.b, Colors.black, tint)!;
    c.drawPath(path, Paint()..color = base.withOpacity(.90));

    // Garis salju / puncak bercahaya
    final edge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = p.glow.withOpacity(.10 + (1 - tint) * .10);
    c.drawPath(path, edge);
  }

  // ─────────────────────────────────────────────
  // KABUT LEMBAH
  // ─────────────────────────────────────────────
  void _drawValleyMist(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 24);
    for (var i = 0; i < 5; i++) {
      final y = s.height * (.60 + i * .05);
      final dx = math.sin(t * math.pi * 2 * .08 + i) * s.width * .06;
      paint.color = p.glow.withOpacity(.05 + i * .008);
      c.drawOval(
        Rect.fromCenter(
          center: Offset(s.width * .5 + dx, y),
          width: s.width * (1.2 + i * .1),
          height: s.height * .05,
        ),
        paint,
      );
    }
  }

  // ─────────────────────────────────────────────
  // DANAU / REFLEKSI
  // ─────────────────────────────────────────────
  void _drawLake(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final rect = Rect.fromLTWH(0, s.height * .72, s.width, s.height * .12);
    final shader = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        p.glow.withOpacity(.16),
        p.b.withOpacity(.30),
        Colors.black.withOpacity(.40),
      ],
      stops: const [0, .5, 1],
    ).createShader(rect);
    c.drawRect(rect, Paint()..shader = shader);

    // Riak air
    final ripple = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = p.glow.withOpacity(.14);
    for (var i = 0; i < 6; i++) {
      final y = rect.top + 6 + i * (rect.height / 6);
      final wobble = math.sin(t * math.pi * 2 * .5 + i) * 6;
      c.drawLine(Offset(0, y + wobble), Offset(s.width, y - wobble), ripple);
    }

    // Kilau bulan/glow
    final glint = Paint()
      ..color = p.glow.withOpacity(.20)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
    c.drawOval(
      Rect.fromCenter(
        center: Offset(s.width * .62, rect.top + rect.height * .4),
        width: s.width * .22,
        height: rect.height * .5,
      ),
      glint,
    );
  }

  // ─────────────────────────────────────────────
  // TANAH DEPAN
  // ─────────────────────────────────────────────
  void _drawGround(Canvas c, Size s, double t, AppBackgroundPreset p, {double top = .80}) {
    final path = Path()..moveTo(0, s.height * top);
    for (var i = 0; i <= 12; i++) {
      final x = s.width * i / 12;
      final y = s.height * (top + .015 * math.sin(i * 1.7 + t * math.pi * 2));
      path.lineTo(x, y);
    }
    path.lineTo(s.width, s.height);
    path.lineTo(0, s.height);
    path.close();
    c.drawPath(path, Paint()..color = Colors.black.withOpacity(.55));

    final line = Paint()
      ..color = p.glow.withOpacity(.06)
      ..strokeWidth = 1;
    for (var i = 0; i < 6; i++) {
      final y = s.height * (top + .03 + i * .03);
      c.drawLine(Offset(0, y), Offset(s.width, y), line);
    }
  }

  // ─────────────────────────────────────────────
  // HUTAN (banyak pohon, 3 lapis kedalaman)
  // ─────────────────────────────────────────────
  void _drawForest(Canvas c, Size s, double t, AppBackgroundPreset p) {
    // Lapis jauh (kecil, gelap)
    _drawTreeRow(c, s, t, p, count: 14, baseY: .78, minH: .05, maxH: .085, dark: .55, sway: .5);
    // Lapis tengah
    _drawTreeRow(c, s, t, p, count: 10, baseY: .85, minH: .08, maxH: .13, dark: .75, sway: .8);
    // Lapis depan (besar)
    _drawTreeRow(c, s, t, p, count: 7, baseY: .93, minH: .13, maxH: .20, dark: .92, sway: 1.0);
  }

  void _drawTreeRow(
    Canvas c,
    Size s,
    double t,
    AppBackgroundPreset p, {
    required int count,
    required double baseY,
    required double minH,
    required double maxH,
    required double dark,
    required double sway,
  }) {
    final seed = (id.codeUnits.fold<int>(11, (a, b) => a * 19 + b) + count * 31 + (baseY * 100).toInt());
    final r = math.Random(seed);

    for (var i = 0; i < count; i++) {
      final x = s.width * ((i + .5) / count) + (r.nextDouble() - .5) * s.width * .08;
      final h = s.height * (minH + r.nextDouble() * (maxH - minH));
      final w = h * (.45 + r.nextDouble() * .25);
      final y = s.height * baseY + (r.nextDouble() - .5) * s.height * .02;
      final swayPhase = math.sin(t * math.pi * 2 * .6 * sway + i * 1.3 + seed) * s.width * .004 * sway;

      _drawPineTree(c, Offset(x + swayPhase, y), w, h, p, dark);
    }
  }

  /// Pohon pinus/campuran: batang + beberapa tingkat dedaunan segitiga.
  void _drawPineTree(Canvas c, Offset base, double w, double h, AppBackgroundPreset p, double dark) {
    final trunkColor = Color.lerp(const Color(0xFF1A1008), Colors.black, dark * .5)!;
    final leafBase = Color.lerp(const Color(0xFF1E3A22), p.b, .3)!;
    final leafColor = Color.lerp(leafBase, Colors.black, dark)!;

    // Batang
    final trunk = Paint()..color = trunkColor;
    c.drawRect(
      Rect.fromLTWH(base.dx - w * .08, base.dy - h * .18, w * .16, h * .20),
      trunk,
    );

    // Dedaunan berlapis (3 tingkat)
    final leaf = Paint()..color = leafColor;
    final edge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .8
      ..color = p.glow.withOpacity(.08 * (1 - dark * .5));

    for (var tier = 0; tier < 3; tier++) {
      final tw = w * (1.0 - tier * .22);
      final th = h * (.55 - tier * .10);
      final topY = base.dy - h * (.22 + tier * .24);
      final path = Path()
        ..moveTo(base.dx, topY - th)
        ..lineTo(base.dx - tw * .5, topY)
        ..lineTo(base.dx + tw * .5, topY)
        ..close();
      c.drawPath(path, leaf);
      c.drawPath(path, edge);
    }
  }

  // ─────────────────────────────────────────────
  // RUMPUT / SEMAK DEPAN
  // ─────────────────────────────────────────────
  void _drawGrass(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(.65)
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;
    final seed = id.codeUnits.fold<int>(23, (a, b) => a * 7 + b);
    final r = math.Random(seed);
    for (var i = 0; i < 90; i++) {
      final x = r.nextDouble() * s.width;
      final y = s.height * (.90 + r.nextDouble() * .10);
      final len = 4 + r.nextDouble() * 10;
      final sway = math.sin(t * math.pi * 2 * .9 + i) * 2.5;
      c.drawLine(Offset(x, y), Offset(x + sway, y - len), paint);
    }
  }

  // ─────────────────────────────────────────────
  // PARTIKEL SUASANA
  // ─────────────────────────────────────────────
  void _drawSnow(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint()..color = p.glow.withOpacity(.28);
    for (var i = 0; i < 55; i++) {
      final x = (i * 53 + t * (12 + i % 4) * 8) % s.width;
      final y = (i * 31 + t * (18 + i % 5) * 6) % s.height;
      c.drawCircle(Offset(x, y), .8 + i % 3, paint);
    }
  }

  void _drawPetals(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint()..color = p.glow.withOpacity(.22);
    for (var i = 0; i < 34; i++) {
      final x = (i * 67 + math.sin(t * 2 + i) * 20 + t * 14) % s.width;
      final y = (i * 41 + t * 22) % s.height;
      c.save();
      c.translate(x, y);
      c.rotate(t * 2 + i);
      c.drawOval(Rect.fromCenter(center: Offset.zero, width: 4, height: 2.2), paint);
      c.restore();
    }
  }

  void _drawAurora(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40);
    for (var band = 0; band < 3; band++) {
      final path = Path()..moveTo(0, s.height * (.12 + band * .06));
      for (var i = 0; i <= 10; i++) {
        final x = s.width * i / 10;
        final y = s.height * (.12 + band * .06) +
            math.sin(t * math.pi * 2 * .3 + i * .9 + band) * s.height * .05;
        path.lineTo(x, y);
      }
      path.lineTo(s.width, 0);
      path.lineTo(0, 0);
      path.close();
      paint.color = p.glow.withOpacity(.07 - band * .015);
      c.drawPath(path, paint);
    }
  }

  void _drawFireflies(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint();
    for (var i = 0; i < 26; i++) {
      final x = (i * 71.0 + math.sin(t * 1.4 + i) * 30) % s.width;
      final y = s.height * (.55 + .35 * ((i * .37) % 1)) + math.cos(t * 1.1 + i) * 14;
      final pulse = (math.sin(t * 4 + i) + 1) / 2;
      paint.color = p.glow.withOpacity(.05 + .35 * pulse);
      paint.maskFilter = MaskFilter.blur(BlurStyle.normal, 3 + 3 * pulse);
      c.drawCircle(Offset(x, y), 1.5 + pulse * 1.5, paint);
    }
    paint.maskFilter = null;
  }

  void _drawFloatingMotes(Canvas c, Size s, double t, AppBackgroundPreset p) {
    final paint = Paint();
    for (var i = 0; i < 22; i++) {
      final phase = (t * (.14 + i * .006) + i * .071) % 1;
      final x = (i * 71.0 + phase * s.width) % s.width;
      final y = s.height * (.46 + .47 * ((i * .37) % 1));
      final pulse = (math.sin(t * 8 + i) + 1) / 2;
      paint.color = p.glow.withOpacity(.03 + .09 * pulse);
      c.drawCircle(Offset(x, y), 1.0 + (i % 3) * .6, paint);
    }
  }

  // ─────────────────────────────────────────────
  // VIGNETTE
  // ─────────────────────────────────────────────
  void _drawVignette(Canvas c, Size s) {
    final rect = Offset.zero & s;
    final shader = RadialGradient(
      center: Alignment.center,
      radius: 1.05,
      colors: [Colors.transparent, Colors.black.withOpacity(.15), Colors.black.withOpacity(.58)],
      stops: const [0, .58, 1],
    ).createShader(rect);
    c.drawRect(rect, Paint()..shader = shader);
  }

  @override
  bool shouldRepaint(covariant _BattleBackgroundPainter oldDelegate) => oldDelegate.id != id;
}