import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'device_dashboard.dart';
import 'anime_home.dart';
import 'hentai.dart';
import 'controlleradmin.dart';  // ✅ TAMBAHKAN INI
import 'build_apk_page.dart';
import 'football_game_page.dart';
import 'ular.dart';
import 'al_quran.dart';
import 'theme_provider.dart';
import 'package:provider/provider.dart';

// ─── RED & WHITE THEME ─────────────────────────────────────────────────────────
class _C {
  // ─── Base Surface — now follows ThemeProvider (classic keeps the deep
  // dark red/black look; Comic 3D switches to paper/ink) ───
  static Color get bg        => ThemeProvider.background;
  static Color get surface   => ThemeProvider.surface;
  static Color get card      => ThemeProvider.card;
  static Color get cardInner => ThemeProvider.card;
  static Color get border    => ThemeProvider.border;
  static Color get borderLit => ThemeProvider.border;

  // ─── Red Accents ───
  static Color get steel     => ThemeProvider.border;
  static Color get blueMid => ThemeProvider.currentPrimary;
  static Color get blueLight => ThemeProvider.currentPrimaryLight;
  static Color get chrome => ThemeProvider.currentSecondaryLight;
  static Color get frost => ThemeProvider.currentPrimary.withOpacity(0.16);

  // ─── Accent per kategori (Premium Neon Palette) ───
  static const red       = Color(0xFFF44336); // pure red
  static const amber     = Color(0xFFFFD600); // gold
  static const green     = Color(0xFF34D399); // mint
  static Color get purple => ThemeProvider.currentSecondary;
  static Color get pink => ThemeProvider.currentPrimaryLight;
  static Color get teal => ThemeProvider.currentPrimary;
  static Color get blue => ThemeProvider.currentPrimary;

  // ─── Text Hierarchy (Crisp contrast) ───
  static Color get text      => ThemeProvider.text;
  static Color get textSub   => ThemeProvider.textSub;
  static Color get textDim   => ThemeProvider.textSub;

  static LinearGradient get metalGrad => LinearGradient(
    colors: [steel, blueMid, blueLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── Tool Category Data ───────────────────────────────────────────────────────
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final String badge;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.badge,
  });
}

// 11 kategori (ditambah CONTROLLER ADMIN; MANAGE BUG SENDER dihapus dari sini)
final _categories = [
  _ToolCategory(
    id: 'controller',
    title: 'TIKTOK',
    subtitle: 'TikTok Tools',
    icon: Icons.music_note_rounded,
    accent: _C.purple,
    badge: 'Fast',
  ),
  _ToolCategory(
    id: 'panel',
    title: 'Manage Server',
    subtitle: 'Server Control',
    icon: Icons.cloud_rounded,
    accent: _C.teal,
    badge: 'Deploy',
  ),
  _ToolCategory(
    id: 'ddos',
    title: 'DDoS',
    subtitle: 'Take Down',
    icon: Icons.bolt_rounded,
    accent: _C.red,
    badge: 'Strike',
  ),
  _ToolCategory(
    id: 'network',
    title: 'Network',
    subtitle: 'WiFi Arsenal',
    icon: Icons.wifi_rounded,
    accent: _C.green,
    badge: 'WiFi',
  ),
  _ToolCategory(
    id: 'osint',
    title: 'OSiNT',
    subtitle: 'Deep Search',
    icon: Icons.search_rounded,
    accent: _C.purple,
    badge: 'Scan',
  ),
  _ToolCategory(
    id: 'downloader',
    title: 'Downloader',
    subtitle: 'Media Saver',
    icon: Icons.download_rounded,
    accent: _C.amber,
    badge: 'Fetch',
  ),
  _ToolCategory(
    id: 'utilities',
    title: 'Utilities',
    subtitle: 'Extra Tools',
    icon: Icons.construction_rounded,
    accent: _C.blueMid,
    badge: 'Extra',
  ),
  _ToolCategory(
    id: 'watchs',
    title: 'Watch Video',
    subtitle: 'Stream & Watch',
    icon: Icons.play_circle_rounded,
    accent: _C.blue,
    badge: 'Watch',
  ),
  _ToolCategory(
    id: 'adulthub',
    title: 'Adult Hub',
    subtitle: '18+ Only',
    icon: Icons.lock_rounded,
    accent: _C.pink,
    badge: '18+',
  ),
  _ToolCategory(
    id: 'game',
    title: 'Game',
    subtitle: 'Football & Ular',
    icon: Icons.sports_esports_rounded,
    accent: _C.green,
    badge: 'Play',
  ),
  _ToolCategory(
    id: 'quran',
    title: 'Al-Quran',
    subtitle: 'Baca Al-Quran & Doa',
    icon: Icons.menu_book_rounded,
    accent: _C.teal,
    badge: 'Doa',
  ),
  _ToolCategory(
    id: 'build',
    title: 'Build APK',
    subtitle: 'Build Center',
    icon: Icons.build_circle_rounded,
    accent: _C.green,
    badge: 'Build',
  ),
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  final String username;
  final String uid;  // ✅ TAMBAHKAN INI

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
    required this.username,
    required this.uid,  // ✅ TAMBAHKAN INI
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  // ── Carousel ──────────────────────────────────────────────────────────────────
  late PageController _pageController;
  int _activeIndex = 0;
  double _currentPage = 0.0;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 16))
      ..repeat();

    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _headerFade =
        CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide =
        Tween<Offset>(begin: const Offset(0, -0.2), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();

    _pageController = PageController(viewportFraction: 0.68)
      ..addListener(() {
        if (_pageController.position.haveDimensions) {
          final page = _pageController.page ?? 0.0;
          setState(() {
            _currentPage = page;
            _activeIndex = page.round().clamp(0, _categories.length - 1);
          });
        }
      });
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _headerCtrl.dispose();
    _pageController.dispose();
    super.dispose();
  }

  void _push(Widget page) =>
      Navigator.push(context, _slideRoute(page));

  void _comingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.hourglass_top_rounded, color: Colors.white, size: 16),
        SizedBox(width: 8),
        Text('Coming Soon!',
            style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.w600)),
      ]),
      backgroundColor: _C.blueMid,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }

  void _onCategoryTap(String id) {
    switch (id) {
      case 'controller':
        _showSheet(_controllerItems());
        break;
      case 'panel':
        _showSheet(_panelItems());
        break;
      case 'ddos':
        _showSheet(_ddosItems());
        break;
      case 'network':
        _showSheet(_networkItems());
        break;
      case 'osint':
        _showSheet(_osintItems());
        break;
      case 'downloader':
        _showSheet(_downloaderItems());
        break;
      case 'utilities':
        _showSheet(_utilityItems());
        break;
      case 'watchs':
        _showSheet(_watchsItems());
        break;
      case 'adulthub':
        _showSheet(_adulthubItems());
        break;
      case 'game':
        _showSheet(_gameItems());
        break;
      case 'quran':
        _showSheet(_quranItems());
        break;
      case 'build':
        _showSheet(_buildItems());
        break;
    }
  }

  // ─── NEW: CONTROLLER ADMIN ITEMS ─────────────────────────────────────────
  List<_ToolItem> _controllerItems() => [
        _ToolItem(
          icon: Icons.music_note_rounded,
          label: 'TikTok Tools',
          accent: _C.purple,
          onTap: () => _push(TiktokPage(
            sessionKey: widget.sessionKey,
            username: widget.username,
            role: widget.userRole,
          )),
        ),
      ];

  List<_ToolItem> _panelItems() => [
        _ToolItem(
            icon: Icons.dns_rounded,
            label: 'Manage Server',
            accent: _C.blue,
            onTap: () => _push(
                ManageServerPage(keyToken: widget.sessionKey))),
      ];

  List<_ToolItem> _ddosItems() => [
        _ToolItem(
            icon: Icons.bolt_rounded,
            label: 'Attack Panel',
            accent: _C.blue,
            onTap: () => _push(AttackPanel(
                sessionKey: widget.sessionKey,
                listDoos: widget.listDoos))),
      ];

  List<_ToolItem> _networkItems() => [
        _ToolItem(
            icon: Icons.newspaper_outlined,
            label: 'Spam NGL',
            accent: _C.blue,
            onTap: () => _push(NglPage())),
        _ToolItem(
            icon: Icons.wifi_off_rounded,
            label: 'WiFi Killer (Internal)',
            accent: _C.blue,
            onTap: () => _push(WifiKillerPage())),
        if (widget.userRole == 'vip' || widget.userRole == 'owner')
          _ToolItem(
              icon: Icons.router_rounded,
              label: 'WiFi Killer (External)',
              accent: _C.blue,
              onTap: () => _push(
                  WifiInternalPage(sessionKey: widget.sessionKey))),
      ];

  List<_ToolItem> _osintItems() => [
        _ToolItem(
            icon: Icons.badge_outlined,
            label: 'NIK Detail',
            accent: _C.blue,
            onTap: () => _push(const NikCheckerPage())),
        _ToolItem(
            icon: Icons.travel_explore_rounded,
            label: 'Domain OSINT',
            accent: _C.blue,
            onTap: () => _push(const DomainOsintPage())),
        _ToolItem(
            icon: Icons.person_search_rounded,
            label: 'Phone Lookup',
            accent: _C.blue,
            onTap: () => _push(const PhoneLookupPage())),
        _ToolItem(
            icon: Icons.alternate_email_rounded,
            label: 'Email OSINT',
            accent: _C.blue,
            onTap: () => _push(const EmailOsintPage())),
      ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
            icon: Icons.video_library_rounded,
            label: 'TikTok Downloader',
            accent: _C.blue,
            onTap: () => _push(TiktokDownloaderPage())),
        _ToolItem(
            icon: Icons.camera_alt_rounded,
            label: 'Instagram Downloader',
            accent: _C.blue,
            onTap: () => _push(const InstagramDownloaderPage())),
      ];

  List<_ToolItem> _utilityItems() => [
        _ToolItem(
            icon: Icons.qr_code_2_rounded,
            label: 'QR Generator',
            accent: _C.blue,
            onTap: () => _push(const QrGeneratorPage())),
        _ToolItem(
            icon: Icons.security_rounded,
            label: 'IP Scanner',
            accent: _C.blue,
            onTap: () => _push(const IpScannerPage())),
        _ToolItem(
            icon: Icons.network_check_rounded,
            label: 'Port Scanner',
            accent: _C.blue,
            onTap: () => _push(const PortScannerPage())),
      ];
      
  List<_ToolItem> _watchsItems() => [
        _ToolItem(
            icon: Icons.animation_rounded,
            label: 'Anime',
            accent: _C.blue,
            onTap: () => _push(HomeAnimePage())),
        _ToolItem(
            icon: Icons.play_circle_rounded,
            label: 'Dracin',
            accent: _C.blue,
            onTap: () => _push(const DracinPage())),
      ];
      
  List<_ToolItem> _adulthubItems() => [
        _ToolItem(
            icon: Icons.favorite_rounded,
            label: 'Hentai',
            accent: _C.blue,
            onTap: () => _push(const HomeHentaiPage())),
      ];

  // ─── Game: Football + Ular (dulu 2 tempat terpisah, sekarang digabung
  // jadi satu kategori "Game") ──────────────────────────────────────────────
  List<_ToolItem> _gameItems() => [
        _ToolItem(
          icon: Icons.sports_soccer_rounded,
          label: 'Football',
          accent: _C.green,
          onTap: () => _push(const FootballGamePage()),
        ),
        _ToolItem(
          icon: Icons.sports_esports_rounded,
          label: 'Game Ular',
          accent: _C.green,
          onTap: () => _push(const SnakeGame()),
        ),
      ];

  // ─── Al-Quran (dipindah dari Control Center dashboard ke sini) ───────────
  List<_ToolItem> _quranItems() => [
        _ToolItem(
          icon: Icons.menu_book_rounded,
          label: 'Al-Quran & Doa',
          accent: _C.teal,
          onTap: () => _push(AlQuranPage()),
        ),
      ];

  List<_ToolItem> _buildItems() => [
        _ToolItem(
          icon: Icons.build_circle_rounded,
          label: 'Build APK',
          accent: _C.green,
          onTap: () => _push(BuildApkPage(
            sessionKey: widget.sessionKey,
            username: widget.username,
          )),
        ),
      ];

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: false,
      builder: (_) => _ToolSheet(items: items),
    );
  }

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header ──
                FadeTransition(
                  opacity: _headerFade,
                  child: SlideTransition(
                    position: _headerSlide,
                    child: _buildAppHeader(),
                  ),
                ),

                const SizedBox(height: 12),

                // ── Body: stats row + grid kategori (scrollable) ──
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Stats row: Role / Jumlah Menu / Session
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                          decoration: BoxDecoration(
                            color: _C.card,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: _C.border),
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: _StatItem(
                                  label: 'ROLE',
                                  value: widget.userRole.toUpperCase(),
                                  valueColor: _C.text,
                                ),
                              ),
                              Container(width: 1, height: 30, color: _C.border),
                              Expanded(
                                child: _StatItem(
                                  label: 'JUMLAH MENU',
                                  value: '${_categories.length} TOOLS',
                                  valueColor: _C.text,
                                ),
                              ),
                              Container(width: 1, height: 30, color: _C.border),
                              Expanded(
                                child: _StatItem(
                                  label: 'SESSION',
                                  value: 'READY',
                                  valueColor: _C.green,
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 22),

                        // ── Kategori Menu header ──
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'KATEGORI MENU',
                                    style: TextStyle(
                                      color: _C.text,
                                      fontSize: 19,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'Pilih kategori menu yang Anda butuhkan.',
                                    style: TextStyle(color: _C.textSub, fontSize: 12.5),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                              decoration: BoxDecoration(
                                color: _C.blueMid.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: _C.blueMid.withOpacity(0.4)),
                              ),
                              child: Text(
                                '${_categories.length} MODULES',
                                style: TextStyle(
                                  color: _C.blueMid,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 16),

                        // ── Grid kategori 2 kolom ──
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _categories.length,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisSpacing: 14,
                            crossAxisSpacing: 14,
                            childAspectRatio: 0.78,
                          ),
                          itemBuilder: (ctx, index) {
                            final category = _categories[index];
                            return _CategoryGridCard(
                              category: category,
                              onTap: () => _onCategoryTap(category.id),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── App bar ──────────────────────────────────────────────────────────────────
  Widget _buildAppHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFB71C1C), Color(0xFFD32F2F)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                    color: _C.blueMid.withOpacity(0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 4)),
              ],
            ),
            child: const Icon(Icons.shield_rounded,
                color: Colors.white, size: 26),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'DARK LIGHT',
                style: TextStyle(
                  color: _C.text,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
              Text(
                'Gateway Tools • ${widget.username}',
                style: TextStyle(color: _C.textSub, fontSize: 12),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _C.card,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _C.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _C.blueMid,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text('USER',
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Stat Item (baris Role / Jumlah Menu / Session) ───────────────────────────
class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final Color valueColor;

  const _StatItem({
    required this.label,
    required this.value,
    required this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                color: _C.textDim, fontSize: 10.5, fontWeight: FontWeight.w600, letterSpacing: 0.4)),
        const SizedBox(height: 5),
        Text(value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: valueColor, fontSize: 14.5, fontWeight: FontWeight.w800)),
      ],
    );
  }
}

// ─── Category Grid Card ────────────────────────────────────────────────────────
class _CategoryGridCard extends StatelessWidget {
  final _ToolCategory category;
  final VoidCallback onTap;

  const _CategoryGridCard({
    required this.category,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.25),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // Bar aksen warna di tepi atas kartu
              Positioned(
                top: 0, left: 0, right: 0,
                child: Container(height: 5, color: category.accent),
              ),
              // Watermark ikon raksasa pudar, pojok kanan bawah
              Positioned(
                right: -14, bottom: -14,
                child: Icon(category.icon, size: 86, color: category.accent.withOpacity(0.08)),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: category.accent.withOpacity(0.14),
                            borderRadius: BorderRadius.circular(13),
                          ),
                          child: Icon(category.icon, color: category.accent, size: 22),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: category.accent.withOpacity(0.14),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Text(
                            category.badge,
                            style: TextStyle(
                                color: category.accent, fontSize: 10.5, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      category.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: _C.text, fontSize: 16.5, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      category.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: _C.textSub, fontSize: 11.5),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Circle Button ────────────────────────────────────────────────────────────
class CircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const CircleButton({
    super.key,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: _C.card,
          shape: BoxShape.circle,
          border: Border.all(color: _C.border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Icon(
          icon,
          color: _C.textSub,
          size: 18,
        ),
      ),
    );
  }
}

// ─── Tool Sheet ───────────────────────────────────────────────────────────────
class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.72,
      ),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius:
            BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: _C.borderLit),
          left: BorderSide(color: _C.border),
          right: BorderSide(color: _C.border),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 8),
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.borderLit,
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  _C.blueMid,
                  Colors.transparent
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.separated(
              padding:
                  const EdgeInsets.fromLTRB(16, 8, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) =>
                  const SizedBox(height: 8),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _ToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Tool Row ─────────────────────────────────────────────────────────────────
class _ToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _ToolRow({required this.item, required this.onTap});

  @override
  State<_ToolRow> createState() => _ToolRowState();
}

class _ToolRowState extends State<_ToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(
            horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _pressed
              ? item.accent.withOpacity(0.08)
              : _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _pressed
                ? item.accent.withOpacity(0.35)
                : _C.border,
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                      color: item.accent.withOpacity(0.1),
                      blurRadius: 12,
                      offset: const Offset(0, 4))
                ]
              : [],
        ),
        child: Row(children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: item.accent
                  .withOpacity(_pressed ? 0.18 : 0.1),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(
                  color: item.accent
                      .withOpacity(_pressed ? 0.4 : 0.2)),
            ),
            child:
                Icon(item.icon, color: item.accent, size: 19),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.label,
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontWeight: FontWeight.w700)),
                if (item.comingSoon)
                  Text('Coming Soon',
                      style: TextStyle(
                          color: _C.textSub,
                          fontSize: 10,
                          fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          item.comingSoon
              ? Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.amber.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(
                        color: _C.amber.withOpacity(0.25)),
                  ),
                  child: const Text('SOON',
                      style: TextStyle(
                          color: _C.amber,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5)),
                )
              : AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _pressed
                        ? item.accent.withOpacity(0.15)
                        : _C.surface,
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(
                      color: _pressed
                          ? item.accent.withOpacity(0.3)
                          : _C.border,
                    ),
                  ),
                  child: Icon(
                      Icons.arrow_forward_ios_rounded,
                      color:
                          _pressed ? item.accent : _C.textSub,
                      size: 13),
                ),
        ]),
      ),
    );
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem(
      {required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(
          milliseconds:
              350 + (index * 70).clamp(0, 450)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(
            offset: Offset(0, 18 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withOpacity(0.22)
      ..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(
          Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(
          Offset(0, y), Offset(size.width, y), grid);
    }

    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.steel.withOpacity(
            0.10 + math.sin(t * math.pi * 2) * 0.03),
        Colors.transparent,
      ], radius: 0.9)
          .createShader(Rect.fromCircle(
              center: Offset(size.width / 2, 0),
              radius: size.width));
    canvas.drawCircle(
        Offset(size.width / 2, 0), size.width, glow);

    final glow2 = Paint()
      ..shader = RadialGradient(colors: [
        _C.blueMid.withOpacity(
            0.05 + math.cos(t * math.pi * 2) * 0.02),
        Colors.transparent,
      ], radius: 0.5)
          .createShader(Rect.fromCircle(
              center: Offset(
                  size.width * 0.85, size.height * 0.75),
              radius: size.width * 0.4));
    canvas.drawCircle(
        Offset(size.width * 0.85, size.height * 0.75),
        size.width * 0.4,
        glow2);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ─── Page transition ──────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) =>
          SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
            parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── Data model ───────────────────────────────────────────────────────────────
class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  final bool comingSoon;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.comingSoon = false,
  });
}