import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'splash.dart';
import 'theme_provider.dart';
import 'package:provider/provider.dart';
import 'global_music_overlay.dart';

// ─── Palette – Deep Navy / Cyan Accent ──────────────────────────────────
class _C {
  static Color get bg => ThemeProvider.background;
  static Color get surface => ThemeProvider.surface;
  static Color get card => ThemeProvider.card;
  static Color get border => ThemeProvider.border;
  static Color get cyan => ThemeProvider.currentPrimary;
  static Color get cyanLight => ThemeProvider.currentPrimaryLight;
  static Color get cyanDark => ThemeProvider.currentPrimaryDark;
  static const green      = Color(0xFF22C55E);
  static const amber      = Color(0xFFF59E0B);
  static const red        = Color(0xFFEF4444);
  static Color get text => ThemeProvider.text;
  static Color get textSub => ThemeProvider.textSub;
  static Color get textDim => ThemeProvider.textSub.withOpacity(.72);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl    = TextEditingController();
  final passCtrl    = TextEditingController();
  final _formKey    = GlobalKey<FormState>();

  bool _isLoading       = false;
  bool _obscurePass     = true;
  String? _androidId;
  String? _uid;  // ✅ TAMBAHKAN INI

  // Animations (unchanged)
  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _logoCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _fade;
  late Animation<Offset>  _slide;
  late Animation<double>  _logoGlow;
  late Animation<double>  _btnPulse;
  late Animation<double>  _shake;

  @override
  void initState() {
    super.initState();
    MusicOverlayGate.hide();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _fade  = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _logoGlow = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));

    _btnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1600))
      ..repeat(reverse: true);
    _btnPulse = Tween<double>(begin: 1.0, end: 1.05)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -5.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 5.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 5.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _logoCtrl.dispose();
    _btnCtrl.dispose();
    _shakeCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  // ─── Init auto-login (updated with UID) ──────────────────────────────────────
  Future<void> _initLogin() async {
    final info = await DeviceInfoPlugin().androidInfo;
    _androidId = info.id;

    final prefs    = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey  = prefs.getString('key');

    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final res  = await http.get(Uri.parse(
            '$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          // ✅ SIMPAN UID
          _uid = data['uid'];
          await prefs.setString('uid', _uid ?? '');
          
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: savedUser, password: savedPass,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              uid: data['uid'],  // ✅ TAMBAHKAN INI
              listBug:  _parseList(data['listBug']),
              listDoos: _parseList(data['listDDoS']),
              news:     _parseList(data['news']),
            )),
          );
        }
      } catch (_) {}
    }
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  // ─── Login (updated with UID) ──────────────────────────────────────────────────
  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final res  = await http.post(Uri.parse('$baseUrl/validate'), body: {
        'username': username,
        'password': password,
        'androidId': _androidId ?? 'unknown',
      });
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title:   'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type:    _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title:   'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type:    _AlertType.warning,
          );
        } else {
          _showAlert(
            title:   'Login Gagal',
            message: 'Username atau password salah.',
            type:    _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);
        
        // ✅ SIMPAN UID
        _uid = data['uid'];
        await prefs.setString('uid', _uid ?? '');

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: username, password: password,
              role: data['role'], sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              uid: data['uid'],  // ✅ TAMBAHKAN INI
              listBug:  _parseList(data['listBug']),
              listDoos: _parseList(data['listDDoS']),
              news:     _parseList(data['news']),
            )),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title:   'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type:    _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  // ─── Alert dialog (unchanged) ─────────────────────────────────────────
  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = switch (type) {
      _AlertType.error   => _C.red,
      _AlertType.warning => _C.amber,
      _AlertType.success => _C.green,
    };
    final icon = switch (type) {
      _AlertType.error   => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.card, _C.surface],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.15), blurRadius: 50),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 30),
            ),
            const SizedBox(height: 18),
            Text(title, style: TextStyle(color: _C.text,
                fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Text(message, textAlign: TextAlign.center,
                style: TextStyle(color: _C.textSub,
                    fontSize: 13, height: 1.5)),
            const SizedBox(height: 24),
            if (showContact) ...[
              _GradBtn(
                label: 'HUBUNGI ADMIN',
                fullWidth: true,
                onTap: () async {
                  Navigator.pop(ctx);
                  await launchUrl(Uri.parse('https://t.me/XakatalZ'),
                      mode: LaunchMode.externalApplication);
                },
              ),
              const SizedBox(height: 12),
            ],
            _OutlineBtn(
              label: showContact ? 'TUTUP' : 'OK',
              fullWidth: true,
              onTap: () => Navigator.pop(ctx),
            ),
          ]),
        ),
      ),
    );
  }

  // ─── Build ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // Clean animated DARK LIGHT background — no photo/image layer.
          Positioned.fill(child: Container(color: _C.bg)),
          if (!ThemeProvider.isComic3D) Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: const Alignment(0, -0.35),
                    radius: 1.05,
                    colors: [
                      _C.cyan.withOpacity(.075),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildLogo(),
                        const SizedBox(height: 28),
                        _buildHeading(),
                        const SizedBox(height: 32),
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0),
                            child: child,
                          ),
                          child: _buildForm(),
                        ),
                        const SizedBox(height: 24),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Logo – circular with white/cyan glow ─────────────────────────────
  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _logoGlow,
      builder: (_, __) => Stack(
        alignment: Alignment.center,
        children: [
          // Soft radial glow (white + cyan)
          Container(
            width: 130, height: 130,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  Colors.white.withOpacity(_logoGlow.value * 0.25),
                  _C.cyan.withOpacity(_logoGlow.value * 0.10),
                  Colors.transparent,
                ],
                radius: 0.8,
              ),
            ),
          ),
          // Outer ring
          Container(
            width: 110, height: 110,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: _C.cyan.withOpacity(_logoGlow.value * 0.20),
                width: 1.5,
              ),
            ),
          ),
          // Inner ring
          Container(
            width: 92, height: 92,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(_logoGlow.value * 0.30),
                width: 2,
              ),
            ),
          ),
          // Logo image
          Hero(
            tag: 'logo',
            child: Container(
              width: 76, height: 76,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [_C.surface, _C.bg],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: Colors.white.withOpacity(_logoGlow.value * 0.4),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.cyan.withOpacity(_logoGlow.value * 0.3),
                    blurRadius: 30,
                    spreadRadius: 4,
                  ),
                ],
              ),
              child: ClipOval(
                child: Image.asset('assets/images/logo.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Icon(
                      Icons.rocket_rounded, color: _C.cyan, size: 40)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Heading – stacked "HOLOW EXECUTION" + subtitle ──────────────────
  Widget _buildHeading() {
    return Column(
      children: [
        Text(
          'DARK LIGHT',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w900,
            color: _C.text,
            letterSpacing: 2,
            height: 1.0,
          ),
        ),
        Text(
          'V8.0.0',
          style: TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w900,
            color: _C.text,
            letterSpacing: 2,
            height: 1.0,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border, width: 1),
          ),
          child: Text('By XakatalZ - DeyOffc',
              style: TextStyle(color: _C.textSub, fontSize: 13,
                  fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }

  // ─── Form – pill fields and glowing login button ──────────────────────
  Widget _buildForm() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.card, _C.surface],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: _C.cyan.withOpacity(0.08),
            blurRadius: 40,
            offset: const Offset(0, 15),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.05),
            blurRadius: 60,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            _LoginField(
              controller: userCtrl,
              label: 'Username',
              icon: Icons.person_outline_rounded,
              validator: (v) => (v == null || v.isEmpty)
                  ? 'Username tidak boleh kosong' : null,
            ),
            const SizedBox(height: 16),
            _LoginField(
              controller: passCtrl,
              label: 'Password',
              icon: Icons.lock_outline_rounded,
              obscure: _obscurePass,
              onToggleObscure: () =>
                  setState(() => _obscurePass = !_obscurePass),
              validator: (v) => (v == null || v.isEmpty)
                  ? 'Password tidak boleh kosong' : null,
            ),
            const SizedBox(height: 28),
            _LoginButton(
              isLoading: _isLoading,
              pulseAnim: _btnPulse,
              onTap: _login,
            ),
            const SizedBox(height: 14),
            _AuthSecondaryButton(
              icon: Icons.bolt_rounded,
              label: 'LOGIN GRATIS 6 HARI',
              subtitle: 'Buat akun member • otomatis login',
              onTap: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => const FreeRegisterPage()));
              },
            ),
          ],
        ),
      ),
    );
  }

  // ─── Footer – shield + "Secure Login · Encrypted Connection" ──────────
  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.shield_outlined, color: _C.cyan, size: 16),
        const SizedBox(width: 8),
        const Text(
          'Secure Login · Encrypted Connection',
          style: TextStyle(
            color: Color(0xFF9CA3AF),
            fontSize: 12,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    );
  }
}


class _AuthSecondaryButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;
  const _AuthSecondaryButton({required this.icon, required this.label, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _C.bg.withOpacity(.72),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.cyan.withOpacity(.22)),
      ),
      child: Row(children: [
        Container(width: 40, height: 40, decoration: BoxDecoration(shape: BoxShape.circle, color: _C.cyan.withOpacity(.10), border: Border.all(color: _C.cyan.withOpacity(.22))), child: Icon(icon, color: _C.cyan, size: 21)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: _C.text, fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: .7)),
          const SizedBox(height: 2),
          Text(subtitle, style: TextStyle(color: _C.textSub, fontSize: 10.5)),
        ])),
        Icon(Icons.chevron_right_rounded, color: _C.textSub),
      ]),
    ),
  );
}

class FreeRegisterPage extends StatefulWidget {
  const FreeRegisterPage({super.key});
  @override State<FreeRegisterPage> createState() => _FreeRegisterPageState();
}
class _FreeRegisterPageState extends State<FreeRegisterPage> {
  final u=TextEditingController(), p=TextEditingController(), p2=TextEditingController();
  bool loading=false, hide1=true, hide2=true, checking=true, claimed=false;
  String? error;
  String? _androidId;
  @override void initState(){super.initState(); _checkClaim();}
  Future<void> _checkClaim() async {
    try{
      final info=await DeviceInfoPlugin().androidInfo; _androidId=info.id;
      final r=await http.get(Uri.parse('$baseUrl/api/free-register/status?androidId=${Uri.encodeQueryComponent(info.id)}'));
      final d=jsonDecode(r.body); if(mounted)setState(()=>claimed=d['claimed']==true);
    }catch(_){ } finally { if(mounted)setState(()=>checking=false); }
  }
  @override void dispose(){u.dispose();p.dispose();p2.dispose();super.dispose();}
  Future<void> _create(){ return _go(); }
  Future<void> _go() async {
    if(claimed){setState(()=>error='Login gratis 6 hari sudah pernah digunakan di perangkat ini.');return;}
    final username=u.text.trim(), password=p.text;
    if(username.length<3 || !RegExp(r'^[A-Za-z0-9_.-]+$').hasMatch(username)){setState(()=>error='Username minimal 3 karakter dan hanya huruf/angka/._-');return;}
    if(password.length<4){setState(()=>error='Password minimal 4 karakter.');return;}
    if(password!=p2.text){setState(()=>error='Konfirmasi password tidak sama.');return;}
    setState(() { loading = true; error = null; });
    try{
      final info=await DeviceInfoPlugin().androidInfo;
      final r=await http.post(Uri.parse('$baseUrl/api/free-register'),body:{'username':username,'password':password,'androidId':info.id});
      final d=jsonDecode(r.body);
      if(d['valid']!=true) throw Exception(d['message']??'Gagal membuat akun');
      final login=await http.post(Uri.parse('$baseUrl/validate'),body:{'username':username,'password':password,'androidId':info.id});
      final ld=jsonDecode(login.body);
      if(ld['valid']!=true) throw Exception(ld['message']??'Akun dibuat tetapi login otomatis gagal');
      final prefs=await SharedPreferences.getInstance();
      await prefs.setString('username',username); await prefs.setString('password',password); await prefs.setString('key',ld['key']); await prefs.setString('uid',ld['uid']??'');
      if(!mounted)return;
      Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>SplashScreen(username:username,password:password,role:ld['role'],sessionKey:ld['key'],expiredDate:ld['expiredDate'],uid:ld['uid'],listBug:_parseList(ld['listBug']),listDoos:_parseList(ld['listDDoS']),news:_parseList(ld['news']))),(_)=>false);
    }catch(e){if(mounted)setState(()=>error=e.toString().replaceFirst('Exception: ',''));}
    if(mounted)setState(()=>loading=false);
  }
  List<Map<String,dynamic>> _parseList(dynamic x)=>(x as List? ?? []).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
  InputDecoration _dec(String hint,IconData icon)=>InputDecoration(hintText:hint,hintStyle:TextStyle(color:_C.textDim),prefixIcon:Icon(icon,color:_C.textSub),filled:true,fillColor:_C.bg.withOpacity(.7),border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide(color:_C.border)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide(color:_C.border)),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide(color:_C.cyan)),contentPadding:EdgeInsets.symmetric(vertical:17));
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:_C.bg,body:Stack(children:[
  Positioned.fill(child:Image.asset('assets/images/background.jpg',fit:BoxFit.cover)),
  Positioned.fill(child:Container(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.black.withOpacity(.70),_C.bg.withOpacity(.97)])))),
  SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(18,12,18,28),children:[
  Row(children:[IconButton(onPressed:()=>Navigator.pop(context),icon:Icon(Icons.arrow_back_rounded,color:_C.text)),Expanded(child:Text('LOGIN GRATIS 6 HARI',style:TextStyle(fontSize:17,fontWeight:FontWeight.w900,letterSpacing:1))),Icon(Icons.bolt_rounded,color:_C.cyan)]),
    Container(padding:EdgeInsets.all(20),decoration:BoxDecoration(gradient:LinearGradient(colors:[_C.card,_C.surface]),borderRadius:BorderRadius.circular(26),border:Border.all(color:_C.cyan.withOpacity(.18))),child:Column(children:[
      Container(width:66,height:66,decoration:BoxDecoration(shape:BoxShape.circle,color:_C.cyan.withOpacity(.10),border:Border.all(color:_C.cyan.withOpacity(.35))),child:Icon(Icons.bolt_rounded,color:_C.cyan,size:34)),SizedBox(height:12),
      const Text('Akses Gratis 6 Hari',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text('Buat akun member gratis. Setelah berhasil, akun langsung login otomatis.',textAlign:TextAlign.center,style:TextStyle(color:_C.textSub)),const SizedBox(height:22),
      TextField(controller:u,decoration:_dec('Nama akun',Icons.person_outline_rounded)),const SizedBox(height:12),
      TextField(controller:p,obscureText:hide1,decoration:_dec('Password',Icons.lock_outline_rounded).copyWith(suffixIcon:IconButton(onPressed:()=>setState(()=>hide1=!hide1),icon:Icon(hide1?Icons.visibility_off:Icons.visibility,color:_C.textSub)))),const SizedBox(height:12),
      TextField(controller:p2,obscureText:hide2,decoration:_dec('Ulangi password',Icons.lock_reset_rounded).copyWith(suffixIcon:IconButton(onPressed:()=>setState(()=>hide2=!hide2),icon:Icon(hide2?Icons.visibility_off:Icons.visibility,color:_C.textSub)))),
      if(error!=null)Padding(padding:const EdgeInsets.only(top:14),child:Text(error!,style:const TextStyle(color:_C.red,fontSize:12),textAlign:TextAlign.center)),const SizedBox(height:18),
      if(claimed)Container(width:double.infinity,padding:const EdgeInsets.all(14),margin:const EdgeInsets.only(top:14),decoration:BoxDecoration(color:_C.red.withOpacity(.08),borderRadius:BorderRadius.circular(16),border:Border.all(color:_C.red.withOpacity(.28))),child:Row(children:[Icon(Icons.block_rounded,color:_C.red),SizedBox(width:10),Expanded(child:Text('Login gratis sudah digunakan. Satu perangkat hanya bisa membuat 1 akun gratis.',style:TextStyle(color:_C.textSub,fontSize:12,fontWeight:FontWeight.w700)))])),
      const SizedBox(height:18),
      SizedBox(width:double.infinity,height:54,child:ElevatedButton(onPressed:(loading||checking||claimed)?null:_create,style:ElevatedButton.styleFrom(backgroundColor:claimed?_C.textDim:_C.cyan,foregroundColor:Colors.black,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),child:checking?SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2,color:Colors.black)):loading?SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2,color:Colors.black)):Text(claimed?'SUDAH DIGUNAKAN':'BUAT & LOGIN SEKARANG',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:.6)))),
    ])),const SizedBox(height:16),Text('Akun gratis berlaku 6 hari dan hanya bisa dibuat 1 kali per perangkat.',style:TextStyle(color:_C.textDim,fontSize:11),textAlign:TextAlign.center)
  ]))
]));
}

// ─── Login Field – pill shape with dark background ──────────────────────────
class _LoginField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _LoginField({
    required this.controller,
    required this.label,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_LoginField> createState() => _LoginFieldState();
}

class _LoginFieldState extends State<_LoginField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: _focused ? _C.cyan : _C.border,
          width: _focused ? 1.5 : 1.0,
        ),
        boxShadow: _focused
            ? [BoxShadow(color: _C.cyan.withOpacity(0.15),
                blurRadius: 16, offset: const Offset(0, 4))]
            : [],
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        obscureText: widget.obscure,
        validator: widget.validator,
        style: TextStyle(color: _C.text, fontSize: 15,
            fontWeight: FontWeight.w500),
        cursorColor: _C.cyan,
        decoration: InputDecoration(
          labelText: widget.label,
          labelStyle: TextStyle(
            color: _focused ? _C.cyanLight : _C.textSub,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
          floatingLabelStyle:
              TextStyle(color: _C.cyan, fontSize: 11),
          prefixIcon: Icon(widget.icon,
              color: _focused ? _C.cyanLight : _C.textSub, size: 20),
          suffixIcon: widget.onToggleObscure != null
              ? GestureDetector(
                  onTap: widget.onToggleObscure,
                  child: Container(
                    margin: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _C.surface,
                    ),
                    child: Icon(
                      widget.obscure
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                      color: _focused ? _C.cyanLight : _C.textSub,
                      size: 20,
                    ),
                  ),
                )
              : null,
          errorStyle: const TextStyle(color: _C.red, fontSize: 11),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        ),
      ),
    );
  }
}

// ─── Login Button – white pill with cyan glow and icon ──────────────────────
class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final Animation<double> pulseAnim;
  final VoidCallback onTap;

  const _LoginButton({
    required this.isLoading,
    required this.pulseAnim,
    required this.onTap,
  });

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedBuilder(
        animation: widget.pulseAnim,
        builder: (_, __) => Transform.scale(
          scale: widget.isLoading || _down ? 1.0 : widget.pulseAnim.value,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            height: 56,
            width: double.infinity,
            decoration: BoxDecoration(
              color: ThemeProvider.isComic3D ? _C.cyan : Colors.white,
              borderRadius: BorderRadius.circular(ThemeProvider.isComic3D ? 16 : 30),
              border: ThemeProvider.isComic3D
                  ? Border.all(color: ThemeProvider.comicInk, width: 2)
                  : null,
              boxShadow: _down || widget.isLoading
                  ? []
                  : [
                      BoxShadow(
                        color: _C.cyan.withOpacity(
                            widget.pulseAnim.value * 0.6),
                        blurRadius: 30,
                        spreadRadius: 4,
                        offset: const Offset(0, 8),
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(
                            widget.pulseAnim.value * 0.2),
                        blurRadius: 40,
                        spreadRadius: 6,
                        offset: const Offset(0, 4),
                      ),
                    ],
            ),
            child: Center(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: widget.isLoading
                    ? SizedBox(
                        key: ValueKey('loading'),
                        width: 22, height: 22,
                        child: CircularProgressIndicator(
                            strokeWidth: 2.5, color: _C.cyanDark),
                      )
                    : Row(
                        key: ValueKey('idle'),
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.login_rounded,
                              color: _C.cyanDark, size: 20),
                          SizedBox(width: 12),
                          Text('LOGIN',
                              style: TextStyle(
                                color: _C.cyanDark,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1,
                              )),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Gradient Button (used in dialogs, unchanged) ──────────────────────────
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _GradBtn({required this.label, required this.onTap,
      this.fullWidth = false});

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 48,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.cyan, _C.cyanDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: _down ? [] : [
              BoxShadow(color: _C.cyan.withOpacity(0.4),
                  blurRadius: 16, offset: const Offset(0, 6)),
            ],
          ),
          child: Center(
            child: Text(widget.label,
                style: const TextStyle(color: Colors.white,
                    fontWeight: FontWeight.w800, fontSize: 14,
                    letterSpacing: 0.5)),
          ),
        ),
      ),
    );
  }
}

// ─── Outline Button (used in dialogs, unchanged) ────────────────────────────
class _OutlineBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _OutlineBtn({required this.label, required this.onTap,
      this.fullWidth = false});

  @override
  State<_OutlineBtn> createState() => _OutlineBtnState();
}

class _OutlineBtnState extends State<_OutlineBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 48,
        width: widget.fullWidth ? double.infinity : null,
        decoration: BoxDecoration(
          color: _down ? _C.border.withOpacity(0.3) : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border, width: 1.5),
        ),
        child: Center(
          child: Text(widget.label,
              style: TextStyle(color: _C.textSub,
                  fontWeight: FontWeight.w700, fontSize: 14,
                  letterSpacing: 0.5)),
        ),
      ),
    );
  }
}

// ─── Animated Background – grid + soft glows ─────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // Grid
    final grid = Paint()
      ..color = _C.border.withOpacity(0.15)
      ..strokeWidth = 0.6;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    // Central cyan glow
    final glow = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.cyan.withOpacity(0.06 + math.sin(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ],
        radius: 0.8,
      ).createShader(
        Rect.fromCircle(
          center: Offset(size.width / 2, size.height * 0.3),
          radius: size.width * 0.7,
        ),
      );
    canvas.drawCircle(
        Offset(size.width / 2, size.height * 0.3),
        size.width * 0.7,
        glow
    );

    // Secondary white glow
    final glow2 = Paint()
      ..shader = RadialGradient(
        colors: [
          Colors.white.withOpacity(0.03 + math.cos(t * math.pi * 2) * 0.01),
          Colors.transparent,
        ],
        radius: 0.5,
      ).createShader(
        Rect.fromCircle(
          center: Offset(size.width * 0.15, size.height * 0.8),
          radius: size.width * 0.5,
        ),
      );
    canvas.drawCircle(
        Offset(size.width * 0.15, size.height * 0.8),
        size.width * 0.5,
        glow2
    );
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

enum _AlertType { error, warning, success }
