import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'api_config.dart';
import 'app_background.dart';

class AppThemePreset {
  final String id;
  final String name;
  final Color primary;
  final Color secondary;
  final bool gradient;
  // Latar (background/surface/card) & Garis (border/ink) opsional — dipakai
  // oleh preset "TEMPLATE WARNA" bergaya komik (persis warna di index.html)
  // supaya 1 klik mengganti ke-4 kanal sekaligus: Utama, Aksen, Latar, Garis.
  final Color? background;
  final Color? border;

  const AppThemePreset({
    required this.id,
    required this.name,
    required this.primary,
    required this.secondary,
    this.gradient = false,
    this.background,
    this.border,
  });
}

class ThemeProvider extends ChangeNotifier {
  static const String _defaultId = 'default';
  static const Color defaultPrimary = Color(0xFFD96891);
  static const Color defaultSecondary = Color(0xFFA94871);

  // Global visual style. "classic" keeps the original DARK LIGHT UI,
  // while "comic3d" switches the whole Material theme to the paper/ink
  // comic language used by the Theme Settings mockup.
  static bool _comic3D = false;
  static bool get isComic3D => _comic3D;
  static String get styleId => _comic3D ? 'comic3d' : 'classic';

  // Runtime palette shared by legacy custom widgets. These values mirror the
  // currently selected per-user theme without touching API/session behavior.
  static Color currentPrimary = defaultPrimary;
  static Color currentSecondary = defaultSecondary;
  static bool _backgroundThemeMode = false;
  static bool get backgroundThemeMode => _backgroundThemeMode;

  // Independent per-channel overrides (the "Kustomisasi Warna Tema" panel).
  // Classic and Comic 3D each keep their own override set, so switching
  // style never bleeds one preset's custom colors into the other.
  static Color? _customBackgroundClassic;
  static Color? _customSurfaceClassic;
  static Color? _customBorderClassic;
  static Color? _customBackgroundComic;
  static Color? _customSurfaceComic;
  static Color? _customBorderComic;

  static Color get currentPrimaryLight => Color.lerp(currentPrimary, Colors.white, 0.35)!;
  static Color get currentPrimaryDark => Color.lerp(currentPrimary, Colors.black, 0.28)!;
  static Color get currentSecondaryLight => Color.lerp(currentSecondary, Colors.white, 0.25)!;
  static bool get isLightPalette => _comic3D || currentPrimary.computeLuminance() > 0.72;
  // ── Comic tokens, derived exactly like `body.comic` in index.html ───────
  //   --red   = Utama (currentPrimary)      --yellow = Aksen (currentSecondary)
  //   --paper = Latar                       --ink    = Garis
  //   --red-d  = red 72% + black            --paper2 = paper 30% + white
  //   --muted  = ink 72% + paper            --on-p / --on-a = white or ink by
  //   luminance (> .42 -> ink) of red / yellow.
  static const Color _defPaper = Color(0xFFF5E6C0);
  static const Color _defInk = Color(0xFF1C1C1C);
  static Color _mix(Color a, Color b, double pa) => Color.fromARGB(
        255,
        (a.red * pa + b.red * (1 - pa)).round(),
        (a.green * pa + b.green * (1 - pa)).round(),
        (a.blue * pa + b.blue * (1 - pa)).round(),
      );
  static Color _onColor(Color c) => _wcagLum(c) > .42 ? _defInk : Colors.white;
  static double _wcagLum(Color c) {
    double f(int v) {
      final x = v / 255;
      return x <= .03928 ? x / 12.92 : math.pow((x + .055) / 1.055, 2.4).toDouble();
    }
    return .2126 * f(c.red) + .7152 * f(c.green) + .0722 * f(c.blue);
  }

  static Color get comicPaper => _customBackgroundComic ?? _defPaper;
  static Color get comicInk => _customBorderComic ?? _defInk;
  static Color get comicRed => _comic3D ? currentPrimary : const Color(0xFFE63A2E);
  static Color get comicYellow => _comic3D ? currentSecondary : const Color(0xFFFFD93D);
  static Color get comicRedDark => _mix(comicRed, Colors.black, .72);
  static Color get comicPaper2 => _mix(comicPaper, Colors.white, .30);
  static Color get comicCream => comicPaper2;
  static Color get comicMuted => _mix(comicInk, comicPaper, .72);
  static Color get comicOnPrimary => _onColor(comicRed);
  static Color get comicOnAccent => _onColor(comicYellow);

  static Color get background => (_comic3D ? _customBackgroundComic : _customBackgroundClassic) ??
      (_comic3D
          ? _defPaper
          : (isLightPalette
              ? Color.lerp(Colors.white, currentPrimary, 0.08)!
              : Color.lerp(Colors.black, currentPrimary, 0.16)!));
  static Color get surface => (_comic3D ? _customSurfaceComic : _customSurfaceClassic) ??
      (_comic3D
          ? comicPaper2
          : (isLightPalette
              ? Color.lerp(Colors.white, currentPrimary, 0.16)!
              : Color.lerp(Colors.black, currentSecondary, 0.32)!));
  static Color get card => (_comic3D ? _customSurfaceComic : _customSurfaceClassic) ??
      (_comic3D
          ? comicPaper2
          : (isLightPalette
              ? Color.lerp(Colors.white, currentPrimary, 0.24)!
              : Color.lerp(Colors.black, currentSecondary, 0.48)!));
  static Color get border => (_comic3D ? _customBorderComic : _customBorderClassic) ??
      (_comic3D
          ? _defInk
          : (isLightPalette
              ? Color.lerp(Colors.black12, currentPrimary, 0.30)!
              : Color.lerp(Colors.black, currentPrimary, 0.42)!));
  static Color get text => _comic3D
      ? comicInk
      : (isLightPalette ? const Color(0xFF111111) : Colors.white);
  static Color get textSub => _comic3D
      ? comicMuted
      : (isLightPalette ? const Color(0xFF555555) : Colors.white70);
  static Color get frost => _comic3D ? Colors.black12 : (isLightPalette ? Colors.black12 : Colors.white12);

  // Legacy UI tint: keeps existing images/text readable while harmonising
  // older widgets that still contain fixed accent colors.
  static bool get needsGlobalTint => !_comic3D && currentPrimary != defaultPrimary;
  static Color get globalTint => currentPrimary;
  static ColorFilter get globalColorFilter {
    if (isLightPalette) {
      // Light themes: gently wash legacy dark surfaces toward the selected hue.
      return ColorFilter.matrix(<double>[
        0.82, 0.08, 0.08, 0, 28,
        0.08, 0.82, 0.08, 0, 28,
        0.08, 0.08, 0.82, 0, 28,
        0,    0,    0,    1, 0,
      ]);
    }
    return ColorFilter.mode(globalTint, BlendMode.hue);
  }

  // TEMPLATE WARNA (mode 3D Comic) — disalin 1:1 (id, nama, dan ke-4 kode
  // HEX: Utama, Aksen, Latar, Garis) dari array `P` di index.html, supaya
  // preset di app sama persis dengan preset di halaman web referensinya.
  // HANYA tampil & bisa dipilih saat ThemeProvider.isComic3D == true.
  static const List<AppThemePreset> comicPresets = [
    AppThemePreset(id: 'classic', name: 'Classic', primary: Color(0xFFE63A2E), secondary: Color(0xFFFFD93D), background: Color(0xFFF5E6C0), border: Color(0xFF1C1C1C), gradient: true),
    AppThemePreset(id: 'cyber', name: 'Cyberpunk', primary: Color(0xFFE91EC7), secondary: Color(0xFF00D9F5), background: Color(0xFFEFE3FF), border: Color(0xFF14102E), gradient: true),
    AppThemePreset(id: 'hutan', name: 'Hutan', primary: Color(0xFF1FA35B), secondary: Color(0xFFFFD93D), background: Color(0xFFE9F3D2), border: Color(0xFF12261A), gradient: true),
    AppThemePreset(id: 'samudra', name: 'Samudra', primary: Color(0xFF1E6FE0), secondary: Color(0xFFFFC83D), background: Color(0xFFDFF0FF), border: Color(0xFF0F1E3D), gradient: true),
    AppThemePreset(id: 'sakura', name: 'Sakura', primary: Color(0xFFEC5B8D), secondary: Color(0xFFFFE08A), background: Color(0xFFFFEEF3), border: Color(0xFF3B1A28), gradient: true),
    AppThemePreset(id: 'sunset', name: 'Sunset', primary: Color(0xFFFF6A2B), secondary: Color(0xFFFFCF33), background: Color(0xFFFFE9CF), border: Color(0xFF2A1409), gradient: true),
    AppThemePreset(id: 'ungu', name: 'Ungu Misteri', primary: Color(0xFF7B3FE4), secondary: Color(0xFFFFD93D), background: Color(0xFFEEE6FF), border: Color(0xFF1D1033), gradient: true),
    AppThemePreset(id: 'mint', name: 'Mint Pop', primary: Color(0xFF14B8A6), secondary: Color(0xFFFF8FB1), background: Color(0xFFE3FBF5), border: Color(0xFF0F2A28), gradient: true),
    AppThemePreset(id: 'manga', name: 'Manga Hitam Putih', primary: Color(0xFF2B2B2B), secondary: Color(0xFFD9D9D9), background: Color(0xFFF2F2F2), border: Color(0xFF000000), gradient: true),
    AppThemePreset(id: 'royal', name: 'Royal Emas', primary: Color(0xFF8B1E3F), secondary: Color(0xFFF5C542), background: Color(0xFFF7ECD2), border: Color(0xFF2A0F17), gradient: true),
    AppThemePreset(id: 'lime', name: 'Neon Lime', primary: Color(0xFF8BD100), secondary: Color(0xFFFF3D81), background: Color(0xFFF6FFE0), border: Color(0xFF1A2200), gradient: true),
    AppThemePreset(id: 'kopi', name: 'Kopi Susu', primary: Color(0xFF8B5A2B), secondary: Color(0xFFF2B84B), background: Color(0xFFF1E2C8), border: Color(0xFF2B1A0E), gradient: true),
  ];

  // TEMPLATE WARNA (mode Standar/Klasik) — palet lembut ala Material,
  // terpisah TOTAL dari comicPresets supaya tidak pernah "bentrok": preset
  // bergaya tinta tebal komik tidak akan pernah muncul/kepilih saat lagi
  // mode Klasik, begitu juga sebaliknya. HANYA tampil saat isComic3D == false.
  static const List<AppThemePreset> classicPresets = [
    AppThemePreset(id: 'pink', name: 'Pink', primary: Color(0xFFD96891), secondary: Color(0xFFA94871), background: Color(0xFFFDF2F6), border: Color(0xFFF0D3DE)),
    AppThemePreset(id: 'rose', name: 'Rose Merah', primary: Color(0xFFE0527A), secondary: Color(0xFFB23A5C), background: Color(0xFFFCEEF1), border: Color(0xFFF0CCD5)),
    AppThemePreset(id: 'peach', name: 'Peach', primary: Color(0xFFFF9466), secondary: Color(0xFFE06B3D), background: Color(0xFFFFF2EB), border: Color(0xFFFBDBC8)),
    AppThemePreset(id: 'emas', name: 'Emas', primary: Color(0xFFD4A73D), secondary: Color(0xFFA67F1F), background: Color(0xFFFBF5E6), border: Color(0xFFEFDFAE)),
    AppThemePreset(id: 'sage', name: 'Hijau Sage', primary: Color(0xFF8FAE8B), secondary: Color(0xFF5F7D5A), background: Color(0xFFF1F6EF), border: Color(0xFFD7E4D4)),
    AppThemePreset(id: 'zamrud', name: 'Zamrud', primary: Color(0xFF1FA874), secondary: Color(0xFF0D7A52), background: Color(0xFFE9F8F1), border: Color(0xFFBFE9D5)),
    AppThemePreset(id: 'langit', name: 'Langit', primary: Color(0xFF5FA8D3), secondary: Color(0xFF2E7BB0), background: Color(0xFFEBF6FC), border: Color(0xFFC6E3F3)),
    AppThemePreset(id: 'biru', name: 'Biru', primary: Color(0xFF5B7FD9), secondary: Color(0xFF3955A8), background: Color(0xFFEDF0FC), border: Color(0xFFCCD7F5)),
    AppThemePreset(id: 'lavender', name: 'Lavender', primary: Color(0xFFA78BFA), secondary: Color(0xFF7C5CD6), background: Color(0xFFF4F0FE), border: Color(0xFFDDD1FB)),
    AppThemePreset(id: 'unguklasik', name: 'Ungu', primary: Color(0xFF8B5CF6), secondary: Color(0xFF6633CC), background: Color(0xFFF1EBFE), border: Color(0xFFD9C8FA)),
    AppThemePreset(id: 'kopiklasik', name: 'Kopi', primary: Color(0xFF8B5A2B), secondary: Color(0xFF5C3A1A), background: Color(0xFFF6EFE7), border: Color(0xFFE2CDB6)),
    AppThemePreset(id: 'abuelegan', name: 'Abu Elegan', primary: Color(0xFF6B7280), secondary: Color(0xFF44474F), background: Color(0xFFF2F3F5), border: Color(0xFFDADDE2)),
  ];

  /// Daftar preset yang berlaku untuk mode yang SEDANG aktif — dipakai UI
  /// supaya tidak perlu cek isComic3D berulang-ulang di tiap tempat.
  static List<AppThemePreset> get activePresets => _comic3D ? comicPresets : classicPresets;

  Color _primary = defaultPrimary;
  Color _secondary = defaultSecondary;
  String _presetId = _defaultId;
  String _presetName = 'Default';
  bool _gradient = true;
  String _backgroundId = 'dragon_ember';
  String _username = '';
  String _sessionKey = '';
  bool _loading = false;

  Color get dxPrimary => _primary;
  Color get dxSecondary => _secondary;
  String get presetId => _presetId;
  String get presetName => _presetName;
  bool get isGradient => _gradient;
  bool get loading => _loading;
  String get backgroundId => _backgroundId;
  AppBackgroundPreset get currentBackground => DragonBackgroundPresets.get(_backgroundId);
  bool get comic3D => _comic3D;

  Future<void> setStyle(String style) async {
    final comic = style.toLowerCase() == 'comic3d';
    _comic3D = comic;
    _backgroundThemeMode = false;
    if (comic) {
      // Start 3D Comic with the same colors as the reference design.
      _primary = const Color(0xFFE63A2E);
      _secondary = const Color(0xFFFFD93D);
      _presetId = 'classic';
      _presetName = 'Classic';
      _customBackgroundComic = null;
      _customSurfaceComic = null;
      _customBorderComic = null;
      _gradient = true;
    } else {
      _primary = defaultPrimary;
      _secondary = defaultSecondary;
      _presetId = _defaultId;
      _presetName = 'Default';
      _gradient = true;
    }
    _syncRuntimePalette();
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  Future<void> selectBackground(AppBackgroundPreset background) async {
    _backgroundId = background.id;
    // Background selection is a complete visual theme: the artwork supplies
    // the primary/secondary accents so cards, buttons, icons and navigation
    // follow the same visual language immediately.
    _primary = background.themePrimary ?? background.glow;
    _secondary = background.themeSecondary ?? background.b;
    _presetId = 'background_${background.id}';
    _presetName = background.name;
    _gradient = true;
    _backgroundThemeMode = true;
    _syncRuntimePalette();
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  /// The "Kustomisasi Warna Tema" panel: set any subset of the 4 channels
  /// (pass null to leave a channel untouched). Applies to whichever style
  /// (classic / comic3d) is active right now.
  Future<void> setCustomChannels({Color? background, Color? primary, Color? secondary, Color? surface, Color? border}) async {
    if (_comic3D) {
      if (background != null) _customBackgroundComic = background;
      if (surface != null) _customSurfaceComic = surface;
      if (border != null) _customBorderComic = border;
    } else {
      if (background != null) _customBackgroundClassic = background;
      if (surface != null) _customSurfaceClassic = surface;
      if (border != null) _customBorderClassic = border;
    }
    if (primary != null) {
      _primary = primary;
      _presetId = 'custom';
      _presetName = 'Custom';
      _backgroundThemeMode = false;
    }
    if (secondary != null) {
      _secondary = secondary;
      _presetId = 'custom';
      _presetName = 'Custom';
      _backgroundThemeMode = false;
    }
    // index.html: touching any of the 4 pickers switches the palette to
    // "custom" (pal='custom').
    if (_comic3D && (background != null || border != null)) {
      _presetId = 'custom';
      _presetName = 'Custom';
    }
    _syncRuntimePalette();
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  /// Clears only the 4-channel overrides for the current style, keeping the
  /// chosen primary/secondary preset untouched.
  Future<void> resetCustomChannels() async {
    if (_comic3D) {
      _customBackgroundComic = null;
      _customSurfaceComic = null;
      _customBorderComic = null;
    } else {
      _customBackgroundClassic = null;
      _customSurfaceClassic = null;
      _customBorderClassic = null;
    }
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  // Some screens (TikTok, Chat) ship their own complete, fixed color
  // theme and must never be re-skinned by the global comic/anime
  // atmosphere or the legacy color tint. They call pushOwnTheme() in
  // initState and popOwnTheme() in dispose; a counter (not a bool)
  // keeps this correct even if such pages are nested/pushed on top of
  // each other.
  static final ValueNotifier<int> ownThemeDepth = ValueNotifier<int>(0);
  static void pushOwnTheme() => ownThemeDepth.value++;
  static void popOwnTheme() {
    if (ownThemeDepth.value > 0) ownThemeDepth.value--;
  }

  // Device-wide fallback key: saved/loaded regardless of whether a user is
  // logged in, so the theme chosen on the Theme page survives app restarts
  // even on screens shown before login (splash, landing, login).
  static const String _deviceKey = 'app_theme_device';

  /// Restores the last-used theme from the device-local key. Must be
  /// awaited before the first frame (see main()) so splash/landing/login
  /// render with the correct style instead of the hardcoded default.
  Future<void> loadDeviceLocal() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_deviceKey);
      if (raw == null || raw.isEmpty) return;
      _applyMap(jsonDecode(raw) as Map<String, dynamic>, notify: false);
    } catch (_) {}
  }

  AppThemePreset get currentPreset => AppThemePreset(
    id: _presetId,
    name: _presetName,
    primary: _primary,
    secondary: _secondary,
    gradient: _gradient,
  );

  Future<void> configure({
    required String username,
    required String sessionKey,
  }) async {
    _username = username;
    _sessionKey = sessionKey;
    await _loadLocal();
    await _loadRemote();
  }

  Future<void> _loadLocal() async {
    if (_username.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('app_theme_$_username');
    if (raw == null || raw.isEmpty) return;
    try {
      _applyMap(jsonDecode(raw) as Map<String, dynamic>, notify: false);
      notifyListeners();
      // Backfill the device-wide fallback so older accounts (saved before
      // this key existed) also get the fix on their very next login.
      await _saveLocal();
    } catch (_) {}
  }

  Future<void> _loadRemote() async {
    if (_sessionKey.isEmpty) return;
    _loading = true;
    notifyListeners();
    try {
      final r = await http.get(
        Uri.parse('$baseUrl/api/user/theme').replace(
          queryParameters: {'session_key': _sessionKey},
        ),
      ).timeout(const Duration(seconds: 8));
      if (r.statusCode == 200) {
        final body = jsonDecode(r.body);
        if (body is Map && body['theme'] is Map) {
          _applyMap(Map<String, dynamic>.from(body['theme']), notify: true);
          await _saveLocal();
        }
      }
    } catch (_) {
      // Local theme remains active when the API is unreachable.
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> select(AppThemePreset preset) async {
    _backgroundThemeMode = false;
    _primary = preset.primary;
    _secondary = preset.secondary;
    _presetId = preset.id;
    _presetName = preset.name;
    _gradient = preset.gradient;
    // Preset TEMPLATE WARNA membawa Latar & Garis sendiri (sama seperti
    // index.html mengganti --paper/--ink sekaligus saat klik 1 preset).
    // Latar dipakai untuk background, surface, DAN card supaya warna
    // "kertas" seragam di semua permukaan, persis seperti referensinya.
    if (preset.background != null) {
      if (_comic3D) {
        _customBackgroundComic = preset.background;
        _customSurfaceComic = null; // card/surface = paper2, derived from paper
      } else {
        _customBackgroundClassic = preset.background;
        _customSurfaceClassic = preset.background;
      }
    }
    if (preset.border != null) {
      if (_comic3D) {
        _customBorderComic = preset.border;
      } else {
        _customBorderClassic = preset.border;
      }
    }
    _syncRuntimePalette();
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  Future<void> setCustom({required Color primary, required Color secondary, bool gradient = true}) async {
    _backgroundThemeMode = false;
    _primary = primary;
    _secondary = secondary;
    _presetId = 'custom';
    _presetName = 'Custom';
    _gradient = gradient;
    _syncRuntimePalette();
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  Future<void> reset() async {
    _backgroundThemeMode = false;
    if (_comic3D) {
      _primary = const Color(0xFFE63A2E);
      _secondary = const Color(0xFFFFD93D);
      _presetId = 'classic';
      _presetName = 'Classic';
      _customBackgroundComic = null;
      _customSurfaceComic = null;
      _customBorderComic = null;
    } else {
      _primary = defaultPrimary;
      _secondary = defaultSecondary;
      _presetId = _defaultId;
      _presetName = 'Default';
      _customBackgroundClassic = null;
      _customSurfaceClassic = null;
      _customBorderClassic = null;
    }
    _gradient = true;
    _syncRuntimePalette();
    notifyListeners();
    await _saveLocal();
    await _saveRemote();
  }

  String? _hex(Color? c) => c == null ? null : c.value.toRadixString(16).padLeft(8, '0');

  Map<String, dynamic> _toMap() => {
    'preset_id': _presetId,
    'name': _presetName,
    'primary': _primary.value.toRadixString(16).padLeft(8, '0'),
    'secondary': _secondary.value.toRadixString(16).padLeft(8, '0'),
    'gradient': _gradient,
    'background_id': _backgroundId,
    'style': styleId,
    'custom_bg_classic': _hex(_customBackgroundClassic),
    'custom_surface_classic': _hex(_customSurfaceClassic),
    'custom_border_classic': _hex(_customBorderClassic),
    'custom_bg_comic': _hex(_customBackgroundComic),
    'custom_surface_comic': _hex(_customSurfaceComic),
    'custom_border_comic': _hex(_customBorderComic),
  };

  void _applyMap(Map<String, dynamic> map, {required bool notify}) {
    if (map.containsKey('style')) _comic3D = '${map['style']}'.toLowerCase() == 'comic3d';
    final primary = _parseColor(map['primary']);
    final secondary = _parseColor(map['secondary']);
    if (primary == null || secondary == null) return;
    _primary = primary;
    _secondary = secondary;
    _presetId = '${map['preset_id'] ?? 'custom'}';
    _presetName = '${map['name'] ?? 'Custom'}';
    _gradient = map['gradient'] == true;
    // Only touch a custom-channel field when the incoming map actually
    // carries that key. The remote /api/user/theme response may still use
    // an older schema that doesn't know about these 4-channel overrides —
    // applying it unconditionally would wipe a correctly-loaded local
    // value back to null (the background reverting to its default color
    // every time the app restarts was exactly this bug).
    if (map.containsKey('custom_bg_classic')) _customBackgroundClassic = _parseColor(map['custom_bg_classic']);
    if (map.containsKey('custom_surface_classic')) _customSurfaceClassic = _parseColor(map['custom_surface_classic']);
    if (map.containsKey('custom_border_classic')) _customBorderClassic = _parseColor(map['custom_border_classic']);
    if (map.containsKey('custom_bg_comic')) _customBackgroundComic = _parseColor(map['custom_bg_comic']);
    if (map.containsKey('custom_surface_comic')) _customSurfaceComic = _parseColor(map['custom_surface_comic']);
    if (map.containsKey('custom_border_comic')) _customBorderComic = _parseColor(map['custom_border_comic']);
    // Older saves stored the paper colour as the card colour too; cards are
    // derived (paper2) now, so drop that duplicate override.
    if (_customSurfaceComic != null && _customSurfaceComic == _customBackgroundComic) {
      _customSurfaceComic = null;
    }
    final bg = map['background_id']?.toString();
    if (bg != null && DragonBackgroundPresets.all.any((p) => p.id == bg)) {
      _backgroundId = bg;
      final selectedBg = DragonBackgroundPresets.get(bg);
      _backgroundThemeMode = !_comic3D && '${map['preset_id'] ?? ''}'.startsWith('background_');
      if (_backgroundThemeMode) {
        _primary = selectedBg.themePrimary ?? selectedBg.glow;
        _secondary = selectedBg.themeSecondary ?? selectedBg.b;
        _presetName = selectedBg.name;
        _gradient = true;
      }
    }
    _syncRuntimePalette();
    if (notify) notifyListeners();
  }

  void _syncRuntimePalette() {
    currentPrimary = _primary;
    currentSecondary = _secondary;
  }

  Color? _parseColor(dynamic value) {
    if (value is! String) return null;
    var hex = value.trim().replaceFirst('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    if (hex.length != 8) return null;
    final n = int.tryParse(hex, radix: 16);
    return n == null ? null : Color(n);
  }

  Future<void> _saveLocal() async {
    final prefs = await SharedPreferences.getInstance();
    final json = jsonEncode(_toMap());
    // Device-wide fallback: always saved, so the theme sticks even on
    // screens reached before a user is logged in.
    await prefs.setString(_deviceKey, json);
    if (_username.isNotEmpty) {
      await prefs.setString('app_theme_$_username', json);
    }
  }

  Future<void> _saveRemote() async {
    if (_sessionKey.isEmpty) return;
    try {
      await http.post(
        Uri.parse('$baseUrl/api/user/theme'),
        headers: const {'Content-Type': 'application/json'},
        body: jsonEncode({
          'session_key': _sessionKey,
          'theme': _toMap(),
        }),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  LinearGradient get accentGradient => LinearGradient(
    colors: [_primary, _secondary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  void cycle() {
    final list = activePresets;
    final index = list.indexWhere((p) => p.id == _presetId);
    select(list[(index + 1) % list.length]);
  }
}
