import 'dart:async';
import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'api_config.dart';
import 'verified_badge.dart';

class RoomChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  final Map<String,dynamic> room;
  const RoomChatPage({super.key, required this.username, required this.sessionKey, required this.room});
  @override State<RoomChatPage> createState()=>_RoomChatPageState();
}

class _RoomChatPageState extends State<RoomChatPage> {
  final ctrl=TextEditingController();
  final scroll=ScrollController();
  List<Map<String,dynamic>> messages=[];
  io.Socket? socket;
  bool loading=true,sending=false;
  Map<String,dynamic>? reply;


  String get roomId=>(widget.room['id']??'').toString();
  String get type=>(widget.room['type']??'group').toString();
  String get title=>(widget.room['name']??'Room').toString();
  bool get isChannel=>type=='channel';
  bool get isManager=>widget.room['owner']==widget.username || ((widget.room['admins'] is List) && (widget.room['admins'] as List).map((e)=>e.toString()).contains(widget.username));

  @override void initState(){super.initState();_load();_connect();}
  @override void dispose(){socket?.emit('room:leave',{'room_id':roomId});socket?.disconnect();socket?.dispose();ctrl.dispose();scroll.dispose();super.dispose();}

  Uri _u(String path,[Map<String,String>? q])=>Uri.parse('$baseUrl$path').replace(queryParameters:q);
  Future<void> _load({bool silent=false}) async{
    try{
      final r=await http.get(_u('/api/chat/room/messages',{'session_key':widget.sessionKey,'room_id':roomId})).timeout(const Duration(seconds:10));
      if(r.statusCode==200){
        final b=jsonDecode(r.body); final list=(b['messages'] is List?b['messages']:[]).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList();
        if(mounted)setState(()=>messages=list);
        if(!silent)WidgetsBinding.instance.addPostFrameCallback((_)=>_bottom());
      }
    }catch(_){}
    if(mounted&&!silent)setState(()=>loading=false);
  }
  void _connect(){
    socket=io.io(baseUrl,io.OptionBuilder().setTransports(['websocket']).disableAutoConnect().build());
    socket!.onConnect((_){socket!.emit('private:auth',{'session_key':widget.sessionKey});});
    socket!.on('private:auth:ok',(_)=>socket!.emit('room:join',{'room_id':roomId}));
    socket!.on('room:message',(d){if(d is Map&&d['message'] is Map){final m=Map<String,dynamic>.from(d['message']);if(m['room_id']==roomId){setState((){if(!messages.any((x)=>x['id']==m['id']))messages.add(m);});_bottom();}}});
    socket!.on('room:message:reaction',(d){if(d is Map&&d['message'] is Map){final m=Map<String,dynamic>.from(d['message']);if(m['room_id']==roomId){setState(()=>messages=[for(final x in messages) x['id']==m['id']?m:x]);}}});
    socket!.on('room:message:edited',(d){if(d is Map&&d['message'] is Map){final m=Map<String,dynamic>.from(d['message']);if(m['room_id']==roomId&&mounted)setState(()=>messages=[for(final x in messages)x['id']==m['id']?m:x]);}});
    socket!.on('room:message:deleted',(d){if(d is Map&&mounted){final id='${d['id']??''}';setState(()=>messages=messages.where((x)=>'${x['id']??''}'!=id).toList());}});
    socket!.on('room:updated',(d){if(d is Map&&d['room'] is Map&&mounted)setState((){});});
    socket!.connect();
  }
  void _bottom(){if(!scroll.hasClients)return;Future.delayed(const Duration(milliseconds:80),()=>scroll.animateTo(scroll.position.maxScrollExtent,duration:const Duration(milliseconds:220),curve:Curves.easeOut));}
  Future<void> _send()async{
    final text=ctrl.text.trim();if(text.isEmpty||sending)return;
    setState(()=>sending=true);
    try{
      final r=await http.post(_u('/api/chat/room/send'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId,'message':text,...(reply==null?{}:{'reply_to':reply!['id']})})).timeout(const Duration(seconds:15));
      if(r.statusCode>=200&&r.statusCode<300){ctrl.clear();setState(()=>reply=null);await _load();}
      else if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Pesan gagal dikirim')));
    }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Server tidak terhubung')));}
    if(mounted)setState(()=>sending=false);
  }
  Future<void> _pickFile() async {
    final p=await FilePicker.platform.pickFiles(withData:false);
    if(p==null||p.files.single.path==null)return;
    final f=p.files.single;
    final req=http.MultipartRequest('POST',_u('/api/chat/room/upload'));
    req.fields['session_key']=widget.sessionKey; req.fields['room_id']=roomId;
    req.files.add(await http.MultipartFile.fromPath('media',f.path!,filename:f.name));
    try { final r=await req.send().timeout(const Duration(seconds:30)); if(r.statusCode>=200&&r.statusCode<300){await _load();} else if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Upload gagal'))); } catch(_){ if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Upload gagal'))); }
  }
  Future<void> _editMessage(Map<String,dynamic> m) async {
    final c=TextEditingController(text:(m['message']??'').toString());
    final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(backgroundColor:const Color(0xFF111B21),title:const Text('Edit pesan',style:TextStyle(color:Colors.white)),content:TextField(controller:c,style:const TextStyle(color:Colors.white),maxLines:4),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('Simpan'))]));
    if(ok==true&&c.text.trim().isNotEmpty){await http.post(_u('/api/chat/room/edit'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId,'id':m['id'],'message':c.text.trim()}));await _load();} c.dispose();
  }
  Future<void> _deleteMessage(Map<String,dynamic> m) async { await http.post(_u('/api/chat/room/delete'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId,'id':m['id']})); await _load(); }
  Future<void> _leaveRoom() async { final r=await http.post(_u('/api/chat/room/leave'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId})); if(r.statusCode>=200&&r.statusCode<300&&mounted)Navigator.pop(context); else if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Tidak bisa keluar dari room'))); }
  Future<void> _openMedia(Map<String,dynamic> m) async { final u=(m['media_url']??'').toString(); if(u.isNotEmpty)await launchUrl(Uri.parse(u),mode:LaunchMode.externalApplication); }

  Future<void> _react(Map<String,dynamic> m,String emoji)async{
    try{await http.post(_u('/api/chat/room/reaction'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId,'id':m['id'],'reaction':emoji}));}catch(_){}
  }
  void _actions(Map<String,dynamic> m){
    showModalBottomSheet(context:context,backgroundColor:const Color(0xFF111B21),builder:(c)=>SafeArea(child:Wrap(children:[ Padding(
  padding: const EdgeInsets.all(12),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: ['❤️','😂','👍','😮','😢','🔥'].map<Widget>((e) => InkWell(
      onTap: () { Navigator.pop(c); _react(m, e); },
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Text(e, style: const TextStyle(fontSize: 25)),
      ),
    )).toList(),
  ),
),
      ListTile(leading:const Icon(Icons.reply,color:Colors.white),title:const Text('Balas',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);setState(()=>reply=m);}),
      if(m['from']==widget.username&&m['media_type']=='text')ListTile(leading:const Icon(Icons.edit,color:Colors.white),title:const Text('Edit',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_editMessage(m);}),
      if(m['from']==widget.username||isManager)ListTile(leading:const Icon(Icons.delete_outline,color:Colors.white),title:const Text('Hapus',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_deleteMessage(m);}),
      if(m['media_url']!=null)ListTile(leading:const Icon(Icons.open_in_new,color:Colors.white),title:const Text('Buka media',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_openMedia(m);}),
    ])));
  }
  Widget _bubble(Map<String,dynamic> m){
    final mine=m['from']==widget.username;
    final reaction=(m['reactions'] is Map)?(m['reactions'] as Map).values.isEmpty?'':(m['reactions'] as Map).values.first.toString():'';
    return GestureDetector(onLongPress:()=>_actions(m),child:Align(alignment:mine?Alignment.centerRight:Alignment.centerLeft,child:Container(
      constraints:const BoxConstraints(maxWidth:330),margin:const EdgeInsets.symmetric(horizontal:10,vertical:3),
      padding:const EdgeInsets.fromLTRB(12,8,10,7),
      decoration:BoxDecoration(color:mine?const Color(0xFF005C4B):const Color(0xFF202C33),borderRadius:BorderRadius.only(topLeft:const Radius.circular(15),topRight:const Radius.circular(15),bottomLeft:Radius.circular(mine?15:4),bottomRight:Radius.circular(mine?4:15))),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        if(!mine)Row(mainAxisSize:MainAxisSize.min,children:[Flexible(child:Text((m['display_name']??m['from']??'').toString(),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Color(0xFF53BDEB),fontSize:12,fontWeight:FontWeight.w800))),if(m['verified']==true)...[const SizedBox(width:4),const BlueVerifiedBadge(size:14)]]),
        if(m['reply_preview'] is Map)Container(margin:const EdgeInsets.only(bottom:5),padding:const EdgeInsets.all(7),decoration:BoxDecoration(color:Colors.black12,border:const Border(left:BorderSide(color:Color(0xFF00A884),width:3)),borderRadius:BorderRadius.circular(5)),child:Text((m['reply_preview']['message']??'').toString(),maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white60,fontSize:11))),
        if((m['media_url']??'').toString().isNotEmpty)Container(margin:const EdgeInsets.only(bottom:6),padding:const EdgeInsets.all(9),decoration:BoxDecoration(color:Colors.black12,borderRadius:BorderRadius.circular(10)),child:Row(mainAxisSize:MainAxisSize.min,children:[Icon((m['media_type']=='image')?Icons.image_rounded:(m['media_type']=='video')?Icons.videocam_rounded:(m['media_type']=='audio')?Icons.mic_rounded:Icons.insert_drive_file_rounded,color:const Color(0xFF00A884)),const SizedBox(width:7),Flexible(child:Text((m['file_name']??'Media').toString(),style:const TextStyle(color:Colors.white),maxLines:2,overflow:TextOverflow.ellipsis))])),
        Text((m['message']??'').toString(),style:const TextStyle(color:Colors.white,fontSize:15,height:1.25)),
        Row(mainAxisSize:MainAxisSize.min,children:[if(reaction.isNotEmpty)Padding(padding:const EdgeInsets.only(top:3,right:4),child:Text(reaction)),Text(_time(m['time']??m['created_at']),style:const TextStyle(color:Colors.white54,fontSize:10))])
      ])
    )));
  }
  String _time(dynamic v){final d=DateTime.tryParse(v?.toString()??'')?.toLocal();if(d==null)return '';return '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';}

  void _roomMenu(){showModalBottomSheet(context:context,backgroundColor:const Color(0xFF111B21),builder:(c)=>SafeArea(child:Wrap(children:[ListTile(leading:const Icon(Icons.info_outline,color:Colors.white),title:const Text('Info room',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_roomInfo();}),if(isManager&&!isChannel)ListTile(leading:const Icon(Icons.person_add,color:Color(0xFF00A884)),title:const Text('Tambah anggota',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_addMember();}),if(isManager)ListTile(leading:const Icon(Icons.admin_panel_settings,color:Color(0xFF00A884)),title:const Text('Kelola anggota',style:TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_manageMembers();}),ListTile(leading:const Icon(Icons.exit_to_app,color:Colors.redAccent),title:Text(isChannel?'Berhenti mengikuti':'Keluar dari grup',style:const TextStyle(color:Colors.white)),onTap:(){Navigator.pop(c);_leaveRoom();})])));}
  void _roomInfo(){showDialog(context:context,builder:(c)=>AlertDialog(backgroundColor:const Color(0xFF111B21),title:Text(title,style:const TextStyle(color:Colors.white)),content:Text('${widget.room['description']??''}\n\n${widget.room['members_count']??0} ${isChannel?'pengikut':'anggota'}',style:const TextStyle(color:Colors.white70)),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Tutup'))]));}
  Future<void> _addMember()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(backgroundColor:const Color(0xFF111B21),title:const Text('Tambah anggota',style:TextStyle(color:Colors.white)),content:TextField(controller:c,style:const TextStyle(color:Colors.white),decoration:const InputDecoration(hintText:'Username')),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(x,c.text.trim().isNotEmpty),child:const Text('Tambah'))]));if(ok==true)await http.post(_u('/api/chat/room/add-member'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId,'username':c.text.trim()}));c.dispose();}
  Future<void> _manageMembers()async{final list=((widget.room['members'] as List?)??const[]).map((e)=>e.toString()).where((e)=>e!=widget.room['owner']).toList();showModalBottomSheet(context:context,backgroundColor:const Color(0xFF111B21),builder:(c)=>ListView(shrinkWrap:true,children:list.map((u)=>ListTile(title:Text(u,style:const TextStyle(color:Colors.white)),trailing:IconButton(icon:const Icon(Icons.remove_circle_outline,color:Colors.redAccent),onPressed:()async{Navigator.pop(c);await http.post(_u('/api/chat/room/remove-member'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'room_id':roomId,'username':u}));}))).toList()));}

  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:const Color(0xFF080D10),
    appBar:AppBar(backgroundColor:const Color(0xFF111B21),foregroundColor:Colors.white,titleSpacing:0,elevation:0,title:Row(children:[
      CircleAvatar(backgroundColor:const Color(0xFF00A884),child:Icon(isChannel?Icons.campaign_rounded:Icons.groups_rounded,color:Colors.white)),
      const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(title,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w800)),
        Text('${widget.room['members_count']??0} ${isChannel?'pengikut':'anggota'}',style:const TextStyle(fontSize:11,color:Colors.white54))
      ])),
    ]),actions:[IconButton(onPressed:_roomMenu,icon:const Icon(Icons.more_vert_rounded))]),
    body:Column(children:[
      Expanded(child:loading?const Center(child:CircularProgressIndicator()):messages.isEmpty?const Center(child:Text('Belum ada pesan',style:TextStyle(color:Colors.white38))):ListView.builder(controller:scroll,padding:const EdgeInsets.symmetric(vertical:10),itemCount:messages.length,itemBuilder:(_,i)=>_bubble(messages[i]))),
      if(reply!=null)Container(color:const Color(0xFF111B21),padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),child:Row(children:[const Icon(Icons.reply,color:Color(0xFF00A884)),const SizedBox(width:8),Expanded(child:Text((reply!['message']??'').toString(),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70))),IconButton(onPressed:()=>setState(()=>reply=null),icon:const Icon(Icons.close,color:Colors.white54))])),
      if(isChannel&&!isManager)Container(padding:const EdgeInsets.all(12),child:const Text('Hanya admin saluran yang dapat mengirim pesan',style:TextStyle(color:Colors.white38))),
      if(!isChannel||isManager)SafeArea(top:false,child:Container(padding:const EdgeInsets.fromLTRB(8,7,8,8),color:const Color(0xFF111B21),child:Row(children:[
        IconButton(onPressed: _emoji, icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white54)),
        IconButton(onPressed: _pickFile, icon: const Icon(Icons.attach_file_rounded, color: Colors.white54)),
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1B272D),
              borderRadius: BorderRadius.circular(22),
            ),
            child: TextField(
              controller: ctrl,
              style: const TextStyle(color: Colors.white),
              minLines: 1,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: 'Ketik pesan',
                hintStyle: TextStyle(color: Colors.white38),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),
        ),
        const SizedBox(width: 5),
        CircleAvatar(
          backgroundColor: const Color(0xFF00A884),
          child: IconButton(
            onPressed: sending ? null : _send,
            icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
          ),
        ),
      ])))
    ])
  );
  void _emoji(){final e=['😀','😂','😍','🔥','👍','❤️','😎','😭','😮','🎉'];showModalBottomSheet(context:context,backgroundColor:const Color(0xFF111B21),builder:(c)=>GridView.count(crossAxisCount:5,shrinkWrap:true,children:e.map((x)=>IconButton(onPressed:(){ctrl.text+=x;Navigator.pop(c);},icon:Text(x,style:const TextStyle(fontSize:28)))).toList()));}
}
