import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart' as home;
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'global_music_overlay.dart';
import 'theme_settings_page.dart';
import 'app_background.dart';
import 'global_anime_atmosphere.dart';
import 'comic_theme.dart';
import 'api_config.dart';

// ─────────────────────────────────────────────
//  COLOR SYSTEM
// ─────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF050A12);
  static const surface   = Color(0xFF0A1525);
  static const card      = Color(0xFF0E1E35);
  static const border    = Color(0xFF162B4A);
  static const borderLit = Color(0xFF1E3F6E);

  static const steel     = Color(0xFF1A4F8A);
  static const blueMid   = Color(0xFF2370BE);
  static const blueLight = Color(0xFF4A94E8);
  static const chrome    = Color(0xFF7AB4E8);
  static const frost     = Color(0xFFADD4F5);

  static const green     = Color(0xFF22C55E);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFFEF4444);

  static const text      = Color(0xFFDEEEFB);
  static const textSub   = Color(0xFF6A92B8);
  static const textDim   = Color(0xFF2E4E6E);

  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFF1A3A6A), Color(0xFF2B6CB0), Color(0xFF4A94E8)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient surfaceGrad = LinearGradient(
    colors: [Color(0xFF0A1525), Color(0xFF0E1E35)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF050A12), Color(0xFF0A1525)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

// ─────────────────────────────────────────────
//  THEME BUILDER
// ─────────────────────────────────────────────
class _AppTheme {
  static String get _font => ThemeProvider.isComic3D ? 'Poppins' : 'ShareTechMono';

  static ThemeData build(Color primary, Color secondary) {
    final bg = ThemeProvider.background;
    final surface = ThemeProvider.surface;
    final card = ThemeProvider.card;
    final border = ThemeProvider.border;
    final text = ThemeProvider.text;
    final textSub = ThemeProvider.textSub;
    final frost = ThemeProvider.frost;
    final comic = ThemeProvider.isComic3D;
    final textDim = textSub.withOpacity(0.62);
    final borderLit = comic ? ThemeProvider.comicInk : Color.lerp(border, primary, 0.45)!;
    final radius = comic ? 18.0 : 12.0;
    return ThemeData(
    useMaterial3: true,
    brightness: ThemeProvider.isLightPalette ? Brightness.light : Brightness.dark,
    fontFamily: _font,
    scaffoldBackgroundColor: bg,

    // ── Color Scheme ──────────────────────────
    colorScheme: comic
        ? ColorScheme.light(
            primary: primary,
            onPrimary: ThemeProvider.comicOnPrimary,
            primaryContainer: secondary,
            onPrimaryContainer: ThemeProvider.comicOnAccent,
            secondary: secondary,
            onSecondary: ThemeProvider.comicOnAccent,
            // .wish:nth-child(odd) -> color-mix(yellow 35%, #fff)
            secondaryContainer: Color.lerp(secondary, Colors.white, .35)!,
            onSecondaryContainer: text,
            tertiary: const Color(0xFF00A86B),
            onTertiary: Colors.white,
            error: _C.red,
            onError: Colors.white,
            surface: surface,
            onSurface: text,
            surfaceContainerHighest: card,
            outline: border,
            outlineVariant: borderLit,
            shadow: Colors.black,
            scrim: Colors.black26,
            inverseSurface: text,
            onInverseSurface: bg,
            inversePrimary: secondary,
          )
        : ColorScheme.dark(
            brightness: ThemeProvider.isLightPalette ? Brightness.light : Brightness.dark,
            primary: primary,
            onPrimary: text,
            primaryContainer: secondary,
            onPrimaryContainer: frost,
            secondary: primary,
            onSecondary: text,
            secondaryContainer: borderLit,
            onSecondaryContainer: text,
            tertiary: _C.green,
            onTertiary: bg,
            error: _C.red,
            onError: text,
            surface: surface,
            onSurface: text,
            surfaceContainerHighest: card,
            outline: border,
            outlineVariant: borderLit,
            shadow: Colors.black,
            scrim: Colors.black87,
            inverseSurface: frost,
            onInverseSurface: bg,
            inversePrimary: secondary,
          ),

    // ── AppBar ────────────────────────────────
    appBarTheme: AppBarTheme(
      backgroundColor:      comic ? primary : surface,
      foregroundColor:      text,
      elevation:            0,
      scrolledUnderElevation: 0,
      centerTitle:          false,
      titleTextStyle: TextStyle(
        fontFamily:   _font,
        fontSize:     18,
        fontWeight:   FontWeight.w600,
        color:        text,
        letterSpacing: 0.4,
      ),
      iconTheme:        IconThemeData(color: primary,    size: 22),
      actionsIconTheme: IconThemeData(color: textSub,   size: 20),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor:                    Colors.transparent,
        statusBarIconBrightness:           Brightness.light,
        statusBarBrightness:               Brightness.dark,
        systemNavigationBarColor:          bg,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
    ),

    // ── Card ──────────────────────────────────
    cardTheme: CardThemeData(
      color:        card,
      elevation:    0,
      margin:       EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: border, width: 1),
      ),
      clipBehavior: Clip.antiAlias,
    ),

    // ── Elevated Button ───────────────────────
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return border;
          if (s.contains(WidgetState.pressed))  return secondary;
          return primary;
        }),
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return textDim;
          // --on-p on red, --on-a on yellow (pressed state uses the accent)
          if (comic) {
            return s.contains(WidgetState.pressed)
                ? ThemeProvider.comicOnAccent
                : ThemeProvider.comicOnPrimary;
          }
          return text;
        }),
        overlayColor:  WidgetStateProperty.all(frost.withOpacity(0.1)),
        elevation:     WidgetStateProperty.all(0),
        shadowColor:   WidgetStateProperty.all(Colors.transparent),
        padding:       WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)),
        ),
        textStyle: WidgetStateProperty.all(
          TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.8),
        ),
        animationDuration: const Duration(milliseconds: 180),
      ),
    ),

    // ── Outlined Button ───────────────────────
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return frost;
          return primary;
        }),
        side: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return BorderSide(color: primary,     width: 1.5);
          if (s.contains(WidgetState.focused)) return BorderSide(color: primary,  width: 1.5);
          return BorderSide(color: borderLit, width: 1);
        }),
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return primary.withOpacity(0.08);
          return Colors.transparent;
        }),
        overlayColor: WidgetStateProperty.all(primary.withOpacity(0.06)),
        padding:      WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)),
        ),
        textStyle: WidgetStateProperty.all(
          TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.6),
        ),
      ),
    ),

    // ── Text Button ───────────────────────────
    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return frost;
          return primary;
        }),
        overlayColor: WidgetStateProperty.all(primary.withOpacity(0.08)),
        padding:      WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        textStyle: WidgetStateProperty.all(
          TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500, letterSpacing: 0.4),
        ),
      ),
    ),

    // ── Input / TextField ─────────────────────
    inputDecorationTheme: InputDecorationTheme(
      filled:      true,
      fillColor:   surface,
      hoverColor:  card,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   BorderSide(color: border, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   BorderSide(color: border, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   BorderSide(color: primary, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   BorderSide(color: _C.red, width: 1),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   BorderSide(color: _C.red, width: 1.5),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   BorderSide(color: textDim, width: 1),
      ),
      labelStyle:          TextStyle(color: textSub,  fontSize: 13),
      hintStyle:           TextStyle(color: textDim,  fontSize: 13),
      errorStyle:          TextStyle(color: _C.red,      fontSize: 11),
      prefixIconColor:     textSub,
      suffixIconColor:     textSub,
      floatingLabelStyle:  TextStyle(color: primary, fontSize: 12),
    ),

    // ── Chip ──────────────────────────────────
    chipTheme: ChipThemeData(
      backgroundColor:     surface,
      selectedColor:       secondary,
      disabledColor:       border,
      deleteIconColor:     textSub,
      labelStyle:          TextStyle(color: text,  fontSize: 12, fontFamily: _font),
      secondaryLabelStyle: TextStyle(color: frost, fontSize: 12, fontFamily: _font),
      padding:             const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side:         BorderSide(color: border),
      ),
      side:            BorderSide(color: border),
      elevation:       0,
      pressElevation:  0,
      showCheckmark:   false,
    ),

    // ── Bottom Navigation Bar ─────────────────
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor:      surface,
      selectedItemColor:    primary,
      unselectedItemColor:  textDim,
      elevation:            0,
      type:                 BottomNavigationBarType.fixed,
      selectedLabelStyle:   TextStyle(fontSize: 10, fontFamily: _font, fontWeight: FontWeight.w600),
      unselectedLabelStyle: TextStyle(fontSize: 10, fontFamily: _font),
    ),

    // ── Navigation Bar (M3) ───────────────────
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor:  surface,
      indicatorColor:   secondary.withOpacity(0.45),
      iconTheme: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return IconThemeData(color: primary, size: 22);
        return IconThemeData(color: textDim, size: 22);
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) {
          return TextStyle(color: primary, fontSize: 11, fontFamily: _font, fontWeight: FontWeight.w600);
        }
        return TextStyle(color: textDim, fontSize: 11, fontFamily: _font);
      }),
      elevation:     0,
      overlayColor:  WidgetStateProperty.all(primary.withOpacity(0.06)),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    ),

    // ── Navigation Rail ───────────────────────
    navigationRailTheme: NavigationRailThemeData(
      backgroundColor:            surface,
      selectedIconTheme:          IconThemeData(color: primary, size: 22),
      unselectedIconTheme:        IconThemeData(color: textDim,   size: 22),
      selectedLabelTextStyle:     TextStyle(color: primary, fontSize: 11, fontFamily: _font, fontWeight: FontWeight.w600),
      unselectedLabelTextStyle:   TextStyle(color: textDim,   fontSize: 11, fontFamily: _font),
      indicatorColor:             secondary.withOpacity(0.4),
      elevation:                  0,
      useIndicator:               true,
    ),

    // ── Drawer ────────────────────────────────
    drawerTheme: DrawerThemeData(
      backgroundColor:   surface,
      elevation:         0,
      surfaceTintColor:  Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight:    Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
    ),

    // ── Dialog ────────────────────────────────
    dialogTheme: DialogThemeData(
      backgroundColor: card,
      elevation:       0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side:         BorderSide(color: borderLit, width: 1),
      ),
      titleTextStyle: TextStyle(
        fontFamily:    _font,
        fontSize:      18,
        fontWeight:    FontWeight.w700,
        color:         text,
        letterSpacing: 0.2,
      ),
      contentTextStyle: TextStyle(
        fontFamily: _font,
        fontSize:   14,
        color:      textSub,
        height:     1.6,
      ),
    ),

    // ── Bottom Sheet ──────────────────────────
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor:      surface,
      modalBackgroundColor:  surface,
      elevation:             0,
      modalElevation:        0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      showDragHandle:   true,
      dragHandleColor:  borderLit,
      dragHandleSize:   Size(40, 4),
      clipBehavior:     Clip.antiAlias,
    ),

    // ── Snack Bar ─────────────────────────────
    snackBarTheme: SnackBarThemeData(
      backgroundColor:  card,
      contentTextStyle: TextStyle(color: text, fontFamily: _font, fontSize: 13),
      actionTextColor:  primary,
      behavior:         SnackBarBehavior.floating,
      elevation:        0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side:         BorderSide(color: borderLit, width: 1),
      ),
    ),

    // ── Tab Bar ───────────────────────────────
    tabBarTheme: TabBarThemeData(
      labelColor:              primary,
      unselectedLabelColor:    textDim,
      indicatorColor:          primary,
      indicatorSize:           TabBarIndicatorSize.label,
      labelStyle:              TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w600),
      unselectedLabelStyle:    TextStyle(fontFamily: _font, fontSize: 13),
      overlayColor:            WidgetStateProperty.all(primary.withOpacity(0.06)),
      dividerColor:            border,
    ),

    // ── List Tile ─────────────────────────────
    listTileTheme: ListTileThemeData(
      tileColor:         Colors.transparent,
      selectedTileColor: Color(0x1A4A94E8),
      iconColor:         textSub,
      selectedColor:     primary,
      textColor:         text,
      subtitleTextStyle: TextStyle(color: textSub, fontSize: 12),
      contentPadding:    EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
    ),

    // ── Divider ───────────────────────────────
    dividerTheme: DividerThemeData(
      color:     border,
      thickness: 1,
      space:     1,
    ),

    // ── Switch ────────────────────────────────
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return primary;
        return textDim;
      }),
      trackColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return secondary.withOpacity(0.5);
        return border;
      }),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      overlayColor:      WidgetStateProperty.all(primary.withOpacity(0.08)),
    ),

    // ── Checkbox ──────────────────────────────
    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return primary;
        return Colors.transparent;
      }),
      checkColor:   WidgetStateProperty.all(bg),
      side:         BorderSide(color: borderLit, width: 1.5),
      shape:        RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      overlayColor: WidgetStateProperty.all(primary.withOpacity(0.08)),
    ),

    // ── Radio ─────────────────────────────────
    radioTheme: RadioThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return primary;
        return textDim;
      }),
      overlayColor: WidgetStateProperty.all(primary.withOpacity(0.08)),
    ),

    // ── Slider ────────────────────────────────
    sliderTheme: SliderThemeData(
      activeTrackColor:    primary,
      inactiveTrackColor:  border,
      thumbColor:          primary,
      overlayColor:        primary.withOpacity(0.12),
      valueIndicatorColor: secondary,
      valueIndicatorTextStyle: TextStyle(color: text, fontSize: 12, fontFamily: _font),
      trackHeight:         3,
      thumbShape:          const RoundSliderThumbShape(enabledThumbRadius: 7),
    ),

    // ── Progress Indicator ────────────────────
    progressIndicatorTheme: ProgressIndicatorThemeData(
      color:              primary,
      linearTrackColor:   border,
      circularTrackColor: border,
      linearMinHeight:    3,
    ),

    // ── FAB ───────────────────────────────────
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor:    primary,
      foregroundColor:    bg,
      elevation:          0,
      focusElevation:     0,
      hoverElevation:     0,
      highlightElevation: 0,
      splashColor:        frost.withOpacity(0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),

    // ── Icons ─────────────────────────────────
    iconTheme:        IconThemeData(color: primary,    size: 22),
    primaryIconTheme: IconThemeData(color: primary, size: 22),

    // ── Popup Menu ────────────────────────────
    popupMenuTheme: PopupMenuThemeData(
      color:            card,
      elevation:        0,
      shadowColor:      Colors.transparent,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side:         BorderSide(color: borderLit, width: 1),
      ),
      textStyle: TextStyle(color: text, fontFamily: _font, fontSize: 13),
      labelTextStyle: WidgetStateProperty.all(
        TextStyle(color: text, fontFamily: _font, fontSize: 13),
      ),
      iconColor: textSub,
    ),

    // ── Tooltip ───────────────────────────────
    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color:        surface,
        borderRadius: BorderRadius.circular(8),
        border:       Border.all(color: borderLit),
      ),
      textStyle: TextStyle(color: text, fontSize: 11, fontFamily: _font),
      padding:   const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    ),

    // ── Scrollbar ─────────────────────────────
    scrollbarTheme: ScrollbarThemeData(
      thumbColor:      WidgetStateProperty.all(borderLit),
      trackColor:      WidgetStateProperty.all(surface),
      radius:          const Radius.circular(4),
      thickness:       WidgetStateProperty.all(3),
      crossAxisMargin: 2,
    ),

    // ── Page Transitions ──────────────────────
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: _SteelTransitionBuilder(),
        TargetPlatform.iOS:     _SteelTransitionBuilder(),
        TargetPlatform.windows: _SteelTransitionBuilder(),
        TargetPlatform.macOS:   _SteelTransitionBuilder(),
        TargetPlatform.linux:   _SteelTransitionBuilder(),
      },
    ),

    // ── Text Theme ────────────────────────────
    textTheme: TextTheme(
      displayLarge:   TextStyle(fontFamily: _font, fontSize: 57, fontWeight: FontWeight.w800, color: text, letterSpacing: -1.5),
      displayMedium:  TextStyle(fontFamily: _font, fontSize: 45, fontWeight: FontWeight.w700, color: text, letterSpacing: -1.0),
      displaySmall:   TextStyle(fontFamily: _font, fontSize: 36, fontWeight: FontWeight.w700, color: text, letterSpacing: -0.5),
      headlineLarge:  TextStyle(fontFamily: _font, fontSize: 32, fontWeight: FontWeight.w700, color: text, letterSpacing: -0.3),
      headlineMedium: TextStyle(fontFamily: _font, fontSize: 26, fontWeight: FontWeight.w600, color: text, letterSpacing: -0.2),
      headlineSmall:  TextStyle(fontFamily: _font, fontSize: 22, fontWeight: FontWeight.w600, color: text),
      titleLarge:     TextStyle(fontFamily: _font, fontSize: 18, fontWeight: FontWeight.w600, color: text, letterSpacing:  0.2),
      titleMedium:    TextStyle(fontFamily: _font, fontSize: 15, fontWeight: FontWeight.w500, color: text, letterSpacing:  0.1),
      titleSmall:     TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500, color: textSub),
      bodyLarge:      TextStyle(fontFamily: _font, fontSize: 16, fontWeight: FontWeight.w400, color: text,    height: 1.6),
      bodyMedium:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w400, color: text,    height: 1.6),
      bodySmall:      TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w400, color: textSub, height: 1.5),
      labelLarge:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, color: text,    letterSpacing: 0.5),
      labelMedium:    TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w500, color: textSub, letterSpacing: 0.4),
      labelSmall:     TextStyle(fontFamily: _font, fontSize: 10, fontWeight: FontWeight.w500, color: textDim, letterSpacing: 0.6),
    ),  );
  }
}

// ─────────────────────────────────────────────
//  CUSTOM PAGE TRANSITION — Steel Fade + Slide
// ─────────────────────────────────────────────
class _SteelTransitionBuilder extends PageTransitionsBuilder {
  const _SteelTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(parent: animation,          curve: Curves.easeOutCubic);
    final outCurve = CurvedAnimation(parent: secondaryAnimation,  curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.035),
          end:   Offset.zero,
        ).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ROUTE BUILDER
// ─────────────────────────────────────────────
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;

  switch (settings.name) {
    case '/':
      page = LandingPage();

    case '/login':
      page = const LoginPage();

    case '/dashboard':
      page = DashboardPage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        sessionKey:  args['key']         as String,
        expiredDate: args['expiredDate'] as String,
        uid: (args['uid'] ?? '') as String,
        listBug:  List<Map<String, dynamic>>.from(args['listBug']  ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news:     List<Map<String, dynamic>>.from(args['news']     ?? []),
      );

    case '/home':
      page = home.HomePage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey:  args['sessionKey']  as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );

    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);

    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);

    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );

    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration:        const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(parent: animation,         curve: Curves.easeOutCubic);
      final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);

      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.035),
            end:   Offset.zero,
          ).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ─────────────────────────────────────────────
//  404 PAGE
// ─────────────────────────────────────────────
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();

    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Glowing icon container
                  AnimatedBuilder(
                    animation: _glow,
                    builder: (_, child) => Container(
                      width: 88, height: 88,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.surface,
                        border: Border.all(color: _C.borderLit, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color:        _C.blueLight.withOpacity(0.18 * _glow.value),
                            blurRadius:   40,
                            spreadRadius: 6,
                          ),
                        ],
                      ),
                      child: child,
                    ),
                    child: Icon(Icons.explore_off_rounded, color: _C.textSub, size: 34),
                  ),

                  const SizedBox(height: 28),

                  // 404 text
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [_C.textDim, _C.borderLit],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text(
                      '404',
                      style: TextStyle(
                        fontFamily:    'ShareTechMono',
                        fontSize:      72,
                        fontWeight:    FontWeight.w800,
                        color:         Colors.white,
                        height:        1,
                        letterSpacing: -3,
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  Text(
                    'Route not found',
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize:   16,
                      fontWeight: FontWeight.w600,
                      color:      _C.textSub,
                      letterSpacing: 0.3,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color:        _C.surface,
                      borderRadius: BorderRadius.circular(6),
                      border:       Border.all(color: _C.border),
                    ),
                    child: Text(
                      '"${widget.routeName}"',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize:   12,
                        color:      _C.textDim,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),

                  const SizedBox(height: 36),

                  OutlinedButton.icon(
                    onPressed: () =>
                        Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false),
                    icon:  const Icon(Icons.arrow_back_rounded, size: 16),
                    label: const Text('Back to Home'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Ambil domain server terbaru dari GitHub (lihat lib/api_config.dart).
  // Kalau gagal/offline, tetap lanjut pakai domain fallback.
  await loadBaseUrl();

  // Transparent overlays with correct brightness
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:                    Colors.transparent,
    statusBarIconBrightness:           Brightness.light,
    statusBarBrightness:               Brightness.dark,
    systemNavigationBarColor:          _C.bg,
    systemNavigationBarDividerColor:   Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  // Lock to portrait (remove if landscape is needed)
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Restore the last-saved theme (style + colors + background) before the
  // very first frame, so splash/landing/login already show it instead of
  // reverting to the default until after login.
  final themeProvider = ThemeProvider();
  await themeProvider.loadDeviceLocal();

  runApp(
    ChangeNotifierProvider<ThemeProvider>.value(
      value: themeProvider,
      child: const _OrcaApp(),
    ),
  );
}

// ─────────────────────────────────────────────
//  ROOT APP WIDGET
// ─────────────────────────────────────────────
class _OrcaApp extends StatelessWidget {
  const _OrcaApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title:           'DARK LIGHT X BMW',
      theme:           _AppTheme.build(
        context.watch<ThemeProvider>().dxPrimary,
        context.watch<ThemeProvider>().dxSecondary,
      ),
      initialRoute:    '/',
      onGenerateRoute: _generateRoute,

      // Global builder: clamp text scale & inject system-bar color
      builder: (context, child) {
        // Keep text scale within readable bounds
        final mq = MediaQuery.of(context);
        return ValueListenableBuilder<int>(
          valueListenable: ThemeProvider.ownThemeDepth,
          builder: (context, ownThemeDepth, _) {
            // Pages like TikTok and Chat ship their own fixed theme: while
            // one of them is active, skip the global tint/comic/anime skin
            // entirely so it can never bleed into their own colors.
            final suppressGlobalSkin = ownThemeDepth > 0;
            final page = (!suppressGlobalSkin &&
                    ThemeProvider.needsGlobalTint &&
                    !ThemeProvider.backgroundThemeMode)
                ? ColorFiltered(
                    colorFilter: ThemeProvider.globalColorFilter,
                    child: child ?? const SizedBox.shrink(),
                  )
                : (child ?? const SizedBox.shrink());
            final themedPage = suppressGlobalSkin
                ? page
                : (ThemeProvider.isComic3D
                    ? ComicThemeAtmosphere(child: page)
                    : (ThemeProvider.backgroundThemeMode
                        ? GlobalAnimeAtmosphere(
                            presetId: context.watch<ThemeProvider>().backgroundId,
                            child: page,
                          )
                        : page));
            return MediaQuery(
              data: mq.copyWith(
                textScaler: TextScaler.linear(
                  mq.textScaleFactor.clamp(0.85, 1.2),
                ),
              ),
              child: GlobalMusicOverlay(child: themedPage),
            );
          },
        );
      },
    );
  }
}