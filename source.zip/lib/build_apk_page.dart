import 'dart:async';
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'api_config.dart';

class BuildApkPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const BuildApkPage({super.key, required this.sessionKey, required this.username});

  @override
  State<BuildApkPage> createState() => _BuildApkPageState();
}

class _BuildApkPageState extends State<BuildApkPage> {
  PlatformFile? _project;
  final _name = TextEditingController(text: 'DARKLIGHT_APP');
  final _version = TextEditingController(text: '1.0.0');
  bool _release = true;
  String _artifact = 'apk';
  bool _busy = false;
  bool _checking = false;
  bool _preflighting = false;
  Map<String, dynamic>? _preflight;
  String? _testingWorker;
  String? _installingWorker;
  String? _jobId;
  Map<String, dynamic>? _job;
  List<Map<String, dynamic>> _servers = [];
  List<Map<String, dynamic>> _history = [];
  String? _selectedServer;
  String _projectStatus = 'Belum ada project yang dicek';
  Map<String, dynamic>? _projectInfo;
  Timer? _timer;

  Color get _green => const Color(0xFF25D366);
  Color get _bg => const Color(0xFF080D0C);
  Color get _cardColor => const Color(0xFF111917);
  Color get _border => const Color(0xFF25312D);

  @override
  void initState() {
    super.initState();
    _loadBuildServer();
    _loadHistory();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _name.dispose();
    _version.dispose();
    super.dispose();
  }

  Map<String, String> get _headers => {'Content-Type': 'application/json'};
  String _key() => Uri.encodeQueryComponent(widget.sessionKey);

  Future<void> _loadBuildServer() async {
    try {
      final r = await http.get(Uri.parse('$baseUrl/api/build-workers?key=${_key()}'));
      if (r.statusCode != 200) throw Exception();
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      final raw = data['workers'];
      final workers = raw is List ? raw.whereType<Map>().map((e) {
        final m = Map<String, dynamic>.from(e);
        final h = m['health'] is Map ? Map<String, dynamic>.from(m['health']) : <String,dynamic>{};
        m['online'] = h['online'] == true;
        m['healthy'] = h['healthy'] == true;
        m['queue'] = h['queue'] ?? 0;
        m['error'] = h['error'];
        m['free_mb'] = h['free_mb'];
        m['flutter'] = h['flutter'];
        m['java'] = h['java'];
        return m;
      }).toList() : <Map<String, dynamic>>[];
      if (!mounted) return;
      setState(() {
        _servers = workers;
        final selected = workers.firstWhere((x) => x['selected'] == true, orElse: () => <String,dynamic>{});
        _selectedServer = selected['host']?.toString();
      });
    } catch (_) {
      if (mounted) _toast('Build server belum bisa dimuat');
    }
  }

  Future<void> _selectServer(String host) async {
    try {
      final r = await http.post(Uri.parse('$baseUrl/api/build-servers/select'), headers: _headers,
          body: jsonEncode({'key': widget.sessionKey, 'host': host}));
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      if (r.statusCode >= 400 || data['valid'] != true) throw Exception(data['message'] ?? 'Gagal memilih server');
      setState(() => _selectedServer = host);
      _toast('Build server aktif: $host');
      _loadBuildServer();
    } catch (e) {
      _toast(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _loadHistory() async {
    try {
      final r = await http.get(Uri.parse('$baseUrl/api/build-history?key=${_key()}'));
      if (r.statusCode != 200) return;
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      final raw = data['jobs'];
      if (!mounted || raw is! List) return;
      setState(() => _history = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList());
    } catch (_) {}
  }

  Future<void> _pickProject() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip'], withData: false);
    if (result == null || result.files.single.path == null) return;
    setState(() {
      _project = result.files.single;
      _projectInfo = null;
      _preflight = null;
      _projectStatus = 'ZIP dipilih — siap dicek';
    });
  }

  Future<void> _checkProject() async {
    final file = _project;
    if (file?.path == null) return _toast('Pilih ZIP project dulu');
    setState(() {
      _checking = true;
      _projectStatus = 'Memeriksa project...';
    });
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/build/check'));
      req.fields['key'] = widget.sessionKey;
      req.files.add(await http.MultipartFile.fromPath('project', file!.path!));
      final r = await req.send();
      final body = await r.stream.bytesToString();
      final data = jsonDecode(body) as Map<String, dynamic>;
      if (r.statusCode >= 400 || data['valid'] != true) throw Exception(data['message'] ?? 'Project check gagal');
      if (!mounted) return;
      setState(() {
        _projectInfo = data['project'] is Map ? Map<String, dynamic>.from(data['project']) : null;
        _projectStatus = data['message']?.toString() ?? 'Project siap';
        final n = _projectInfo?['name']?.toString();
        final v = _projectInfo?['version']?.toString();
        if (n != null && n.isNotEmpty && _name.text == 'DEY_APP') _name.text = n;
        if (v != null && v.isNotEmpty && _version.text == '1.0.0') _version.text = v.split('+').first;
      });
    } catch (e) {
      if (mounted) setState(() => _projectStatus = 'Check gagal');
      _toast(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<bool> _runPreflight() async {
    final file = _project;
    if (file?.path == null) return false;
    setState(() { _preflighting = true; _projectStatus = 'Menjalankan preflight + cek worker VPS...'; });
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/build/preflight'));
      req.fields['key'] = widget.sessionKey;
      req.files.add(await http.MultipartFile.fromPath('project', file!.path!));
      final r = await req.send();
      final body = await r.stream.bytesToString();
      final data = jsonDecode(body) as Map<String, dynamic>;
      if (mounted) setState(() { _preflight = data; _preflighting = false; });
      if (r.statusCode >= 400 || data['ready'] != true) {
        _toast(data['message']?.toString() ?? 'Preflight gagal');
        return false;
      }
      final server = data['selected_server']?.toString();
      if (mounted) {
        setState(() {
          _selectedServer = server ?? _selectedServer;
          _projectStatus = data['message']?.toString() ?? 'Preflight OK';
        });
      }
      await _loadBuildServer();
      return true;
    } catch (e) {
      if (mounted) { setState(() { _preflighting = false; _preflight = {'ready': false}; _projectStatus = 'Preflight gagal'; }); }
      _toast(e.toString().replaceFirst('Exception: ', ''));
      return false;
    }
  }

  Future<void> _installWorker(String host) async {
    if (_installingWorker != null) return;
    setState(() => _installingWorker = host);
    try {
      final r = await http.post(
        Uri.parse('$baseUrl/api/build-workers/bootstrap'),
        headers: _headers,
        body: jsonEncode({'key': widget.sessionKey, 'host': host}),
      );
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      final ok = data['ready'] == true || data['valid'] == true;
      if (mounted) {
        setState(() => _installingWorker = null);
      }
      _toast(data['message']?.toString() ?? (ok ? 'Worker berhasil disiapkan' : 'Install worker gagal'));
      await _loadBuildServer();
    } catch (e) {
      if (mounted) setState(() => _installingWorker = null);
      _toast(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _testWorker(String host) async {
    setState(() => _testingWorker = host);
    try {
      final r = await http.post(Uri.parse('$baseUrl/api/build-workers/test'), headers: _headers, body: jsonEncode({'key': widget.sessionKey, 'host': host}));
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      final health = data['health'] is Map ? Map<String, dynamic>.from(data['health']) : <String,dynamic>{};
      _toast(data['message']?.toString() ?? (data['valid'] == true ? 'Worker READY' : 'Worker belum siap'));
      if (mounted) setState(() { _testingWorker = null; });
      await _loadBuildServer();
    } catch (e) {
      if (mounted) setState(() => _testingWorker = null);
      _toast(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _startBuild() async {
    final file = _project;
    if (file?.path == null) return _toast('Pilih ZIP project Flutter dulu');
    if (_projectInfo == null) {
      await _checkProject();
      if (_projectInfo == null) return;
    }
    if (_preflight?['ready'] != true) {
      final ready = await _runPreflight();
      if (!ready) return;
    }
    final appName = _name.text.trim();
    final version = _version.text.trim();
    if (appName.isEmpty || version.isEmpty) return _toast('Nama dan versi wajib diisi');
    setState(() {
      _busy = true;
      _job = {'status': 'uploading', 'progress': 3, 'message': 'Mengupload project...'};
    });
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/build'));
      req.fields.addAll({
        'key': widget.sessionKey,
        'username': widget.username,
        'app_name': appName,
        'version': version,
        'build_type': _release ? 'release' : 'debug',
        'artifact': _artifact,
      });
      req.files.add(await http.MultipartFile.fromPath('project', file!.path!));
      final response = await req.send();
      final body = await response.stream.bytesToString();
      final data = jsonDecode(body) as Map<String, dynamic>;
      if (response.statusCode >= 400 || data['valid'] != true) throw Exception(data['message'] ?? 'Build request gagal');
      _jobId = data['job_id']?.toString();
      await _loadJob();
      _startPolling();
    } catch (e) {
      if (mounted) setState(() => _busy = false);
      _toast(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  void _startPolling() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _loadJob());
  }

  Future<void> _loadJob() async {
    final id = _jobId;
    if (id == null) return;
    try {
      final r = await http.get(Uri.parse('$baseUrl/api/build/$id?key=${_key()}'));
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      if (!mounted) return;
      final next = data['job'] is Map ? Map<String, dynamic>.from(data['job']) : data;
      next['log'] = data['log']?.toString() ?? '';
      setState(() => _job = next);
      // API may report the delivery gate as available while final metadata is
      // still being persisted. Treat a real artifact as completed.
      var status = next['status']?.toString();
      final logText = next['log']?.toString() ?? '';
      final artifactReady = next['artifact_available'] == true || next['download_path'] != null;
      if (artifactReady && status != 'failed' && status != 'cancelled') {
        next['status'] = 'success';
        next['progress'] = 100;
        next['message'] = 'Build berhasil — APK tersimpan';
        status = 'success';
        setState(() => _job = Map<String, dynamic>.from(next));
      } else if (status == 'building' && RegExp(r'artifact detected|artifact ditemukan|handoff terdeteksi', caseSensitive: false).hasMatch(logText)) {
        // Never leave the UI visually frozen at 45% once the worker has announced
        // that an APK exists. The API may still be transferring it.
        next['status'] = 'packaging';
        next['progress'] = 88;
        next['message'] = 'APK sudah selesai di worker — mengambil hasil build...';
        status = 'packaging';
        setState(() => _job = Map<String, dynamic>.from(next));
      }
      if (status == 'success' || status == 'failed' || status == 'cancelled') {
        _timer?.cancel();
        setState(() => _busy = false);
        _loadHistory();
      }
    } catch (_) {}
  }

  Future<void> _download([String? id]) async {
    final jobId = id ?? _jobId;
    if (jobId == null) return;
    final uri = Uri.parse('$baseUrl/api/build/download/$jobId').replace(queryParameters: { 'key': widget.sessionKey });
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) _toast('Tidak bisa membuka link download');
  }

  void _showLog() {
    final log = _job?['log']?.toString() ?? '';
    showModalBottomSheet(
      context: context,
      backgroundColor: _cardColor,
      isScrollControlled: true,
      builder: (_) {
        return SizedBox(
          height: MediaQuery.of(context).size.height * .72,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.terminal_rounded, color: Colors.white70),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'Build Log',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close, color: Colors.white70),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: SingleChildScrollView(
                      reverse: true,
                      child: Text(
                        log.isEmpty ? 'Belum ada log...' : log,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontFamily: 'monospace',
                          fontSize: 11,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _toast(String text) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }

  Future<void> _resendTelegram(String id) async {
    try {
      final r = await http.post(Uri.parse('$baseUrl/api/build/resend/$id'), headers: _headers, body: jsonEncode({'key': widget.sessionKey}));
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      if (r.statusCode >= 400 || data['valid'] != true) throw Exception(data['message'] ?? 'Gagal kirim ulang Telegram');
      _toast(data['message']?.toString() ?? 'APK dikirim ulang ke Telegram');
    } catch (e) {
      _toast(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  String _fmtSize(dynamic value) {
    final n = value is num ? value.toDouble() : double.tryParse('$value');
    if (n == null || n <= 0) return '-';
    if (n >= 1024 * 1024 * 1024) return '${(n / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    return '${(n / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  String _fmtDuration(dynamic seconds) {
    final n = seconds is num ? seconds.toInt() : int.tryParse('$seconds');
    if (n == null || n <= 0) return '-';
    final h = n ~/ 3600; final m = (n % 3600) ~/ 60; final s = n % 60;
    if (h > 0) return '${h}j ${m.toString().padLeft(2,'0')}m';
    return '${m.toString().padLeft(2,'0')}:${s.toString().padLeft(2,'0')}';
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'success': return 'SUCCESS';
      case 'failed': return 'FAILED';
      case 'queued': return 'QUEUED';
      case 'building': return 'BUILDING';
      case 'packaging': return 'PACKAGING';
      case 'uploading': return 'UPLOADING';
      default: return status.toUpperCase();
    }
  }

  Color _statusColor(String status) {
    if (status == 'success') return const Color(0xFF22C55E);
    if (status == 'failed' || status == 'cancelled') return const Color(0xFFEF4444);
    if (status == 'queued') return const Color(0xFFF59E0B);
    if (status == 'building' || status == 'packaging' || status == 'uploading') return const Color(0xFF8B5CF6);
    return const Color(0xFF64748B);
  }

  Widget _metric(String title, String value, IconData icon, Color color, {String? sub}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: const Color(0xFF101722),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF202B3B)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 31,
              height: 31,
              decoration: BoxDecoration(
                color: color.withOpacity(.10),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 17),
            ),
            const SizedBox(height: 10),
            Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 10, fontWeight: FontWeight.w700)),
            if (sub != null) ...[
              const SizedBox(height: 3),
              Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white30, fontSize: 8)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title, IconData icon, {VoidCallback? action, String? actionText}) {
    return Row(
      children: [
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(color: const Color(0xFF7C5CFF).withOpacity(.10), borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, color: const Color(0xFF9A84FF), size: 16),
        ),
        const SizedBox(width: 9),
        Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900))),
        if (action != null)
          TextButton(onPressed: action, style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 30)), child: Text(actionText ?? 'Lihat Semua', style: const TextStyle(color: Color(0xFF9A84FF), fontSize: 10, fontWeight: FontWeight.w700))),
      ],
    );
  }

  Widget _statusChip(String status) {
    final c = _statusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(color: c.withOpacity(.10), borderRadius: BorderRadius.circular(8), border: Border.all(color: c.withOpacity(.22))),
      child: Text(_statusLabel(status), style: TextStyle(color: c, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .3)),
    );
  }

  Widget _dashboardHeader() {
    final online = _servers.where((s) => s['online'] == true).length;
    final ready = _servers.where((s) => s['healthy'] == true).length;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 15, 14, 15),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF111A29), Color(0xFF0C121C)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF202C3F)),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF7558FF), Color(0xFF3B82F6)]),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 23),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('DARG LIGH BUILD', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 3),
              Text('$ready/$online worker siap • Build APK lebih mudah', style: const TextStyle(color: Colors.white38, fontSize: 9)),
            ]),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
            decoration: BoxDecoration(color: online > 0 ? const Color(0xFF22C55E).withOpacity(.09) : const Color(0xFFEF4444).withOpacity(.09), borderRadius: BorderRadius.circular(10)),
            child: Row(children: [Icon(Icons.circle, size: 6, color: online > 0 ? const Color(0xFF22C55E) : const Color(0xFFEF4444)), const SizedBox(width: 5), Text(online > 0 ? 'ONLINE' : 'OFFLINE', style: TextStyle(color: online > 0 ? const Color(0xFF22C55E) : const Color(0xFFEF4444), fontSize: 8, fontWeight: FontWeight.w900))]),
          ),
        ],
      ),
    );
  }

  Widget _metricsRow() {
    final total = _history.length;
    final success = _history.where((j) => j['status'] == 'success').length;
    final failed = _history.where((j) => j['status'] == 'failed').length;
    final queue = _history.where((j) => ['queued', 'building', 'packaging', 'uploading'].contains(j['status'])).length;
    return Row(children: [
      _metric('Total Build', '$total', Icons.layers_rounded, const Color(0xFF60A5FA), sub: 'tersimpan'),
      const SizedBox(width: 8),
      _metric('Sukses', '$success', Icons.check_circle_rounded, const Color(0xFF22C55E), sub: total == 0 ? '0%' : '${(success * 100 / total).toStringAsFixed(0)}%'),
      const SizedBox(width: 8),
      _metric('Gagal', '$failed', Icons.error_outline_rounded, const Color(0xFFEF4444), sub: 'perlu dicek'),
      const SizedBox(width: 8),
      _metric('Queue', '$queue', Icons.schedule_rounded, const Color(0xFFF59E0B), sub: 'menunggu'),
    ]);
  }

  Widget _workerPanel() {
    final online = _servers.where((s) => s['online'] == true).length;
    final ready = _servers.where((s) => s['healthy'] == true).length;
    final active = _selectedServer ?? (_servers.isNotEmpty ? _servers.first['host']?.toString() : null);
    return _panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _sectionHeader('Worker Aktif', Icons.dns_rounded, action: _loadBuildServer, actionText: 'Refresh'),
        const SizedBox(height: 10),
        Row(children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF22C55E).withOpacity(.10), borderRadius: BorderRadius.circular(13)), child: const Icon(Icons.android_rounded, color: Color(0xFF4ADE80), size: 23)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(active ?? 'Belum ada worker', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis), Text('$ready siap • $online online', style: const TextStyle(color: Colors.white38, fontSize: 9))])),
          if (ready > 0) _statusChip('success') else _statusChip(online > 0 ? 'building' : 'failed'),
        ]),
      ]),
    );
  }

  Widget _storagePanel() {
    int totalBytes = 0;
    int success = 0;
    for (final j in _history) {
      if (j['status'] == 'success') success++;
      final n = j['file_size'];
      if (n is num) totalBytes += n.toInt();
    }
    final pct = (totalBytes / (50 * 1024 * 1024 * 1024)).clamp(0.0, 1.0);
    return _panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _sectionHeader('APK Storage', Icons.storage_rounded, action: _loadHistory, actionText: 'Refresh'),
        const SizedBox(height: 8),
        Row(children: [
          SizedBox(width: 48, height: 48, child: Stack(alignment: Alignment.center, children: [CircularProgressIndicator(value: pct, strokeWidth: 5, backgroundColor: Colors.white10, valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF8B5CF6))), Text('${(pct * 100).toStringAsFixed(0)}%', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900))])),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_fmtSize(totalBytes), style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)), Text('$success APK berhasil tersimpan', style: const TextStyle(color: Colors.white38, fontSize: 9)), const SizedBox(height: 4), Text(pct > .9 ? 'Storage hampir penuh' : 'Storage aman', style: TextStyle(color: pct > .9 ? const Color(0xFFF59E0B) : const Color(0xFF4ADE80), fontSize: 8, fontWeight: FontWeight.w700))])),
        ]),
      ]),
    );
  }

  Widget _panel({required Widget child}) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF0D151F), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF1E2A3A))), child: child);

  Widget _historyDashboard() {
    final items = _history.take(8).toList();
    return _panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _sectionHeader('Build Terbaru', Icons.history_rounded, action: _loadHistory, actionText: 'Lihat Semua'),
      const SizedBox(height: 4),
      if (items.isEmpty)
        const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Belum ada build tersimpan.', style: TextStyle(color: Colors.white38, fontSize: 10))))
      else
        ...items.map((j) {
          final id = j['job_id']?.toString();
          final st = j['status']?.toString() ?? '-';
          final name = j['app_name']?.toString() ?? 'Project';
          final ver = j['version']?.toString() ?? '-';
          final type = (j['artifact'] ?? 'apk').toString().toUpperCase();
          final available = j['artifact_available'] == true;
          return InkWell(
            onTap: () { setState(() { _job = j; _jobId = id; }); _showJobDetail(j); },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 11),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFF182231)))),
              child: Row(children: [
                Container(width: 36, height: 36, decoration: BoxDecoration(color: _statusColor(st).withOpacity(.09), borderRadius: BorderRadius.circular(11)), child: Icon(st == 'success' ? Icons.android_rounded : st == 'failed' ? Icons.error_outline_rounded : Icons.build_rounded, color: _statusColor(st), size: 18)),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text('v$ver • $type', style: const TextStyle(color: Colors.white30, fontSize: 8))])),
                _statusChip(st),
                if (available && id != null) IconButton(onPressed: () => _download(id), padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 34, minHeight: 34), icon: const Icon(Icons.download_rounded, color: Colors.white54, size: 17)),
              ]),
            ),
          );
        }),
    ]));
  }

  void _showJobDetail(Map<String, dynamic> j) {
    final id = j['job_id']?.toString();
    final st = j['status']?.toString() ?? '-';
    final hasArtifact = j['artifact_available'] == true && id != null;
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0B121C),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(18, 10, 18, 20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 38, height: 4, decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(4)))),
        const SizedBox(height: 15),
        Row(children: [const Icon(Icons.receipt_long_rounded, color: Color(0xFF9A84FF), size: 20), const SizedBox(width: 9), const Expanded(child: Text('Detail Build', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900))), _statusChip(st)]),
        const SizedBox(height: 15),
        Text(j['app_name']?.toString() ?? 'Project', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)),
        Text('Job ID: ${id ?? '-'}', style: const TextStyle(color: Colors.white30, fontSize: 9)),
        const SizedBox(height: 13),
        _detailRow('Version', j['version']?.toString() ?? '-'),
        _detailRow('Type', (j['artifact'] ?? 'apk').toString().toUpperCase()),
        _detailRow('Worker', j['build_server']?.toString() ?? '-'),
        _detailRow('Size', _fmtSize(j['file_size'])),
        _detailRow('Duration', _fmtDuration(j['duration_seconds'])),
        const SizedBox(height: 13),
        if (hasArtifact) Row(children: [Expanded(child: ElevatedButton.icon(onPressed: () => _download(id), icon: const Icon(Icons.download_rounded, size: 17), label: const Text('DOWNLOAD'), style: _primaryButton())), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: () => _resendTelegram(id), icon: const Icon(Icons.send_rounded, size: 17), label: const Text('TELEGRAM'), style: _outlineButton()))]),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () { Navigator.pop(context); if (id != null) { setState(() { _jobId = id; _job = j; }); _showLog(); } }, icon: const Icon(Icons.terminal_rounded, size: 17), label: const Text('LIHAT BUILD LOG'), style: _outlineButton())),
      ]))),
    );
  }

  Widget _detailRow(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [SizedBox(width: 82, child: Text(a, style: const TextStyle(color: Colors.white30, fontSize: 9))), Expanded(child: Text(b, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w700)))]));

  ButtonStyle _primaryButton() => ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7658FF), foregroundColor: Colors.white, elevation: 0, minimumSize: const Size(0, 45), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10));
  ButtonStyle _outlineButton() => OutlinedButton.styleFrom(foregroundColor: Colors.white70, side: const BorderSide(color: Color(0xFF263447)), minimumSize: const Size(0, 45), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10));

  Widget _quickActions() => Row(children: [Expanded(child: _quick('Build Baru', Icons.add_rounded, const Color(0xFF8B5CF6), () {})), const SizedBox(width: 8), Expanded(child: _quick('Riwayat', Icons.history_rounded, const Color(0xFF60A5FA), _loadHistory)), const SizedBox(width: 8), Expanded(child: _quick('Worker', Icons.dns_rounded, const Color(0xFF22C55E), _loadBuildServer))]);

  Widget _quick(String title, IconData icon, Color color, VoidCallback onTap) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(13), child: Container(padding: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: const Color(0xFF0D151F), borderRadius: BorderRadius.circular(13), border: Border.all(color: const Color(0xFF1E2A3A))), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: color, size: 17), const SizedBox(width: 6), Text(title, style: TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.w800))])));

  @override
  Widget build(BuildContext context) {
    final job = _job;
    final progress = ((job?['progress'] as num?)?.toDouble() ?? 0).clamp(0, 100).toDouble();
    final status = job?['status']?.toString() ?? 'idle';
    return Scaffold(
      backgroundColor: const Color(0xFF070C13),
      appBar: AppBar(
        backgroundColor: const Color(0xFF070C13),
        elevation: 0,
        toolbarHeight: 58,
        titleSpacing: 16,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Build Center', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900)), Text(widget.username, style: const TextStyle(color: Colors.white30, fontSize: 8))]),
        actions: [IconButton(onPressed: () async { await _loadBuildServer(); await _loadHistory(); }, icon: const Icon(Icons.refresh_rounded, color: Colors.white60, size: 20)), const SizedBox(width: 5)],
      ),
      body: RefreshIndicator(
        color: const Color(0xFF8B5CF6),
        backgroundColor: const Color(0xFF101722),
        onRefresh: () async { await _loadBuildServer(); await _loadHistory(); },
        child: ListView(padding: const EdgeInsets.fromLTRB(14, 2, 14, 32), children: [
          _dashboardHeader(),
          const SizedBox(height: 10),
          _metricsRow(),
          const SizedBox(height: 10),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: _workerPanel()), const SizedBox(width: 8), Expanded(child: _storagePanel())]),
          const SizedBox(height: 10),
          _projectCard(),
          const SizedBox(height: 10),
          _formCard(),
          const SizedBox(height: 10),
          _serverCard(),
          if (job != null) ...[const SizedBox(height: 10), _progressCard(progress, status)],
          const SizedBox(height: 10),
          _historyDashboard(),
          const SizedBox(height: 10),
          _quickActions(),
        ]),
      ),
    );
  }

  Widget _projectCard() => _card('Project Source', Icons.folder_zip_rounded, Column(children: [
    InkWell(onTap: _busy ? null : _pickProject, borderRadius: BorderRadius.circular(14), child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF0A111A), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF202C3D))), child: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF8B5CF6).withOpacity(.10), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.folder_zip_rounded, color: Color(0xFF9A84FF), size: 21)), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_project?.name ?? 'Pilih ZIP project Flutter', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(_project == null ? 'ZIP belum dipilih' : 'ZIP siap untuk diperiksa', style: const TextStyle(color: Colors.white30, fontSize: 8))])), const Icon(Icons.chevron_right_rounded, color: Colors.white30)]))),
    const SizedBox(height: 9),
    Row(children: [Expanded(child: Text(_projectStatus, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: _projectInfo != null ? const Color(0xFF4ADE80) : Colors.white38, fontSize: 9, height: 1.3))), const SizedBox(width: 8), OutlinedButton.icon(onPressed: (_project == null || _checking || _busy) ? null : _checkProject, icon: _checking ? const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.verified_rounded, size: 15), label: const Text('CHECK'), style: _outlineButton())]),
    if (_projectInfo != null) ...[const SizedBox(height: 9), Row(children: [_mini('Name', _projectInfo!['name']?.toString() ?? '-'), _mini('Version', _projectInfo!['version']?.toString() ?? '-'), _mini('Android', _projectInfo!['has_android'] == true ? 'YES' : 'NO')])]
  ]));

  Widget _serverCard() => _card('Worker & Preflight', Icons.dns_rounded, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    if (_servers.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 5), child: Text('Belum ada Build Worker. Tambahkan lewat /addbuildworker atau /addbuildserver di Telegram.', style: TextStyle(color: Colors.white38, fontSize: 10, height: 1.4)))
    else ..._servers.map((s) {
      final host = s['host']?.toString() ?? '-';
      final online = s['online'] == true;
      final healthy = s['healthy'] == true;
      final selected = host == _selectedServer;
      final queue = (s['queue'] as num?)?.toInt() ?? 0;
      final testing = _testingWorker == host;
      final installing = _installingWorker == host;
      final err = s['error']?.toString();
      return Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: selected ? const Color(0xFF7658FF).withOpacity(.07) : const Color(0xFF0A111A), borderRadius: BorderRadius.circular(14), border: Border.all(color: selected ? const Color(0xFF7658FF).withOpacity(.35) : const Color(0xFF1C2938))), child: Column(children: [
        Row(children: [Container(width: 36, height: 36, decoration: BoxDecoration(color: healthy ? const Color(0xFF22C55E).withOpacity(.10) : const Color(0xFF64748B).withOpacity(.10), borderRadius: BorderRadius.circular(11)), child: Icon(healthy ? Icons.cloud_done_rounded : online ? Icons.cloud_rounded : Icons.cloud_off_rounded, color: healthy ? const Color(0xFF4ADE80) : online ? const Color(0xFFF59E0B) : const Color(0xFFEF4444), size: 19)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(host, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(healthy ? 'READY' : online ? 'ONLINE • BELUM READY' : 'OFFLINE', style: TextStyle(color: healthy ? const Color(0xFF4ADE80) : online ? const Color(0xFFF59E0B) : const Color(0xFFEF4444), fontSize: 8, fontWeight: FontWeight.w800))])), if (selected) _statusChip('success')]),
        if (queue > 0) Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(top: 7), child: Text('Queue: $queue', style: const TextStyle(color: Colors.white30, fontSize: 8)))),
        if (err != null && err.isNotEmpty) Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(top: 5), child: Text(err, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFFF59E0B), fontSize: 8)))),
        const SizedBox(height: 5),
        Row(mainAxisAlignment: MainAxisAlignment.end, children: [TextButton.icon(onPressed: testing ? null : () => _testWorker(host), icon: testing ? const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.health_and_safety_rounded, size: 14), label: Text(testing ? 'CHECK...' : 'TEST')), TextButton.icon(onPressed: (_busy || online || _installingWorker != null) ? null : () => _installWorker(host), icon: installing ? const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.download_rounded, size: 14), label: Text(installing ? 'INSTALL...' : 'INSTALL')), TextButton(onPressed: (_busy || !healthy) ? null : () => _selectServer(host), child: Text(selected ? 'ACTIVE' : 'USE'))]),
      ]));
    }),
    if (_preflight != null) ...[const SizedBox(height: 2), Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: (_preflight?['ready'] == true ? const Color(0xFF22C55E) : const Color(0xFFF59E0B)).withOpacity(.07), borderRadius: BorderRadius.circular(11)), child: Row(children: [Icon(_preflight?['ready'] == true ? Icons.verified_rounded : Icons.warning_amber_rounded, color: _preflight?['ready'] == true ? const Color(0xFF4ADE80) : const Color(0xFFF59E0B), size: 16), const SizedBox(width: 8), Expanded(child: Text(_preflight?['message']?.toString() ?? 'Preflight belum siap', style: const TextStyle(color: Colors.white60, fontSize: 9)))]) )],
    const SizedBox(height: 4),
    Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: _preflighting ? null : _runPreflight, icon: _preflighting ? const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.health_and_safety_rounded, size: 15), label: Text(_preflighting ? 'CHECKING...' : 'RUN PREFLIGHT'))),
  ]));

  Widget _formCard() => _card('Build Configuration', Icons.tune_rounded, Column(children: [
    Row(children: [Expanded(child: _field('App Name', _name)), const SizedBox(width: 8), Expanded(child: _field('Version', _version))]),
    const SizedBox(height: 11),
    Row(children: [Expanded(child: _choice('APK', _artifact == 'apk', () => setState(() => _artifact = 'apk'))), const SizedBox(width: 8), Expanded(child: _choice('AAB', _artifact == 'aab', () => setState(() => _artifact = 'aab')))]),
    const SizedBox(height: 8),
    Row(children: [Expanded(child: _choice('Release', _release, () => setState(() => _release = true))), const SizedBox(width: 8), Expanded(child: _choice('Debug', !_release, () => setState(() => _release = false)))]),
    const SizedBox(height: 13),
    SizedBox(width: double.infinity, height: 48, child: ElevatedButton.icon(onPressed: (_busy || _preflighting || _projectInfo == null) ? null : _startBuild, icon: Icon(_busy ? Icons.hourglass_top_rounded : Icons.rocket_launch_rounded, size: 18), label: Text(_busy ? 'BUILD SEDANG BERJALAN...' : 'MULAI BUILD', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)), style: _primaryButton())),
  ]));

  Widget _progressCard(double progress, String status) {
    final done = status == 'success';
    final failed = status == 'failed';
    final log = _job?['log']?.toString() ?? '';
    final message = _job?['message']?.toString() ?? status;
    final error = _job?['error']?.toString() ?? '';
    final c = done ? const Color(0xFF22C55E) : failed ? const Color(0xFFEF4444) : const Color(0xFF8B5CF6);
    return _card('Current Build', Icons.bolt_rounded, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Container(width: 39, height: 39, decoration: BoxDecoration(color: c.withOpacity(.10), borderRadius: BorderRadius.circular(12)), child: Icon(done ? Icons.check_rounded : failed ? Icons.close_rounded : Icons.build_rounded, color: c, size: 20)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(done ? 'Build berhasil' : failed ? 'Build gagal' : 'Build sedang diproses', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(message, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white38, fontSize: 8))])), _statusChip(status)]),
      const SizedBox(height: 14),
      Row(children: [Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: (progress / 100).clamp(0.0, 1.0), minHeight: 8, backgroundColor: Colors.white10, valueColor: AlwaysStoppedAnimation<Color>(c)))), const SizedBox(width: 10), Text('${progress.toStringAsFixed(0)}%', style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w900))]),
      if (failed && error.isNotEmpty) ...[const SizedBox(height: 8), Container(width: double.infinity, padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: const Color(0xFFEF4444).withOpacity(.06), borderRadius: BorderRadius.circular(10)), child: Text(error, style: const TextStyle(color: Color(0xFFF87171), fontSize: 8)))],
      const SizedBox(height: 11),
      Row(children: [Expanded(child: OutlinedButton.icon(onPressed: log.isEmpty ? null : _showLog, icon: const Icon(Icons.terminal_rounded, size: 15), label: const Text('BUILD LOG'), style: _outlineButton())), if (done) ...[const SizedBox(width: 8), Expanded(child: ElevatedButton.icon(onPressed: _download, icon: const Icon(Icons.download_rounded, size: 15), label: Text(_artifact.toUpperCase()), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF22C55E), foregroundColor: Colors.black, minimumSize: const Size(0, 45), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 10))))]]),
    ]));
  }

  Widget _card(String title, IconData icon, Widget child) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFF0D151F), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF1E2A3A))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: const Color(0xFF9A84FF), size: 18), const SizedBox(width: 8), Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w900))]), const SizedBox(height: 12), child]));
  Widget _field(String label, TextEditingController c) => TextField(controller: c, enabled: !_busy, style: const TextStyle(color: Colors.white, fontSize: 11), decoration: InputDecoration(labelText: label, labelStyle: const TextStyle(color: Colors.white38, fontSize: 10), filled: true, fillColor: const Color(0xFF0A111A), contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF1E2A3A)))));
  Widget _choice(String text, bool selected, VoidCallback onTap) => InkWell(onTap: _busy ? null : onTap, borderRadius: BorderRadius.circular(12), child: AnimatedContainer(duration: const Duration(milliseconds: 180), padding: const EdgeInsets.symmetric(vertical: 12), alignment: Alignment.center, decoration: BoxDecoration(color: selected ? const Color(0xFF7658FF).withOpacity(.12) : const Color(0xFF0A111A), borderRadius: BorderRadius.circular(12), border: Border.all(color: selected ? const Color(0xFF7658FF).withOpacity(.65) : const Color(0xFF1E2A3A))), child: Text(text, style: TextStyle(color: selected ? Colors.white : Colors.white54, fontSize: 10, fontWeight: FontWeight.w800))));
  Widget _mini(String a, String b) => Expanded(child: Container(margin: const EdgeInsets.only(right: 7), padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: const Color(0xFF0A111A), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF182433))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(a, style: const TextStyle(color: Colors.white30, fontSize: 8)), const SizedBox(height: 3), Text(b, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 9, fontWeight: FontWeight.w700))])));
}
