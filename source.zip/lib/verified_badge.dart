import 'dart:math' as math;
import 'package:flutter/material.dart';

class BlueVerifiedBadge extends StatelessWidget {
  final double size;
  const BlueVerifiedBadge({super.key, this.size = 18});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _BlueVerifiedPainter()),
    );
  }
}

class _BlueVerifiedPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final c = Offset(s.width / 2, s.height / 2);
    final r = s.shortestSide * .40;
    final path = Path();
    const spikes = 12;
    for (var i = 0; i < spikes * 2; i++) {
      final rr = i.isEven ? r * 1.28 : r * .98;
      final a = -3.14159265 / 2 + i * 3.14159265 / spikes;
      final p = Offset(c.dx + rr * math.cos(a), c.dy + rr * math.sin(a));
      if (i == 0) path.moveTo(p.dx, p.dy); else path.lineTo(p.dx, p.dy);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = const Color(0xFF20A9FF));
    final check = Path()
      ..moveTo(s.width * .28, s.height * .52)
      ..lineTo(s.width * .44, s.height * .68)
      ..lineTo(s.width * .75, s.height * .34);
    canvas.drawPath(check, Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = s.width * .13
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round);
  }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
