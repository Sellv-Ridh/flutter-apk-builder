import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class AiChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const AiChatPage({super.key, required this.username, required this.sessionKey});

  @override
  State<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends State<AiChatPage> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  final List<_AiMessage> _messages = [];
  bool _sending = false;
  bool _loadingSettings = false;

  @override
  void initState() {
    super.initState();
    _messages.add(const _AiMessage(false, 'Halo! 👋 Saya DARK LIGHT AI. Tanyakan apa saja yang bisa saya bantu.'));
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _sending) return;
    _controller.clear();
    setState(() {
      _messages.add(_AiMessage(true, text));
      _sending = true;
    });
    _jumpBottom();
    try {
      final r = await http.post(
        Uri.parse('$baseUrl/api/chat/ai'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'session_key': widget.sessionKey, 'message': text}),
      ).timeout(const Duration(seconds: 35));
      Map<String, dynamic> body = {};
      try {
        final decoded = jsonDecode(r.body);
        if (decoded is Map) body = Map<String, dynamic>.from(decoded);
      } catch (_) {}
      final answer = (body['message'] ?? '').toString();
      if (r.statusCode == 200 && answer.isNotEmpty) {
        setState(() => _messages.add(_AiMessage(false, answer)));
      } else {
        final code = (body['code'] ?? '').toString();
        final detail = answer.isNotEmpty ? answer : 'AI gagal merespons (${r.statusCode}).';
        setState(() => _messages.add(_AiMessage(false, '⚠️ $detail${code.isNotEmpty ? '\nKode: $code' : ''}')));
      }
    } catch (e) {
      if (mounted) setState(() => _messages.add(_AiMessage(false, '⚠️ Gagal terhubung ke server AI.\n${e.toString()}')));
    } finally {
      if (mounted) {
        setState(() => _sending = false);
        _jumpBottom();
      }
    }
  }

  Future<void> _clearHistory() async {
    try {
      await http.delete(Uri.parse('$baseUrl/api/chat/ai/history').replace(queryParameters: {'session_key': widget.sessionKey}));
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _messages
        ..clear()
        ..add(const _AiMessage(false, 'History dibersihkan. 👋 Ada yang ingin kamu tanyakan?'));
    });
  }

  Future<void> _openAiSettings() async {
    if (_loadingSettings) return;
    setState(() => _loadingSettings = true);
    Map<String, dynamic> profile = {};
    List<dynamic> memories = [];
    try {
      final p = await http.get(Uri.parse('$baseUrl/api/chat/ai/profile').replace(queryParameters: {'session_key': widget.sessionKey}));
      if (p.statusCode == 200) {
        final d = jsonDecode(p.body);
        if (d is Map && d['profile'] is Map) profile = Map<String, dynamic>.from(d['profile']);
      }
      final m = await http.get(Uri.parse('$baseUrl/api/chat/ai/memory').replace(queryParameters: {'session_key': widget.sessionKey}));
      if (m.statusCode == 200) {
        final d = jsonDecode(m.body);
        if (d is Map && d['memory'] is List) memories = List<dynamic>.from(d['memory']);
      }
    } catch (_) {}
    if (!mounted) return;
    setState(() => _loadingSettings = false);
    final name = TextEditingController(text: (profile['name'] ?? '').toString());
    final nickname = TextEditingController(text: (profile['nickname'] ?? '').toString());
    final about = TextEditingController(text: (profile['about'] ?? '').toString());
    final preferences = TextEditingController(text: (profile['preferences'] ?? '').toString());
    final memory = TextEditingController();
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF0A1525),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => StatefulBuilder(builder: (context, setSheet) {
        Future<void> saveProfile() async {
          try {
            await http.put(Uri.parse('$baseUrl/api/chat/ai/profile'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({
              'session_key': widget.sessionKey, 'name': name.text.trim(), 'nickname': nickname.text.trim(),
              'about': about.text.trim(), 'preferences': preferences.text.trim(),
            }));
            if (context.mounted) Navigator.pop(context);
          } catch (_) {}
        }
        Future<void> addMem() async {
          final text = memory.text.trim(); if (text.isEmpty) return;
          try {
            final r = await http.post(Uri.parse('$baseUrl/api/chat/ai/memory'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'session_key': widget.sessionKey, 'text': text}));
            if (r.statusCode == 200) { memories.add({'text': text}); memory.clear(); setSheet(() {}); }
          } catch (_) {}
        }
        Future<void> clearMem() async {
          try { await http.delete(Uri.parse('$baseUrl/api/chat/ai/memory').replace(queryParameters: {'session_key': widget.sessionKey})); } catch (_) {}
          memories.clear(); setSheet(() {});
        }
        InputDecoration dec(String hint) => InputDecoration(hintText: hint, hintStyle: const TextStyle(color: Colors.white38), filled: true, fillColor: const Color(0xFF111A27), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none));
        return Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, MediaQuery.of(context).viewInsets.bottom + 18), child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(9)))),
          const SizedBox(height: 16),
          const Text('🧠 dey AI — Profil & Memory', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5), const Text('Bikin DarkLight AI lebih mengenal kamu.', style: TextStyle(color: Colors.white54)),
          const SizedBox(height: 16),
          TextField(controller: name, style: const TextStyle(color: Colors.white), decoration: dec('Nama kamu')),
          const SizedBox(height: 9), TextField(controller: nickname, style: const TextStyle(color: Colors.white), decoration: dec('Panggilan')),
          const SizedBox(height: 9), TextField(controller: about, minLines: 2, maxLines: 4, style: const TextStyle(color: Colors.white), decoration: dec('Tentang kamu / proyek kamu')),
          const SizedBox(height: 9), TextField(controller: preferences, minLines: 2, maxLines: 4, style: const TextStyle(color: Colors.white), decoration: dec('Preferensi kamu, misalnya jangan hapus fitur lama')),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: TextField(controller: memory, style: const TextStyle(color: Colors.white), decoration: dec('Tambah memory'))), const SizedBox(width: 8), IconButton(onPressed: addMem, icon: const Icon(Icons.add_circle, color: Color(0xFF19E6C1), size: 34))]),
          if (memories.isNotEmpty) ...[
            const SizedBox(height: 10), const Text('Memory tersimpan', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6), ...memories.take(8).map((m) => Padding(padding: const EdgeInsets.only(bottom: 5), child: Text('• ${(m is Map ? m['text'] : m).toString()}', style: const TextStyle(color: Colors.white54, fontSize: 13)))),
            TextButton.icon(onPressed: clearMem, icon: const Icon(Icons.delete_outline, color: Colors.redAccent), label: const Text('Hapus semua memory', style: TextStyle(color: Colors.redAccent))),
          ],
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: saveProfile, icon: const Icon(Icons.save_rounded), label: const Text('Simpan profil AI'), style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF19E6C1), foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))),
        ])));
      }),
    );
    name.dispose(); nickname.dispose(); about.dispose(); preferences.dispose(); memory.dispose();
  }

  void _jumpBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050A12),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A1525),
        foregroundColor: Colors.white,
        titleSpacing: 0,
        title: const Row(children: [
          CircleAvatar(radius: 18, backgroundColor: Color(0xFF19E6C1), child: Icon(Icons.auto_awesome, color: Colors.black, size: 19)),
          SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('DarkLight AI', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text('Groq • Online', style: TextStyle(fontSize: 11, color: Colors.white54)),
          ])
        ]),
        actions: [IconButton(onPressed: _loadingSettings ? null : _openAiSettings, icon: const Icon(Icons.psychology_alt_rounded)), IconButton(onPressed: _sending ? null : _clearHistory, icon: const Icon(Icons.delete_sweep_rounded))],
      ),
      body: Column(children: [
        if (_messages.length == 1 && !_sending) SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: ['Kenalan sama saya', 'Bantu coding', 'Ide fitur baru', 'Jelaskan error'].map((q) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ActionChip(label: Text(q), onPressed: () { _controller.text = q; _send(); }, backgroundColor: const Color(0xFF111A27), labelStyle: const TextStyle(color: Colors.white70)))).toList())),
        Expanded(child: ListView.builder(
          controller: _scroll,
          padding: const EdgeInsets.fromLTRB(14, 18, 14, 12),
          itemCount: _messages.length + (_sending ? 1 : 0),
          itemBuilder: (_, i) {
            if (i == _messages.length) return const _TypingBubble();
            final m = _messages[i];
            return Align(
              alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .82),
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11),
                decoration: BoxDecoration(
                  color: m.mine ? const Color(0xFF0B4D46) : const Color(0xFF111A27),
                  borderRadius: BorderRadius.only(
                    topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
                    bottomLeft: Radius.circular(m.mine ? 18 : 4), bottomRight: Radius.circular(m.mine ? 4 : 18),
                  ),
                ),
                child: Text(m.text, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4)),
              ),
            );
          },
        )),
        SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
          child: Row(children: [
            Expanded(child: Container(
              decoration: BoxDecoration(color: const Color(0xFF111A27), borderRadius: BorderRadius.circular(25), border: Border.all(color: Colors.white10)),
              child: TextField(
                controller: _controller,
                minLines: 1, maxLines: 5,
                enabled: !_sending,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(hintText: 'Tulis pesan ke AI...', hintStyle: TextStyle(color: Colors.white38), border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 18, vertical: 12)),
                onSubmitted: (_) => _send(),
              ),
            )),
            const SizedBox(width: 8),
            CircleAvatar(radius: 24, backgroundColor: const Color(0xFF19E6C1), child: IconButton(onPressed: _sending ? null : _send, icon: const Icon(Icons.send_rounded, color: Colors.black))),
          ]),
        )),
      ]),
    );
  }
}

class _AiMessage {
  final bool mine;
  final String text;
  const _AiMessage(this.mine, this.text);
}

class _TypingBubble extends StatelessWidget {
  const _TypingBubble();
  @override
  Widget build(BuildContext context) => Align(alignment: Alignment.centerLeft, child: Container(
    margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    decoration: BoxDecoration(color: const Color(0xFF111A27), borderRadius: BorderRadius.circular(18)),
    child: const Text('DARK LIGHT AI sedang mengetik…', style: TextStyle(color: Colors.white54)),
  ));
}
