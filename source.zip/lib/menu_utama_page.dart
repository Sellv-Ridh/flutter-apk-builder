import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'bug_group_page.dart';
import 'bug_sender.dart';
import 'comic_theme.dart';
import 'custom_payload.dart';
import 'home_page.dart' as home;
import 'theme_provider.dart';
import 'theme_settings_page.dart';

/// One of the 7 modules shown on the "Menu Utama" screen.
class MenuModule {
  final String title;
  final String subtitle;
  final String tag; // short chip label, e.g. "WA", "UBOT", "AI"
  final IconData icon;
  final Color color;
  final WidgetBuilder pageBuilder;

  const MenuModule({
    required this.title,
    required this.subtitle,
    required this.tag,
    required this.icon,
    required this.color,
    required this.pageBuilder,
  });
}

/// "Menu Utama": a swipeable carousel of module cards on top, the same
/// modules listed below it. Tapping "Bug & Pairing" opens the real sub-menu
/// (Sender Manager, Bug Group, Custom Payload, Home Page); every other
/// module opens its own page, which for now just says "Coming Soon".
///
/// In Comic mode, this page (and BugPairingMenuPage below) matches the hand
/// -drawn comic language used elsewhere: paper + halftone + doodles behind
/// everything, sticker-style headlines (solid text + an offset duplicate
/// behind it), thick ink borders and hard offset shadows on every card, and
/// a big circular icon that pokes out above each card instead of sitting
/// inside it.
class MenuUtamaPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String password;
  final String role;
  final String expiredDate;

  const MenuUtamaPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<MenuUtamaPage> createState() => _MenuUtamaPageState();
}

class _MenuUtamaPageState extends State<MenuUtamaPage> {
  late final PageController _pageCtrl = PageController(viewportFraction: 0.78);
  double _page = 0;
  late final List<MenuModule> _modules = _buildModules();

  @override
  void initState() {
    super.initState();
    _pageCtrl.addListener(() {
      if (mounted) setState(() => _page = _pageCtrl.page ?? 0);
    });
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  List<MenuModule> _buildModules() {
    return [
      MenuModule(
        title: 'Bug & Pairing',
        subtitle: 'Server di HP · Server Lokal',
        tag: 'WA',
        icon: Icons.chat_bubble_rounded,
        color: const Color(0xFF22C55E),
        pageBuilder: (_) => BugPairingMenuPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
        ),
      ),
      MenuModule(
        title: 'Add Userbot',
        subtitle: 'Tambah ubot dari APK · nomor & OTP',
        tag: 'UBOT',
        icon: Icons.smart_toy_rounded,
        color: const Color(0xFF2563EB),
        pageBuilder: (_) => const ComingSoonPage(title: 'Add Userbot'),
      ),
      MenuModule(
        title: 'Per-SC an',
        subtitle: 'Multi SC · Termux · session',
        tag: 'SC',
        icon: Icons.science_rounded,
        color: const Color(0xFF9333EA),
        pageBuilder: (_) => const ComingSoonPage(title: 'Per-SC an'),
      ),
      MenuModule(
        title: 'Install Ubot',
        subtitle: 'Termux/VPS · form rebrand',
        tag: 'UBOT',
        icon: Icons.smart_toy_outlined,
        color: const Color(0xFF0EA5E9),
        pageBuilder: (_) => const ComingSoonPage(title: 'Install Ubot'),
      ),
      MenuModule(
        title: 'Install Panel',
        subtitle: 'Termux/VPS · Panel + Wings',
        tag: 'PANEL',
        icon: Icons.dns_rounded,
        color: const Color(0xFF64748B),
        pageBuilder: (_) => const ComingSoonPage(title: 'Install Panel'),
      ),
      MenuModule(
        title: '9router + Hermes',
        subtitle: 'Termux/VPS · AI stack',
        tag: 'AI',
        icon: Icons.auto_awesome_rounded,
        color: const Color(0xFFF59E0B),
        pageBuilder: (_) => const ComingSoonPage(title: '9router + Hermes'),
      ),
      MenuModule(
        title: 'SYAM Ai',
        subtitle: 'Chat di HP · cek HP, senter, menu',
        tag: 'CHAT',
        icon: Icons.auto_awesome_rounded,
        color: const Color(0xFFEC4899),
        pageBuilder: (_) => const ComingSoonPage(title: 'SYAM Ai'),
      ),
    ];
  }

  void _open(MenuModule m) {
    Navigator.of(context).push(MaterialPageRoute(builder: m.pageBuilder));
  }

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final comic = ThemeProvider.isComic3D;

    final content = SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: comic
                      ? _ComicSticker(text: 'MENU UTAMA', fontSize: 28)
                      : Text('MENU UTAMA',
                          style: TextStyle(
                              color: ThemeProvider.text,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron')),
                ),
                const SizedBox(width: 10),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text('· Termux & VPS',
                      style: TextStyle(color: ThemeProvider.textSub, fontSize: 12.5)),
                ),
              ],
            ),
          ),
          SizedBox(
            height: comic ? 232 : 190,
            child: PageView.builder(
              controller: _pageCtrl,
              itemCount: _modules.length,
              padEnds: true,
              itemBuilder: (context, i) {
                final m = _modules[i];
                final delta = (_page - i).abs().clamp(0.0, 1.0);
                final scale = 1 - delta * 0.12;
                return Transform.scale(
                  scale: scale,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                    child: comic
                        ? _ComicCarouselCard(module: m, onTap: () => _open(m))
                        : _ModuleCarouselCard(module: m, onTap: () => _open(m)),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_modules.length, (i) {
              final active = (_page.round() == i);
              return AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: active
                      ? ThemeProvider.currentPrimary
                      : (comic ? ThemeProvider.comicInk.withOpacity(0.25) : ThemeProvider.border),
                  borderRadius: BorderRadius.circular(3),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          _GeserMenuPill(
            index: _page.round(),
            total: _modules.length,
            onPrev: _page.round() > 0
                ? () => _pageCtrl.animateToPage(_page.round() - 1,
                    duration: const Duration(milliseconds: 280), curve: Curves.easeOut)
                : null,
            onNext: _page.round() < _modules.length - 1
                ? () => _pageCtrl.animateToPage(_page.round() + 1,
                    duration: const Duration(milliseconds: 280), curve: Curves.easeOut)
                : null,
          ),
          const SizedBox(height: 14),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              itemCount: _modules.length,
              separatorBuilder: (_, __) => const SizedBox(height: 14),
              itemBuilder: (context, i) {
                final m = _modules[i];
                return comic
                    ? _ComicListEntry(module: m, onTap: () => _open(m))
                    : _ModuleListTile(module: m, onTap: () => _open(m));
              },
            ),
          ),
        ],
      ),
    );

    if (!comic) {
      return Container(color: ThemeProvider.background, child: content);
    }

    return Stack(
      children: [
        Positioned.fill(child: ComicThemeAtmosphere(child: const SizedBox.shrink())),
        const Positioned.fill(child: ComicDoodleLayer()),
        content,
      ],
    );
  }
}

/// Sticker-style headline used for comic headers: a solid-colour copy of the
/// text offset behind the main black text, like a drop shadow printed on
/// paper. Mirrors the hand-lettered titles in the reference screens.
class _ComicSticker extends StatelessWidget {
  final String text;
  final double fontSize;
  final TextAlign align;
  const _ComicSticker({required this.text, required this.fontSize, this.align = TextAlign.left});

  @override
  Widget build(BuildContext context) {
    final style = TextStyle(
      fontSize: fontSize,
      fontWeight: FontWeight.w900,
      fontStyle: FontStyle.italic,
      letterSpacing: 0.2,
      height: 1.0,
    );
    return Stack(
      children: [
        Transform.translate(
          offset: const Offset(2.5, 2.5),
          child: Text(text,
              textAlign: align,
              style: style.copyWith(color: ThemeProvider.comicYellow.withOpacity(0.85))),
        ),
        Text(text, textAlign: align, style: style.copyWith(color: ThemeProvider.comicInk)),
      ],
    );
  }
}

/// "< GESER MENU (n/total) >" pill, matching the reference screenshot.
class _GeserMenuPill extends StatelessWidget {
  final int index;
  final int total;
  final VoidCallback? onPrev;
  final VoidCallback? onNext;
  const _GeserMenuPill({required this.index, required this.total, this.onPrev, this.onNext});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: ThemeProvider.comicPaper2,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: ThemeProvider.comicInk, width: 2.4),
          boxShadow: [BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(2.5, 3))],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.chevron_left_rounded,
                size: 18, color: ThemeProvider.comicInk.withOpacity(onPrev == null ? 0.3 : 1)),
            const SizedBox(width: 4),
            Text('GESER MENU (${index + 1}/$total)',
                style: TextStyle(
                    color: ThemeProvider.comicInk,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3)),
            const SizedBox(width: 4),
            Icon(Icons.chevron_right_rounded,
                size: 18, color: ThemeProvider.comicInk.withOpacity(onNext == null ? 0.3 : 1)),
          ],
        ),
      ),
    );
  }
}

/// Comic carousel card: a big circular icon pokes out above a thick-bordered
/// paper card with hard offset shadow, title, subtitle and a yellow tag pill.
class _ComicCarouselCard extends StatelessWidget {
  final MenuModule module;
  final VoidCallback onTap;
  const _ComicCarouselCard({required this.module, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const circle = 92.0;
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.only(top: circle / 2),
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topCenter,
          children: [
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(top: circle / 2),
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
              decoration: BoxDecoration(
                color: ThemeProvider.comicPaper2,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: ThemeProvider.comicInk, width: 3),
                boxShadow: [
                  BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(5, 6)),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(module.title,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: ThemeProvider.comicInk, fontSize: 19, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 5),
                  Text(module.subtitle,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: ThemeProvider.comicMuted, fontSize: 11.5)),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: ThemeProvider.comicYellow,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: ThemeProvider.comicInk, width: 2),
                    ),
                    child: Text(module.tag,
                        style: TextStyle(
                            color: ThemeProvider.comicOnAccent,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 0,
              child: Container(
                width: circle,
                height: circle,
                decoration: BoxDecoration(
                  color: module.color,
                  shape: BoxShape.circle,
                  border: Border.all(color: ThemeProvider.comicInk, width: 3),
                  boxShadow: [
                    BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(3, 4)),
                  ],
                ),
                child: Icon(module.icon, color: Colors.white, size: 38),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Comic list entry: a compact icon+title row, followed by a full-width
/// yellow "⚡ BUKA ..." button, matching "BUKA BUG & PAIRING" in the reference.
class _ComicListEntry extends StatelessWidget {
  final MenuModule module;
  final VoidCallback onTap;
  const _ComicListEntry({required this.module, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: ThemeProvider.comicPaper2,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: ThemeProvider.comicInk, width: 2.6),
            boxShadow: [BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(3.5, 4))],
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: module.color,
                  shape: BoxShape.circle,
                  border: Border.all(color: ThemeProvider.comicInk, width: 2),
                ),
                child: Icon(module.icon, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(module.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: ThemeProvider.comicInk, fontSize: 14.5, fontWeight: FontWeight.w900)),
                    Text(module.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: ThemeProvider.comicMuted, fontSize: 11.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        _ComicYellowButton(label: 'BUKA ${module.title.toUpperCase()}', onTap: onTap),
      ],
    );
  }
}

class _ComicYellowButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _ComicYellowButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(26),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            color: ThemeProvider.comicYellow,
            borderRadius: BorderRadius.circular(26),
            border: Border.all(color: ThemeProvider.comicInk, width: 2.6),
            boxShadow: [BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(3.5, 4))],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.bolt_rounded, color: ThemeProvider.comicOnAccent, size: 18),
              const SizedBox(width: 8),
              Flexible(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ThemeProvider.comicOnAccent,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Non-comic (Classic) styling — unchanged from before ─────────────────

class _ModuleCarouselCard extends StatelessWidget {
  final MenuModule module;
  final VoidCallback onTap;
  const _ModuleCarouselCard({required this.module, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: ThemeProvider.card,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: ThemeProvider.border, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(color: module.color.withOpacity(0.15), shape: BoxShape.circle),
              child: Icon(module.icon, color: module.color, size: 26),
            ),
            const SizedBox(height: 10),
            Text(module.title,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: ThemeProvider.text, fontSize: 15.5, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(module.subtitle,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: ThemeProvider.textSub, fontSize: 10.5)),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration:
                  BoxDecoration(color: module.color.withOpacity(0.15), borderRadius: BorderRadius.circular(16)),
              child: Text(module.tag,
                  style: TextStyle(
                      color: module.color, fontSize: 10.5, fontWeight: FontWeight.w900, letterSpacing: 0.5)),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModuleListTile extends StatelessWidget {
  final MenuModule module;
  final VoidCallback onTap;
  const _ModuleListTile({required this.module, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: ThemeProvider.card,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: ThemeProvider.border, width: 1),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration:
                    BoxDecoration(color: module.color.withOpacity(0.15), borderRadius: BorderRadius.circular(13)),
                child: Icon(module.icon, color: module.color, size: 21),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(module.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: ThemeProvider.text, fontSize: 14, fontWeight: FontWeight.w800)),
                    Text(module.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: ThemeProvider.textSub, fontSize: 11.5)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                decoration: BoxDecoration(color: module.color, borderRadius: BorderRadius.circular(20)),
                child: const Text('Buka',
                    style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Sub-menu opened from the "Bug & Pairing" module: the 4 destinations the
/// user asked for, reusing the pages that already exist elsewhere in the app.
class BugPairingMenuPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String password;
  final String role;
  final String expiredDate;

  const BugPairingMenuPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<BugPairingMenuPage> createState() => _BugPairingMenuPageState();
}

class _BugPairingMenuPageState extends State<BugPairingMenuPage> {
  late final List<MenuModule> _items = [
    MenuModule(
      title: 'Sender Manager',
      subtitle: 'Kelola sender WhatsApp',
      tag: 'WA',
      icon: Icons.dns_rounded,
      color: const Color(0xFF22C55E),
      pageBuilder: (_) => BugSenderPage(
          sessionKey: widget.sessionKey, username: widget.username, role: widget.role),
    ),
    MenuModule(
      title: 'Bug Group',
      subtitle: 'Kirim bug ke group WhatsApp',
      tag: 'GROUP',
      icon: Icons.group_rounded,
      color: const Color(0xFF16A34A),
      pageBuilder: (_) => BugGroupPage(sessionKey: widget.sessionKey, role: widget.role),
    ),
    MenuModule(
      title: 'Custom Payload',
      subtitle: 'Setting custom delay & loops',
      tag: 'CUSTOM',
      icon: Icons.tune_rounded,
      color: const Color(0xFFEC4899),
      pageBuilder: (_) => CustomPayloadPage(
        sessionKey: widget.sessionKey,
        role: widget.role,
        listBug: const [],
        username: widget.username,
        password: widget.password,
        expiredDate: widget.expiredDate,
      ),
    ),
    MenuModule(
      title: 'Home Page',
      subtitle: 'Bug tanpa custom, siap pakai',
      tag: 'HOME',
      icon: Icons.bug_report_rounded,
      color: const Color(0xFF1565C0),
      pageBuilder: (_) => home.HomePage(
        username: widget.username,
        password: widget.password,
        listBug: const [],
        role: widget.role,
        expiredDate: widget.expiredDate,
        sessionKey: widget.sessionKey,
      ),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final comic = ThemeProvider.isComic3D;

    final body = SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 6, 14, 4),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_rounded,
                      color: comic ? ThemeProvider.comicInk : ThemeProvider.text),
                  onPressed: () => Navigator.of(context).maybePop(),
                ),
                Expanded(
                  child: Column(
                    children: [
                      comic
                          ? _ComicSticker(text: 'BUG & PAIRING', fontSize: 19, align: TextAlign.center)
                          : Text('BUG & PAIRING',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: ThemeProvider.text,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Orbitron')),
                      const SizedBox(height: 2),
                      Text('server SYAM di HP',
                          style: TextStyle(
                              color: comic ? ThemeProvider.comicMuted : ThemeProvider.textSub,
                              fontSize: 10.5)),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.palette_rounded,
                      color: comic ? ThemeProvider.comicInk : ThemeProvider.text),
                  onPressed: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => const ThemeSettingsPage())),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              children: [
                comic
                    ? _ComicSticker(text: 'SERVER & TOOLS', fontSize: 23)
                    : Text('SERVER & TOOLS',
                        style: TextStyle(
                            color: ThemeProvider.text,
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron')),
                const SizedBox(height: 12),
                _ServerOnlineCard(comic: comic),
                const SizedBox(height: 20),
                ..._items.map((m) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: comic
                          ? _ComicListEntry(
                              module: m,
                              onTap: () => Navigator.of(context)
                                  .push(MaterialPageRoute(builder: m.pageBuilder)),
                            )
                          : _ModuleListTile(
                              module: m,
                              onTap: () => Navigator.of(context)
                                  .push(MaterialPageRoute(builder: m.pageBuilder)),
                            ),
                    )),
              ],
            ),
          ),
        ],
      ),
    );

    if (!comic) {
      return Scaffold(backgroundColor: ThemeProvider.background, body: body);
    }

    return Scaffold(
      backgroundColor: ThemeProvider.comicPaper,
      body: Stack(
        children: [
          Positioned.fill(child: ComicThemeAtmosphere(child: const SizedBox.shrink())),
          const Positioned.fill(child: ComicDoodleLayer()),
          body,
        ],
      ),
    );
  }
}

class _ServerOnlineCard extends StatelessWidget {
  final bool comic;
  const _ServerOnlineCard({required this.comic});

  @override
  Widget build(BuildContext context) {
    final text = comic ? ThemeProvider.comicInk : ThemeProvider.text;
    final sub = comic ? ThemeProvider.comicMuted : ThemeProvider.textSub;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: comic ? ThemeProvider.comicPaper2 : const Color(0xFF22C55E).withOpacity(0.08),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: comic ? ThemeProvider.comicInk : const Color(0xFF22C55E).withOpacity(0.35),
          width: comic ? 3 : 1,
        ),
        boxShadow: comic
            ? [BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(4, 5))]
            : null,
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF22C55E),
              shape: BoxShape.circle,
              border: comic ? Border.all(color: ThemeProvider.comicInk, width: 2) : null,
            ),
            child: const Icon(Icons.dns_rounded, color: Colors.white, size: 19),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Server Online',
                    style: TextStyle(
                        color: const Color(0xFF16A34A),
                        fontWeight: FontWeight.w900,
                        fontSize: 14.5)),
                Text('server terhubung ke pusat (1.6.79)', style: TextStyle(color: sub, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Placeholder page for modules that aren't built yet. Shown for everything
/// outside "Bug & Pairing" on the Menu Utama screen.
class ComingSoonPage extends StatelessWidget {
  final String title;
  const ComingSoonPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final comic = ThemeProvider.isComic3D;
    final text = comic ? ThemeProvider.comicInk : ThemeProvider.text;
    final sub = comic ? ThemeProvider.comicMuted : ThemeProvider.textSub;
    final primary = ThemeProvider.currentPrimary;

    final body = SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 6, 14, 4),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_rounded, color: text),
                  onPressed: () => Navigator.of(context).maybePop(),
                ),
                Expanded(
                  child: Text(title,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: text, fontSize: 16, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 48),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      color: comic ? ThemeProvider.comicYellow : primary.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: comic ? ThemeProvider.comicInk : primary.withOpacity(0.35),
                        width: comic ? 3 : 2,
                      ),
                      boxShadow: comic
                          ? [BoxShadow(color: ThemeProvider.comicInk, offset: const Offset(4, 5))]
                          : null,
                    ),
                    child: Icon(Icons.hourglass_top_rounded,
                        color: comic ? ThemeProvider.comicOnAccent : primary, size: 40),
                  ),
                  const SizedBox(height: 20),
                  comic
                      ? const _ComicSticker(text: 'COMING SOON', fontSize: 24, align: TextAlign.center)
                      : Text('COMING SOON',
                          style: TextStyle(
                              color: text, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2)),
                  const SizedBox(height: 8),
                  Text('$title sedang dalam pengembangan',
                      textAlign: TextAlign.center, style: TextStyle(color: sub, fontSize: 13)),
                ],
              ),
            ),
          ),
        ],
      ),
    );

    if (!comic) {
      return Scaffold(backgroundColor: ThemeProvider.background, body: body);
    }
    return Scaffold(
      backgroundColor: ThemeProvider.comicPaper,
      body: Stack(
        children: [
          Positioned.fill(child: ComicThemeAtmosphere(child: const SizedBox.shrink())),
          const Positioned.fill(child: ComicDoodleLayer()),
          body,
        ],
      ),
    );
  }
}
