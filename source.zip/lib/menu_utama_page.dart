import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import 'bug_group_page.dart';
import 'bug_sender.dart';
import 'comic_theme.dart';
import 'custom_payload.dart';
import 'home_page.dart' as home;
import 'theme_provider.dart';
import 'theme_settings_page.dart';

/// One of the 7 modules shown on the "Menu Utama" screen.
// Border & shadow kartu di halaman ini dulu SELALU memakai gaya "sticker
// komik" (border tinta tebal 2-3px + hard offset shadow tanpa blur, teks
// judul miring dengan bayangan ganda) di KEDUA tema — jadi Classic ikut
// kelihatan seperti komik juga, bukan bersih/modern seperti referensi biru
// (Samudra). Dua helper ini membuat kartu memakai gaya tinta tebal HANYA
// saat 3D Comic aktif; di Classic border jadi tipis & halus, shadow jadi
// blur lembut (bukan hard-offset), supaya tampilannya sesuai tema masing².
BoxBorder? _menuCardBorder({double comicWidth = 2.6}) => ThemeProvider.isComic3D
    ? Border.all(color: ThemeProvider.cardInk, width: comicWidth)
    : Border.all(color: ThemeProvider.cardInk.withOpacity(0.08), width: 1);

List<BoxShadow> _menuCardShadow({Offset comicOffset = const Offset(3.5, 4)}) =>
    ThemeProvider.isComic3D
        ? [BoxShadow(color: ThemeProvider.cardInk, offset: comicOffset)]
        : [BoxShadow(color: Colors.black.withOpacity(0.10), blurRadius: 16, offset: const Offset(0, 6))];

class _NoGlowScrollBehavior extends MaterialScrollBehavior {
  const _NoGlowScrollBehavior();
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) {
    return child; // no GlowingOverscrollIndicator
  }
}

class MenuModule {
  final String title;
  final String subtitle;
  final String tag; // short chip label, e.g. "WA", "UBOT", "AI"
  final IconData icon;
  final Color color;
  final WidgetBuilder pageBuilder;

  const MenuModule({
    required this.title,
    required this.subtitle,
    required this.tag,
    required this.icon,
    required this.color,
    required this.pageBuilder,
  });
}

/// "Menu Utama": a swipeable carousel of module cards on top, the same
/// modules listed below it. Tapping "Bug & Pairing" opens the real sub-menu
/// (Sender Manager, Bug Group, Custom Payload, Home Page); every other
/// module opens its own page, which for now just says "Coming Soon".
///
/// In Comic mode, this page (and BugPairingMenuPage below) matches the hand
/// -drawn comic language used elsewhere: paper + halftone + doodles behind
/// everything, sticker-style headlines (solid text + an offset duplicate
/// behind it), thick ink borders and hard offset shadows on every card, and
/// a big circular icon that pokes out above each card instead of sitting
/// inside it.
class MenuUtamaPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;

  const MenuUtamaPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    this.listBug = const [],
  });

  @override
  State<MenuUtamaPage> createState() => _MenuUtamaPageState();
}

class _MenuUtamaPageState extends State<MenuUtamaPage> {
  // _modules must exist before _loopBase is computed below.
  late final List<MenuModule> _modules = _buildModules();

  // Geser tak berujung: itemCount jauh lebih besar dari jumlah modul asli,
  // lalu itemBuilder mengambil modul lewat modulo (i % _modules.length).
  // Mulai dari tengah rentang virtual supaya kedua arah geser punya banyak
  // "ruang" sebelum benar-benar habis (dalam praktiknya nyaris tak terasa).
  static const int _loopMultiplier = 5000;
  int get _loopItemCount => _modules.length * _loopMultiplier;
  int get _loopBase => (_loopItemCount ~/ 2) - ((_loopItemCount ~/ 2) % _modules.length);

  late final PageController _pageCtrl =
      PageController(viewportFraction: 1.0, initialPage: _loopBase);
  double _page = 0;

  @override
  void initState() {
    super.initState();
    _page = _loopBase.toDouble();
    _pageCtrl.addListener(() {
      if (mounted) setState(() => _page = _pageCtrl.page ?? _loopBase.toDouble());
    });
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  List<MenuModule> _buildModules() {
    return [
      MenuModule(
        title: 'Bug & Pairing',
        subtitle: 'Server di HP · Server Lokal',
        tag: 'WA',
        icon: Icons.chat_bubble_rounded,
        color: const Color(0xFF22C55E),
        pageBuilder: (_) => BugPairingMenuPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          listBug: widget.listBug,
        ),
      ),
      MenuModule(
        title: 'Add Userbot',
        subtitle: 'Tambah ubot dari APK · nomor & OTP',
        tag: 'UBOT',
        icon: Icons.smart_toy_rounded,
        color: const Color(0xFF2563EB),
        pageBuilder: (_) => const ComingSoonPage(title: 'Add Userbot'),
      ),
      MenuModule(
        title: 'Per-SC an',
        subtitle: 'Multi SC · Termux · session',
        tag: 'SC',
        icon: Icons.science_rounded,
        color: const Color(0xFF9333EA),
        pageBuilder: (_) => const ComingSoonPage(title: 'Per-SC an'),
      ),
      MenuModule(
        title: 'Install Ubot',
        subtitle: 'Termux/VPS · form rebrand',
        tag: 'UBOT',
        icon: Icons.smart_toy_outlined,
        color: const Color(0xFF0EA5E9),
        pageBuilder: (_) => const ComingSoonPage(title: 'Install Ubot'),
      ),
      MenuModule(
        title: 'Install Panel',
        subtitle: 'Termux/VPS · Panel + Wings',
        tag: 'PANEL',
        icon: Icons.dns_rounded,
        color: const Color(0xFF64748B),
        pageBuilder: (_) => const ComingSoonPage(title: 'Install Panel'),
      ),
      MenuModule(
        title: '9router + Hermes',
        subtitle: 'Termux/VPS · AI stack',
        tag: 'AI',
        icon: Icons.auto_awesome_rounded,
        color: const Color(0xFFF59E0B),
        pageBuilder: (_) => const ComingSoonPage(title: '9router + Hermes'),
      ),
      MenuModule(
        title: 'DARK LIGHT Ai',
        subtitle: 'Chat di HP · cek HP, senter, menu',
        tag: 'CHAT',
        icon: Icons.auto_awesome_rounded,
        color: const Color(0xFFEC4899),
        pageBuilder: (_) => const ComingSoonPage(title: 'DARK LIGHT Ai'),
      ),
    ];
  }

  void _open(MenuModule m) {
    Navigator.of(context).push(MaterialPageRoute(builder: m.pageBuilder));
  }

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final comic = ThemeProvider.isComic3D;

    final content = SafeArea(
      bottom: false,
      // Di layar yang lebih pendek kontennya sedikit melebihi satu layar,
      // jadi harus BISA digeser turun sedikit (seperti di video) supaya
      // kartu paling bawah tidak pernah terpotong mentok di tepi layar
      // seperti sebelumnya. BouncingScrollPhysics juga kasih sedikit efek
      // pantulan di ujung, jadi jelas kelihatan "masih bisa digeser",
      // bukan terasa seperti dibatasi/dipotong.
      child: ScrollConfiguration(
        behavior: const _NoGlowScrollBehavior(),
        child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
              child: Row(
                children: [
                  // "<App> SYSTEM HUB" — pill dengan titik hijau berdenyut,
                  // meniru badge "SYAM SYSTEM HUB" di referensi. Sama bentuk
                  // di kedua tema, warnanya ikut palet aktif.
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: ThemeProvider.accent.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(18),
                      border: _menuCardBorder(comicWidth: 2),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Container(
                        width: 7, height: 7,
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF2ECC71)),
                      ),
                      const SizedBox(width: 6),
                      Text('SYAM SYSTEM HUB',
                          style: TextStyle(
                              color: ThemeProvider.cardInk, fontSize: 10, fontWeight: FontWeight.w900)),
                    ]),
                  ),
                  const Spacer(),
                  // "N MODULES" — pill di kanan atas.
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: ThemeProvider.cardSurface,
                      borderRadius: BorderRadius.circular(18),
                      border: _menuCardBorder(comicWidth: 2),
                    ),
                    child: Text('${_modules.length} MODULES',
                        style: TextStyle(
                            color: ThemeProvider.cardInk, fontSize: 10, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Expanded(
                  child: _ComicSticker(text: 'MENU UTAMA', fontSize: 28),
                ),
                const SizedBox(width: 10),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text('· Termux & VPS',
                      style: TextStyle(color: ThemeProvider.textSub, fontSize: 12.5)),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 2, 18, 4),
            child: _ComicDateTimeCard(),
          ),
          SizedBox(
            // Generous fixed height: circle (92) + gap (14) + card (~120)
            // + the item's own vertical padding (20), with headroom so the
            // card can never be clipped at the bottom.
            // Generous fixed height for both themes now that the shape is
            // shared: circle (92) + gap (14) + card (~120) + the item's own
            // vertical padding (20), with headroom so it never clips.
            height: 268,
            child: ScrollConfiguration(
              behavior: const _NoGlowScrollBehavior(),
              child: PageView.builder(
                controller: _pageCtrl,
                itemCount: _loopItemCount,
                itemBuilder: (context, i) {
                  final m = _modules[i % _modules.length];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    child: _ComicCarouselCard(module: m, onTap: () => _open(m)),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_modules.length, (i) {
              final active = (_page.round() % _modules.length == i);
              return AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: active
                      ? ThemeProvider.currentPrimary
                      : ThemeProvider.cardInk.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(3),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          _GeserMenuPill(
            index: _page.round() % _modules.length,
            total: _modules.length,
            // Tak berujung: tombol panah selalu aktif, lewat batas modul
            // terasa berputar balik ke yang pertama/terakhir, bukan mentok.
            onPrev: () => _pageCtrl.animateToPage(_page.round() - 1,
                duration: const Duration(milliseconds: 280), curve: Curves.easeOut),
            onNext: () => _pageCtrl.animateToPage(_page.round() + 1,
                duration: const Duration(milliseconds: 280), curve: Curves.easeOut),
          ),
          const SizedBox(height: 14),
          // Cuma SATU kartu recap, disinkronkan ke modul yang lagi aktif di
          // carousel — bukan daftar scroll berisi semua modul. Itu sebabnya
          // sebelumnya terasa "ada 2 cara" (geser + scroll); sekarang cuma
          // geser saja, sama seperti video referensi.
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            child: Builder(builder: (_) {
              final m = _modules[_page.round() % _modules.length];
              return _ComicListEntry(module: m, onTap: () => _open(m));
            }),
          ),
          ],
        ),
        ),
      ),
    );

    if (!comic) {
      // Dashboard sudah memasang foto dash_manga.jpg + gelapan di belakang
      // SEMUA tab (termasuk tab Menu ini), persis seperti di Beranda. Dulu
      // halaman ini malah menimpanya dengan warna solid (ThemeProvider
      // .background) sehingga foto manga itu cuma kelihatan sedikit di
      // celah paling bawah. Sekarang biarkan transparan supaya foto manga
      // itu tampil penuh di balik seluruh halaman, sama seperti Beranda.
      return content;
    }

    return Stack(
      children: [
        Positioned.fill(child: ComicThemeAtmosphere(child: const SizedBox.shrink())),
        const Positioned.fill(child: ComicDoodleLayer()),
        content,
      ],
    );
  }
}

/// Jam + tanggal + tag status, dalam satu kartu komik — meniru kartu info
/// "20:07 WITA · Malam | MIN 11 MINGGU OKT 2026 | Infra Termux/VPS · SYAM ·
/// Full Fitur" di referensi. Jamnya berjalan sendiri (update tiap menit).
class _ComicDateTimeCard extends StatefulWidget {
  @override
  State<_ComicDateTimeCard> createState() => _ComicDateTimeCardState();
}

class _ComicDateTimeCardState extends State<_ComicDateTimeCard> {
  late DateTime _now = DateTime.now();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _dayPart {
    final h = _now.hour;
    if (h < 4) return 'Dini Hari';
    if (h < 11) return 'Pagi';
    if (h < 15) return 'Siang';
    if (h < 18) return 'Sore';
    return 'Malam';
  }

  // Nama hari/bulan Indonesia manual (tanpa bergantung pada data locale intl
  // yang mungkin belum di-inisialisasi di main.dart).
  static const _dayNames = ['SENIN', 'SELASA', 'RABU', 'KAMIS', 'JUMAT', 'SABTU', 'MINGGU'];
  static const _dayShortNames = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN'];
  static const _monthNames = [
    'JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES'
  ];

  @override
  Widget build(BuildContext context) {
    final time = DateFormat('HH:mm').format(_now);
    final dayShort = _dayShortNames[_now.weekday - 1];
    final dayNum = _now.day.toString();
    final dayFull = _dayNames[_now.weekday - 1];
    final monthYear = '${_monthNames[_now.month - 1]} ${_now.year}';

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
      decoration: BoxDecoration(
        color: ThemeProvider.card,
        borderRadius: BorderRadius.circular(18),
        border: _menuCardBorder(comicWidth: 2.5),
        boxShadow: ThemeProvider.isComic3D
            ? [BoxShadow(color: ThemeProvider.cardInk.withOpacity(0.35), offset: const Offset(3, 4))]
            : [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 14, offset: const Offset(0, 5))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 42, height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: ThemeProvider.accent,
              borderRadius: BorderRadius.circular(12),
              border: _menuCardBorder(comicWidth: 2),
            ),
            child: Icon(Icons.access_time_filled_rounded, color: ThemeProvider.cardInk, size: 20),
          ),
          const SizedBox(width: 10),
          Text(time,
              style: TextStyle(
                  color: ThemeProvider.text, fontSize: 24, fontWeight: FontWeight.w900,
                  fontStyle: ThemeProvider.isComic3D ? FontStyle.italic : FontStyle.normal)),
          const SizedBox(width: 6),
          Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Text('WITA · $_dayPart', style: TextStyle(color: ThemeProvider.textSub, fontSize: 11)),
          ),
          const Spacer(),
          Container(width: 1.4, height: 34, color: ThemeProvider.cardInk.withOpacity(0.18)),
          const SizedBox(width: 10),
          Container(
            width: 42, height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0xFFE63A2E),
              borderRadius: BorderRadius.circular(12),
              border: _menuCardBorder(comicWidth: 2),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(dayShort, style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w800)),
              Text(dayNum, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
            ]),
          ),
          const SizedBox(width: 8),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(dayFull,
                style: TextStyle(
                    color: const Color(0xFFE63A2E), fontSize: 13, fontWeight: FontWeight.w900,
                    fontStyle: ThemeProvider.isComic3D ? FontStyle.italic : FontStyle.normal)),
            Text(monthYear, style: TextStyle(color: ThemeProvider.textSub, fontSize: 10.5)),
          ]),
        ]),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: ThemeProvider.accent.withOpacity(0.28),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _tag(Icons.hub_rounded, 'Infra Termux/VPS'),
            _dot(),
            _tag(Icons.shield_rounded, 'SYAM'),
            _dot(),
            _tag(Icons.bolt_rounded, 'Full Fitur'),
          ]),
        ),
      ]),
    );
  }

  Widget _tag(IconData icon, String label) => Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 12, color: ThemeProvider.cardInk),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(color: ThemeProvider.cardInk, fontSize: 10.5, fontWeight: FontWeight.w700)),
      ]);

  Widget _dot() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Container(width: 3, height: 3, decoration: BoxDecoration(shape: BoxShape.circle, color: ThemeProvider.cardInk.withOpacity(0.5))),
      );
}

/// Sticker-style headline used for comic headers: a solid-colour copy of the
/// text offset behind the main black text, like a drop shadow printed on
/// paper. Mirrors the hand-lettered titles in the reference screens.
class _ComicSticker extends StatelessWidget {
  final String text;
  final double fontSize;
  final TextAlign align;
  const _ComicSticker({required this.text, required this.fontSize, this.align = TextAlign.left});

  @override
  Widget build(BuildContext context) {
    final comic = ThemeProvider.isComic3D;
    final style = TextStyle(
      fontSize: fontSize,
      fontWeight: FontWeight.w900,
      fontStyle: comic ? FontStyle.italic : FontStyle.normal,
      letterSpacing: 0.2,
      height: 1.0,
    );
    // Efek "sticker" (teks ganda offset di belakang) cuma dipakai di Comic
    // 3D. Di Classic cukup judul tebal polos, sesuai tampilan modern/bersih
    // referensi (bukan gaya komik).
    if (!comic) {
      return Text(text, textAlign: align, style: style.copyWith(color: ThemeProvider.text));
    }
    return Stack(
      children: [
        Transform.translate(
          offset: const Offset(2.5, 2.5),
          child: Text(text,
              textAlign: align,
              style: style.copyWith(color: ThemeProvider.accent.withOpacity(0.85))),
        ),
        Text(text, textAlign: align, style: style.copyWith(color: ThemeProvider.cardInk)),
      ],
    );
  }
}

/// "< GESER MENU (n/total) >" pill, matching the reference screenshot.
class _GeserMenuPill extends StatelessWidget {
  final int index;
  final int total;
  final VoidCallback? onPrev;
  final VoidCallback? onNext;
  const _GeserMenuPill({required this.index, required this.total, this.onPrev, this.onNext});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
        decoration: BoxDecoration(
          color: ThemeProvider.cardSurface,
          borderRadius: BorderRadius.circular(30),
          border: _menuCardBorder(comicWidth: 2.4),
          boxShadow: _menuCardShadow(comicOffset: const Offset(2.5, 3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.chevron_left_rounded,
                size: 18, color: ThemeProvider.cardInk.withOpacity(onPrev == null ? 0.3 : 1)),
            const SizedBox(width: 4),
            Text('GESER MENU (${index + 1}/$total)',
                style: TextStyle(
                    color: ThemeProvider.cardInk,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.3)),
            const SizedBox(width: 4),
            Icon(Icons.chevron_right_rounded,
                size: 18, color: ThemeProvider.cardInk.withOpacity(onNext == null ? 0.3 : 1)),
          ],
        ),
      ),
    );
  }
}

/// Comic carousel card: a big circular icon pokes out above a thick-bordered
/// paper card with hard offset shadow, title, subtitle and a yellow tag pill.
class _ComicCarouselCard extends StatelessWidget {
  final MenuModule module;
  final VoidCallback onTap;
  const _ComicCarouselCard({required this.module, required this.onTap});

  @override
  Widget build(BuildContext context) {
    const circle = 92.0;
    // The icon circle and the card sit fully apart with a clear gap
    // between them -- never overlapping the title underneath.
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: circle,
            height: circle,
            decoration: BoxDecoration(
              color: module.color,
              shape: BoxShape.circle,
              border: ThemeProvider.isComic3D
                  ? Border.all(color: ThemeProvider.cardInk, width: 3)
                  : Border.all(color: Colors.white, width: 3),
              boxShadow: _menuCardShadow(comicOffset: const Offset(3, 4)),
            ),
            child: Icon(module.icon, color: Colors.white, size: 38),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
            decoration: BoxDecoration(
              color: ThemeProvider.cardSurface,
              borderRadius: BorderRadius.circular(26),
              border: _menuCardBorder(comicWidth: 3),
              boxShadow: _menuCardShadow(comicOffset: const Offset(5, 6)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(module.title,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ThemeProvider.cardInk, fontSize: 19, fontWeight: FontWeight.w900)),
                const SizedBox(height: 5),
                Text(module.subtitle,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: ThemeProvider.cardMuted, fontSize: 11.5)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: ThemeProvider.accent,
                    borderRadius: BorderRadius.circular(16),
                    border: _menuCardBorder(comicWidth: 2),
                  ),
                  child: Text(module.tag,
                      style: TextStyle(
                          color: ThemeProvider.onAccent,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Comic list entry: a compact icon+title row, followed by a full-width
/// yellow "⚡ BUKA ..." button, matching "BUKA BUG & PAIRING" in the reference.
class _ComicListEntry extends StatelessWidget {
  final MenuModule module;
  final VoidCallback onTap;
  const _ComicListEntry({required this.module, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: ThemeProvider.cardSurface,
            borderRadius: BorderRadius.circular(18),
            border: _menuCardBorder(comicWidth: 2.6),
            boxShadow: _menuCardShadow(comicOffset: const Offset(3.5, 4)),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: module.color,
                  shape: BoxShape.circle,
                  border: ThemeProvider.isComic3D
                      ? Border.all(color: ThemeProvider.cardInk, width: 2)
                      : Border.all(color: Colors.white, width: 2),
                ),
                child: Icon(module.icon, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(module.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: ThemeProvider.cardInk, fontSize: 14.5, fontWeight: FontWeight.w900)),
                    Text(module.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: ThemeProvider.cardMuted, fontSize: 11.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        _ComicYellowButton(label: 'Buka ${module.title}', onTap: onTap),
      ],
    );
  }
}

class _ComicYellowButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _ComicYellowButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(26),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 15),
          decoration: BoxDecoration(
            color: ThemeProvider.accent,
            borderRadius: BorderRadius.circular(26),
            border: ThemeProvider.isComic3D ? _menuCardBorder(comicWidth: 2.6) : null,
            boxShadow: _menuCardShadow(comicOffset: const Offset(3.5, 4)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.bolt_rounded, color: ThemeProvider.onAccent, size: 18),
              const SizedBox(width: 8),
              Flexible(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ThemeProvider.onAccent,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Sub-menu opened from the "Bug & Pairing" module: the 4 destinations the
/// user asked for, reusing the pages that already exist elsewhere in the app.
class BugPairingMenuPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;

  const BugPairingMenuPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    this.listBug = const [],
  });

  @override
  State<BugPairingMenuPage> createState() => _BugPairingMenuPageState();
}

class _BugPairingMenuPageState extends State<BugPairingMenuPage> {
  // Geser biasa, berhenti di modul pertama/terakhir — beda dari carousel
  // Menu Utama yang tak berujung.
  late final PageController _pageCtrl = PageController(viewportFraction: 1.0);
  double _page = 0;

  @override
  void initState() {
    super.initState();
    _pageCtrl.addListener(() {
      if (mounted) setState(() => _page = _pageCtrl.page ?? 0);
    });
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    super.dispose();
  }

  late final List<MenuModule> _items = [
    MenuModule(
      title: 'Sender Manager',
      subtitle: 'Kelola sender WhatsApp',
      tag: 'WA',
      icon: Icons.dns_rounded,
      color: const Color(0xFF22C55E),
      pageBuilder: (_) => BugSenderPage(
          sessionKey: widget.sessionKey, username: widget.username, role: widget.role),
    ),
    MenuModule(
      title: 'Bug Group',
      subtitle: 'Kirim bug ke group WhatsApp',
      tag: 'GROUP',
      icon: Icons.group_rounded,
      color: const Color(0xFF16A34A),
      pageBuilder: (_) => BugGroupPage(sessionKey: widget.sessionKey, role: widget.role),
    ),
    MenuModule(
      title: 'Custom Payload',
      subtitle: 'Setting custom delay & loops',
      tag: 'CUSTOM',
      icon: Icons.tune_rounded,
      color: const Color(0xFFEC4899),
      pageBuilder: (_) => CustomPayloadPage(
        sessionKey: widget.sessionKey,
        role: widget.role,
        listBug: widget.listBug,
        username: widget.username,
        password: widget.password,
        expiredDate: widget.expiredDate,
      ),
    ),
    MenuModule(
      title: 'Home Page',
      subtitle: 'Bug tanpa custom, siap pakai',
      tag: 'HOME',
      icon: Icons.bug_report_rounded,
      color: const Color(0xFF1565C0),
      pageBuilder: (_) => home.HomePage(
        username: widget.username,
        password: widget.password,
        listBug: widget.listBug,
        role: widget.role,
        expiredDate: widget.expiredDate,
        sessionKey: widget.sessionKey,
      ),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final comic = ThemeProvider.isComic3D;

    final body = SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 6, 14, 4),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_rounded, color: ThemeProvider.cardInk),
                  onPressed: () => Navigator.of(context).maybePop(),
                ),
                const Expanded(
                  child: Column(
                    children: [
                      _ComicSticker(text: 'BUG & PAIRING', fontSize: 19, align: TextAlign.center),
                      SizedBox(height: 2),
                      _BugPairingSubtitle(),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.palette_rounded, color: ThemeProvider.cardInk),
                  onPressed: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => const ThemeSettingsPage())),
                ),
              ],
            ),
          ),
          // "Server Online" tetap diam di atas (bukan bagian carousel),
          // sisanya cuma GESER — tidak ada daftar scroll terpisah lagi,
          // sama seperti video referensi.
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const _ComicSticker(text: 'SERVER & TOOLS', fontSize: 23),
              const SizedBox(height: 12),
              const _ServerOnlineCard(),
            ]),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: ScrollConfiguration(
              behavior: const _NoGlowScrollBehavior(),
              child: PageView.builder(
                controller: _pageCtrl,
                itemCount: _items.length,
                itemBuilder: (context, i) {
                  final m = _items[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    child: _ComicCarouselCard(
                      module: m,
                      onTap: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: m.pageBuilder)),
                    ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_items.length, (i) {
              final active = (_page.round() == i);
              return AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 18 : 6,
                height: 6,
                decoration: BoxDecoration(
                  color: active
                      ? ThemeProvider.currentPrimary
                      : ThemeProvider.cardInk.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(3),
                ),
              );
            }),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );

    if (!comic) {
      return Scaffold(backgroundColor: ThemeProvider.background, body: body);
    }

    return Scaffold(
      backgroundColor: ThemeProvider.comicPaper,
      body: Stack(
        children: [
          Positioned.fill(child: ComicThemeAtmosphere(child: const SizedBox.shrink())),
          const Positioned.fill(child: ComicDoodleLayer()),
          body,
        ],
      ),
    );
  }
}

// Small non-const text whose only job is to pick up ThemeProvider's current
// colour; lets the header above stay a `const` subtree otherwise.
class _BugPairingSubtitle extends StatelessWidget {
  const _BugPairingSubtitle();
  @override
  Widget build(BuildContext context) => Text('server DARK LIGHT di HP',
      style: TextStyle(color: ThemeProvider.cardMuted, fontSize: 10.5));
}

class _ServerOnlineCard extends StatelessWidget {
  const _ServerOnlineCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ThemeProvider.cardSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ThemeProvider.cardInk, width: 3),
        boxShadow: [BoxShadow(color: ThemeProvider.cardInk, offset: const Offset(4, 5))],
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: const Color(0xFF22C55E),
              shape: BoxShape.circle,
              border: Border.all(color: ThemeProvider.cardInk, width: 2),
            ),
            child: const Icon(Icons.dns_rounded, color: Colors.white, size: 19),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Server Online',
                    style: TextStyle(
                        color: Color(0xFF16A34A), fontWeight: FontWeight.w900, fontSize: 14.5)),
                Text('server terhubung ke pusat (1.6.79)',
                    style: TextStyle(color: ThemeProvider.cardMuted, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Placeholder page for modules that aren't built yet. Shown for everything
/// outside "Bug & Pairing" on the Menu Utama screen.
class ComingSoonPage extends StatelessWidget {
  final String title;
  const ComingSoonPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final comic = ThemeProvider.isComic3D;

    final body = SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 6, 14, 4),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back_rounded, color: ThemeProvider.cardInk),
                  onPressed: () => Navigator.of(context).maybePop(),
                ),
                Expanded(
                  child: Text(title,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: ThemeProvider.cardInk, fontSize: 16, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 48),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      color: ThemeProvider.accent,
                      shape: BoxShape.circle,
                      border: Border.all(color: ThemeProvider.cardInk, width: 3),
                      boxShadow: [BoxShadow(color: ThemeProvider.cardInk, offset: const Offset(4, 5))],
                    ),
                    child: Icon(Icons.hourglass_top_rounded, color: ThemeProvider.onAccent, size: 40),
                  ),
                  const SizedBox(height: 20),
                  _ComicSticker(text: 'COMING SOON', fontSize: 24, align: TextAlign.center),
                  const SizedBox(height: 8),
                  Text('$title sedang dalam pengembangan',
                      textAlign: TextAlign.center, style: TextStyle(color: ThemeProvider.cardMuted, fontSize: 13)),
                ],
              ),
            ),
          ),
        ],
      ),
    );

    if (!comic) {
      return Scaffold(backgroundColor: ThemeProvider.background, body: body);
    }
    return Scaffold(
      backgroundColor: ThemeProvider.comicPaper,
      body: Stack(
        children: [
          Positioned.fill(child: ComicThemeAtmosphere(child: const SizedBox.shrink())),
          const Positioned.fill(child: ComicDoodleLayer()),
          body,
        ],
      ),
    );
  }
}
