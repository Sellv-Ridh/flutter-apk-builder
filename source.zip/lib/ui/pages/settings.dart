import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:Aq/core/app/runtimeDatas.dart';
import 'package:Aq/ui/pages/settingPages/account.dart';
import 'package:Aq/ui/pages/settingPages/appInfo.dart';
import 'package:Aq/ui/pages/settingPages/common.dart';
import 'package:Aq/ui/pages/settingPages/general.dart';
import 'package:Aq/ui/pages/settingPages/player.dart';
import 'package:Aq/ui/pages/settingPages/ui.dart';
import 'package:flutter/material.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class SettingItem {
  final dynamic icon;
  final String label;
  final Widget navigateTo;
  final String description;

  SettingItem({
    required this.icon,
    required this.label,
    required this.navigateTo,
    required this.description,
  });
}

class _SettingsPageState extends State<SettingsPage> {
  final List<SettingItem> settingItems = [
    SettingItem(
        icon: Icons.account_circle, label: "Account", description: "Personal stuff", navigateTo: AccountSetting()),
    SettingItem(icon: Icons.brush_rounded, label: "UI", description: "Colors n Visuals", navigateTo: ThemeSetting()),
    SettingItem(
        icon: Icons.play_circle_fill_rounded,
        label: "Player",
        description: "Tailor your playback",
        navigateTo: PlayerSetting()),
    SettingItem(icon: Icons.tune_rounded, label: "General", description: "Basic tweaks", navigateTo: GeneralSetting()),
    SettingItem(
        icon: Icons.info_outline_rounded, label: "App Info", description: "The App stuff", navigateTo: AppInfoSetting())
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.backgroundColor,
      appBar: settingPagesAppBar(context),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(left: MediaQuery.of(context).padding.left),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.only(top: 40, left: 20, bottom: 40),
                child: Text(
                  "Settings",
                  style: TextStyle(fontFamily: "Rubik", fontSize: 40, color: appTheme.textMainColor),
                ),
              ),
              ListView.builder(
                itemCount: settingItems.length,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) => Container(
                  padding: EdgeInsets.only(left: 15, right: 15, top: 5, bottom: 5),
                  child: Container(
                    // margin: EdgeInsets.only(left: 15, right: 15, top: 5, bottom: 5),
                    decoration:
                        BoxDecoration(color: appTheme.backgroundSubColor, borderRadius: BorderRadius.circular(20)),
                    clipBehavior: Clip.hardEdge,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context)
                              .push(
                            PageRouteBuilder(
                              pageBuilder: (context, anim, anim2) {
                                return settingItems[index].navigateTo;
                              },
                              transitionDuration: Duration(milliseconds: 100),
                              reverseTransitionDuration: Duration(milliseconds: 100),
                              transitionsBuilder: (context, animation, secondaryAnimation, child) {
                                // final tween = Tween(begin: Offset(1.0, 0.0), end: Offset.zero);
                                // final curvedAnimation = CurvedAnimation(
                                //   parent: animation,
                                //   curve: Curves.ease,
                                // );
                                return FadeTransition(
                                  opacity: animation,
                                  child: child,
                                );
                                // return SlideTransition(
                                //   position: tween.animate(curvedAnimation),
                                //   child: child,
                                // );
                              },
                            ),
                          )
                              .then((val) {
                            if (mounted) setState(() {});
                          });
                        },
                        focusColor: appTheme.textSubColor,
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  _DynamicIcon(
                                    settingItems[index].icon,
                                    color: appTheme.textMainColor,
                                    size: 35,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          settingItems[index].label,
                                          style: TextStyle(
                                              fontFamily: "NotoSans",
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20,
                                              color: appTheme.textMainColor),
                                        ),
                                        Text(
                                          settingItems[index].description,
                                          style: TextStyle(
                                            fontFamily: "NunitoSans",
                                            color: appTheme.textSubColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              Icon(
                                Icons.keyboard_arrow_right_rounded,
                                color: appTheme.textMainColor,
                                size: 30,
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
