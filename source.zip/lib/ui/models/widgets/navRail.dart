import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:Aq/core/app/runtimeDatas.dart';
import 'package:Aq/ui/models/widgets/bottomBar.dart';
import 'package:flutter/material.dart';

class AnimeStreamNavDestination {
  final dynamic icon;
  final String label;
  final Color? selectedColor;
  final Color? unselectedColor;
  final Color? selectedIconColor;
  final Color? unselectedIconColor;
  final VoidCallback? onClick;

  const AnimeStreamNavDestination({
    required this.icon,
    required this.label,
    this.selectedColor,
    this.unselectedColor,
    this.selectedIconColor,
    this.unselectedIconColor,
    this.onClick,
  });
}

class AnimeStreamNavRail extends StatefulWidget {
  final List<AnimeStreamNavDestination> destinations;
  final AnimeStreamBottomBarController controller;
  final int initialIndex;
  final bool shouldExpand;
  final bool autoCollapse;
  const AnimeStreamNavRail({
    super.key,
    required this.destinations,
    required this.controller,
    required this.initialIndex,
    this.shouldExpand = false, // Expanded mode
    this.autoCollapse = true, // Collapse under split width (1200)
  });

  @override
  State<AnimeStreamNavRail> createState() => _AnimeStreamNavRailState();
}

class _AnimeStreamNavRailState extends State<AnimeStreamNavRail> {
  @override
  void initState() {
    super.initState();
    widget.controller.currentIndex = widget.initialIndex;
  }

  final Set<int> hoveredIndices = {};

  @override
  Widget build(BuildContext context) {
    final shouldCollapse = (MediaQuery.sizeOf(context).width < 1200) && widget.autoCollapse;

    //
    final double width = shouldCollapse || !widget.shouldExpand ? 60 : MediaQuery.sizeOf(context).width;
    return Container(
      margin: shouldCollapse ? null : EdgeInsets.only(left: 8),
      width: width,
      constraints: BoxConstraints(minWidth: 60, maxWidth: 220),
      child: ValueListenableBuilder(
          valueListenable: widget.controller.currentIndexNotifier,
          builder: (context, currentIndex, child) {
            return ListView.builder(
                itemCount: widget.destinations.length,
                itemBuilder: (context, index) {
                  final item = widget.destinations[index];
                  final controller = widget.controller;
                  final isNonNavButton = controller.nonViewIndices.contains(index);

                  final hovered = hoveredIndices.contains(index);

                  return MouseRegion(
                    onEnter: (_) => setState(() {
                      hoveredIndices.add(index);
                    }),
                    onExit: (_) => setState(() {
                      hoveredIndices.remove(index);
                    }),
                    cursor: SystemMouseCursors.click,
                    child: GestureDetector(
                      onTap: () {
                        if (item.onClick != null)
                          return item.onClick?.call();
                        else if (!isNonNavButton) controller.currentIndex = index;
                      },
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: widget.controller.animDuration),
                        height: 50,
                        // width: 50,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: currentIndex == index && !isNonNavButton
                              ? (item.selectedColor ?? appTheme.accentColor)
                              : hovered
                                  ? appTheme.backgroundSubColor.withAlpha(150)
                                  : (item.unselectedColor ?? appTheme.backgroundSubColor),
                        ),
                        margin: EdgeInsets.all(5),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: shouldCollapse ? MainAxisAlignment.center : MainAxisAlignment.start,
                            children: [
                              _DynamicIcon(
                                item.icon,
                                size: 30,
                                color: currentIndex == index && !isNonNavButton
                                    ? (item.selectedIconColor ?? appTheme.onAccent)
                                    : (item.unselectedIconColor ?? appTheme.textMainColor),
                              ),
                              if (!shouldCollapse && widget.shouldExpand)
                                Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Text(
                                    widget.destinations[index].label,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: currentIndex == index && !isNonNavButton
                                          ? (item.selectedIconColor ?? appTheme.onAccent)
                                          : (item.unselectedIconColor ?? appTheme.textMainColor),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                });
          }),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
