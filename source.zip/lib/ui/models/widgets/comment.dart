import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:Aq/core/app/runtimeDatas.dart';
import 'package:Aq/core/models/comment_model.dart';
import 'package:flutter/material.dart';

class CommentItem extends StatefulWidget {
  final Comment comment;
  const CommentItem({super.key, required this.comment});

  @override
  State<CommentItem> createState() => _CommentItemState();
}

class _CommentItemState extends State<CommentItem> {
  String _getFriendlyTimeDifference() {
    final diff = DateTime.now().difference(widget.comment.updatedAt);
    if (diff.inDays > 0) return "${diff.inDays} day${diff.inDays > 1 ? "s" : ''} ago";
    if (diff.inHours > 0) return "${diff.inHours} hour${diff.inHours > 1 ? "s" : ''} ago";
    if (diff.inMinutes > 0) return "${diff.inMinutes} minute${diff.inMinutes > 1 ? "s" : ''} ago";
    return "just now";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 15),
      // decoration: BoxDecoration(color: appTheme.backgroundColor),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                foregroundImage: widget.comment.avatarUrl != null ? NetworkImage(widget.comment.avatarUrl!) : null,
                backgroundColor: appTheme.backgroundSubColor.withAlpha(80),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.comment.username,
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      _getFriendlyTimeDifference(),
                      style: TextStyle(fontSize: 12, color: appTheme.textSubColor),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              widget.comment.content,
              style: const TextStyle(fontSize: 15),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                _buildVoteButton(
                    icon: Icons.keyboard_arrow_up_rounded, active: widget.comment.userVote == 1, onPressed: () {}),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: Text("${widget.comment.score}"),
                ),
                _buildVoteButton(
                    icon: Icons.keyboard_arrow_down_rounded,
                    active: widget.comment.userVote == -1,
                    onPressed: () {
                      // Handle downvote logic
                    }),
                Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(color: appTheme.backgroundColor, borderRadius: BorderRadius.circular(12)),
                    child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text("${widget.comment.repliesCount} "),
                    Icon(Icons.reply_rounded),
                  ],
                )),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildVoteButton({required dynamic icon, required bool active, required VoidCallback onPressed}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(100),
        child: _DynamicIcon(
          icon,
          size: 28,
          color: active ? appTheme.accentColor : appTheme.textSubColor,
        ),
      ),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
