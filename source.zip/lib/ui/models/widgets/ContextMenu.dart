import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:ui';

import 'package:Aq/core/app/runtimeDatas.dart';
import 'package:flutter/material.dart';

typedef ContextMenuBuilder = Widget Function(BuildContext context, Offset offset);

class ContextMenu extends StatefulWidget {
  final Widget child;
  final Widget? header;
  final List<ContextMenuItem> menuItems;
  const ContextMenu({super.key, required this.child, required this.menuItems, this.header});

  @override
  State<ContextMenu> createState() => _ContextMenuState();
}

class _ContextMenuState extends State<ContextMenu> {
  ContextMenuController controller = ContextMenuController();

  void _showContextMenu(Offset pos) {
    _hideContextMenu();

    final hoverList = List.generate(widget.menuItems.length, (ind) => ValueNotifier<bool>(false));

    const double width = 230 + 8;

    controller.show(
        context: context,
        contextMenuBuilder: (context) => Stack(
              children: [
                Positioned.fill(
                    child: GestureDetector(
                  onTap: () => _hideContextMenu(),
                  behavior: HitTestBehavior.translucent,
                )),
                Positioned(
                  top: pos.dy,
                  left: pos.dx + width > MediaQuery.of(context).size.width ? pos.dx - width : pos.dx,
                  child: ClipRRect(
                    clipBehavior: Clip.antiAlias,
                    borderRadius: BorderRadius.circular(8),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          border: Border.all(color: appTheme.textSubColor.withAlpha(70)),
                          borderRadius: BorderRadius.circular(8),
                          color: appTheme.textMainColor.withAlpha(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withAlpha(150),
                              blurRadius: 1,
                              spreadRadius: 10,
                            ),
                          ],
                        ),
                        height:
                            (widget.menuItems.length * 40) + 12 + (widget.header != null ? 50 : 0), //add the padding
                        width: width,
                        child: Column(
                          children: [
                            if (widget.header != null) SizedBox(height: 50, child: widget.header!),
                            Expanded(
                              child: ListView.separated(
                                padding: EdgeInsets.zero,
                                physics: NeverScrollableScrollPhysics(),
                                itemBuilder: (context, index) {
                                  return MouseRegion(
                                    onEnter: (event) => hoverList[index].value = true,
                                    onExit: (event) => hoverList[index].value = false,
                                    child: ValueListenableBuilder(
                                      valueListenable: hoverList[index],
                                      builder: (context, hovered, child) => GestureDetector(
                                        onTap: () {
                                          widget.menuItems[index].onClick();
                                          _hideContextMenu();
                                        },
                                        child: Container(
                                            height: 40,
                                            decoration: BoxDecoration(
                                                color: hovered ? Colors.white.withAlpha(10) : null,
                                                borderRadius: BorderRadius.circular(8)),
                                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                            child: widget.menuItems[index]),
                                      ),
                                    ),
                                  );
                                },
                                separatorBuilder: (context, int) {
                                  return Container(
                                    height: 1,
                                    margin: EdgeInsets.symmetric(horizontal: 20),
                                    color: appTheme.textSubColor.withAlpha(70),
                                  );
                                },
                                itemCount: widget.menuItems.length,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ));
  }

  void _hideContextMenu() {
    controller.remove();
  }

  @override
  void dispose() {
    controller.remove();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onSecondaryTapUp: (details) {
        _showContextMenu(details.globalPosition);
      },
      child: widget.child,
    );
  }
}

class ContextMenuItem extends StatelessWidget {
  final dynamic icon;
  final String label;
  final VoidCallback onClick;

  ContextMenuItem({required this.icon, required this.label, required this.onClick});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        _DynamicIcon(
          icon,
          color: Colors.white,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Text(
            label,
            style: TextStyle(fontFamily: "NotoSans", fontSize: 16, color: Colors.white),
          ),
        ),
      ],
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
