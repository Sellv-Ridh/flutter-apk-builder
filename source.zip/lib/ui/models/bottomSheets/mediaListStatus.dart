import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:math';

import 'package:Aq/core/app/runtimeDatas.dart';
import 'package:Aq/core/commons/utils.dart';
import 'package:Aq/core/database/handler/syncHandler.dart';
import 'package:Aq/ui/models/providers/infoProvider.dart';
import 'package:Aq/ui/models/snackBar.dart';
import 'package:flutter/material.dart';

class MediaListStatusBottomSheet extends StatefulWidget {
  final InfoProvider provider;

  const MediaListStatusBottomSheet({
    super.key,
    required this.provider,
  });

  @override
  State<MediaListStatusBottomSheet> createState() => _MediaListStatusBottomSheetState();
}

class _MediaListStatusBottomSheetState extends State<MediaListStatusBottomSheet> {
  @override
  void initState() {
    super.initState();
    itemList = makeItemList();
    textEditingController.value = TextEditingValue(text: "${widget.provider.watched}");
  }

  final List<String> statuses = ["PLANNING", "CURRENT", "DROPPED", "COMPLETED"];

  List<DropdownMenuEntry> itemList = [];
  String? initialSelection;

  List<DropdownMenuEntry> makeItemList() {
    final List<DropdownMenuEntry> itemList = [];
    statuses.forEach((element) {
      itemList.add(
        DropdownMenuEntry(
          value: element,
          label: element,
          style: ButtonStyle(
            foregroundColor: WidgetStatePropertyAll(appTheme.textMainColor),
            textStyle: WidgetStatePropertyAll(
              TextStyle(
                color: appTheme.textMainColor,
                fontFamily: "Rubik",
                fontSize: 16,
              ),
            ),
          ),
        ),
      );
    });
    return itemList;
  }

  String getInitialSelection() {
    if (widget.provider.mediaListStatus == null) {
      initialSelection = itemList[0].value;
      print("set initial to $initialSelection");
      return itemList[0].value;
    } else {
      initialSelection = widget.provider.mediaListStatus!.name;
      selectedValue = initialSelection;
      return widget.provider.mediaListStatus!.name;
    }
  }

  String? selectedValue;

  TextEditingController textEditingController = TextEditingController();
  TextEditingController menuController = TextEditingController();

  bool markedDelete = false;

  @override
  Widget build(BuildContext context) {
    final provider = widget.provider;
    final isDialog = MediaQuery.of(context).size.width > 800;

    // Thanks Claude for the design!!!
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 24,
        right: 24,
        top: isDialog ? 16 : 24,
      ),
      decoration: BoxDecoration(
        color: appTheme.backgroundColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(isDialog ? 16 : 24),
          topRight: Radius.circular(isDialog ? 16 : 24),
          bottomLeft: Radius.circular(isDialog ? 16 : 0),
          bottomRight: Radius.circular(isDialog ? 16 : 0),
        ),
        boxShadow: isDialog
            ? [
                BoxShadow(
                  color: Colors.black.withAlpha(51),
                  blurRadius: 20,
                  offset: Offset(0, 5),
                )
              ]
            : null,
      ),
      width: isDialog ? min(500, MediaQuery.of(context).size.width * 0.85) : double.infinity,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            Padding(
              padding: EdgeInsets.only(bottom: 20, top: isDialog ? 8 : 0),
              child: Text(
                "Update Progress",
                style: TextStyle(
                  color: appTheme.textMainColor,
                  fontFamily: "Rubik",
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            // Status Dropdown
            Text(
              "Status",
              style: TextStyle(
                color: appTheme.textMainColor.withAlpha(204),
                fontFamily: "Poppins",
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: EdgeInsets.only(right: 8),
                    child: markedDelete
                        ? Text(
                            "REMOVED",
                            style: TextStyle(fontWeight: FontWeight.bold, fontFamily: "Poppins", fontSize: 16),
                          )
                        : DropdownMenu(
                            controller: menuController,
                            onSelected: (value) {
                              if (value != initialSelection) selectedValue = value;
                            },
                            enableSearch: false,
                            menuStyle: MenuStyle(
                              backgroundColor: WidgetStatePropertyAll(appTheme.backgroundColor),
                              shape: WidgetStatePropertyAll(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: BorderSide(
                                    width: 1,
                                    color: appTheme.textMainColor.withAlpha(51),
                                  ),
                                ),
                              ),
                              elevation: WidgetStatePropertyAll(8),
                              // padding: WidgetStatePropertyAll(EdgeInsets.symmetric(vertical: 8)),
                            ),
                            textStyle: TextStyle(
                              color: appTheme.textMainColor,
                              fontFamily: "Poppins",
                              fontSize: 16,
                            ),
                            inputDecorationTheme: InputDecorationTheme(
                              filled: true,
                              fillColor: appTheme.backgroundColor,
                              border: OutlineInputBorder(
                                borderSide: BorderSide(width: 1, color: appTheme.textMainColor.withAlpha(51)),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  width: 1,
                                  color: appTheme.textMainColor.withAlpha(51),
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  width: 1.5,
                                  color: appTheme.accentColor,
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            ),
                            width: double.infinity,
                            initialSelection: getInitialSelection(),
                            dropdownMenuEntries: itemList,
                          ),
                  ),
                ),
                _ProgressButton(
                  icon: Icons.delete_outline_rounded,
                  onPressed: () async {
                    setState(() {
                      markedDelete = !markedDelete;
                    });
                  },
                  color: markedDelete ? appTheme.modalSheetBackgroundColor : appTheme.accentColor,
                  backgroundColor: markedDelete ? appTheme.accentColor : appTheme.backgroundColor,
                  border: Border.all(
                    color: appTheme.textMainColor.withAlpha(51),
                  ),
                )
              ],
            ),

            // Progress Section
            const SizedBox(height: 24),
            Text(
              "Progress",
              style: TextStyle(
                color: appTheme.textMainColor.withAlpha(204),
                fontFamily: "Poppins",
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              decoration: BoxDecoration(
                color: appTheme.backgroundColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: appTheme.textMainColor.withAlpha(25),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _ProgressButton(
                    icon: Icons.remove_rounded,
                    onPressed: () {
                      final currentNumber =
                          int.parse(textEditingController.value.text.isEmpty ? "0" : textEditingController.value.text);
                      if (currentNumber < 1) return;
                      textEditingController.value = TextEditingValue(text: "${currentNumber - 1}");
                    },
                    color: appTheme.textMainColor,
                    backgroundColor: appTheme.textMainColor.withAlpha(25),
                  ),
                  Row(
                    children: [
                      Container(
                        height: 48,
                        width: 80,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: appTheme.backgroundColor,
                          border: Border.all(
                            color: appTheme.textMainColor.withAlpha(51),
                            width: 1,
                          ),
                        ),
                        child: TextField(
                          controller: textEditingController,
                          onChanged: (value) {
                            if (value.isNotEmpty && int.parse(value) > (provider.data.episodes ?? 9999)) {
                              textEditingController.value = TextEditingValue(
                                text: "${provider.data.episodes ?? 0}",
                              );
                            }
                          },
                          keyboardType: TextInputType.number,
                          textAlign: TextAlign.center,
                          decoration: InputDecoration(
                            contentPadding: EdgeInsets.zero,
                            border: InputBorder.none,
                          ),
                          style: TextStyle(
                            color: appTheme.textMainColor,
                            fontFamily: "Rubik",
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                          ),
                          autocorrect: false,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          "of ${provider.data.episodes ?? 0}",
                          style: TextStyle(
                            color: appTheme.textMainColor.withAlpha(178),
                            fontFamily: "Rubik",
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                  _ProgressButton(
                    icon: Icons.add_rounded,
                    onPressed: () {
                      final currentNumber =
                          int.parse(textEditingController.value.text.isEmpty ? "0" : textEditingController.value.text);
                      if (currentNumber + 1 >= (provider.data.episodes ?? 0)) {
                        menuController.value = TextEditingValue(text: "COMPLETED");
                        selectedValue = "COMPLETED";
                      }
                      if (currentNumber + 1 > (provider.data.episodes ?? 0)) return;
                      textEditingController.value = TextEditingValue(text: "${currentNumber + 1}");
                    },
                    color: appTheme.textMainColor,
                    backgroundColor: appTheme.textMainColor.withAlpha(25),
                  )
                ],
              ),
            ),

            // Buttons
            Padding(
              padding: EdgeInsets.only(top: 32, bottom: isDialog ? 8 : MediaQuery.of(context).padding.bottom + 16),
              child: Row(
                children: [
                  Expanded(
                    child: _ActionButton(
                      label: "Cancel",
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      backgroundColor: appTheme.textMainColor.withAlpha(25),
                      textColor: appTheme.textMainColor,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _ActionButton(
                      label: "Save",
                      onPressed: () {
                        final int progress = int.parse(textEditingController.value.text);
                        if (markedDelete) {
                          SyncHandler()
                              .deleteAnimeEntry(
                                  id: provider.data.listId ?? provider.id, otherIds: provider.altDatabases)
                              .then((val) {
                            provider.refreshListStatus(null, 0);
                          });
                          floatingSnackBar("Entry deleted!");
                          if (mounted) Navigator.pop(context);
                          return;
                        }
                        if (selectedValue != null || progress != provider.watched || provider.mediaListStatus == null) {
                          SyncHandler()
                              .mutateAnimeList(
                                  id: provider.id,
                                  status: assignItemEnum(selectedValue ?? initialSelection!),
                                  previousStatus: assignItemEnum(initialSelection),
                                  progress: progress,
                                  otherIds: provider.altDatabases)
                              .then((value) {
                            initialSelection = selectedValue ?? initialSelection;
                            provider.refreshListStatus(selectedValue ?? initialSelection!, progress);
                            floatingSnackBar("The list has been updated!");
                            if (mounted) {
                              Navigator.of(context).pop();
                            }
                          });
                        }
                      },
                      backgroundColor: appTheme.accentColor,
                      textColor: appTheme.onAccent,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    textEditingController.dispose();
    menuController.dispose();
    super.dispose();
  }
}

// Helper class for + and - buttons
class _ProgressButton extends StatelessWidget {
  final dynamic icon;
  final VoidCallback onPressed;
  final Color color;
  final Color backgroundColor;
  final Border? border;

  const _ProgressButton({
    required this.icon,
    required this.onPressed,
    required this.color,
    required this.backgroundColor,
    this.border,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(12),
            border: this.border,
          ),
          child: _DynamicIcon(
            icon,
            color: color,
            size: 24,
          ),
        ),
      ),
    );
  }
}

// Helper class for action buttons
class _ActionButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  final Color backgroundColor;
  final Color textColor;

  const _ActionButton({
    required this.label,
    required this.onPressed,
    required this.backgroundColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor,
        foregroundColor: textColor,
        padding: EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        shadowColor: Colors.transparent,
        elevation: 0,
      ),
      onPressed: onPressed,
      child: Text(
        label,
        style: TextStyle(
          fontFamily: "Poppins",
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}

// WEBA2APK_DYNAMIC_ICON_START
class _DynamicIcon extends StatelessWidget {
  final dynamic icon;
  final double? size;
  final Color? color;
  final List<Shadow>? shadows;
  final String? semanticLabel;
  final dynamic textDirection;
  final double? fill;
  final double? weight;
  final double? grade;
  final double? opticalSize;
  final bool? applyTextScaling;

  const _DynamicIcon(
    this.icon, {
    Key? key,
    this.size,
    this.color,
    this.shadows,
    this.semanticLabel,
    this.textDirection,
    this.fill,
    this.weight,
    this.grade,
    this.opticalSize,
    this.applyTextScaling,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (icon == null) return const SizedBox(width: 0, height: 0);

    bool isFontAwesome = false;
    try {
      final str = icon.toString();
      final typeStr = icon.runtimeType.toString();
      if (typeStr.contains('FaIcon') ||
          str.contains('FaIcon') ||
          str.contains('font_awesome_flutter') ||
          (icon is IconData && icon.fontPackage == 'font_awesome_flutter')) {
        isFontAwesome = true;
      }
    } catch (_) {}

    if (isFontAwesome) {
      Widget child = FaIcon(
        icon is IconData ? icon : icon,
        size: size,
        color: color,
        semanticLabel: semanticLabel,
        textDirection: textDirection,
      );
      if (shadows != null && shadows!.isNotEmpty) {
        child = DecoratedBox(
          decoration: BoxDecoration(
            boxShadow: shadows!.map((s) => BoxShadow(color: s.color, blurRadius: s.blurRadius)).toList(),
          ),
          child: child,
        );
      }
      return Center(widthFactor: 1.0, heightFactor: 1.0, child: child);
    } else {
      return Center(
        widthFactor: 1.0,
        heightFactor: 1.0,
        child: Icon(
          icon is IconData ? icon : null,
          size: size,
          color: color,
          shadows: shadows,
          semanticLabel: semanticLabel,
          textDirection: textDirection,
          fill: fill,
          weight: weight,
          grade: grade,
          opticalSize: opticalSize,
          applyTextScaling: applyTextScaling,
        ),
      );
    }
  }
}
// WEBA2APK_DYNAMIC_ICON_END
