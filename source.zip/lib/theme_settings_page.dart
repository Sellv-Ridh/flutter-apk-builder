import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

class ThemeSettingsPage extends StatefulWidget {
  const ThemeSettingsPage({super.key});

  @override
  State<ThemeSettingsPage> createState() => _ThemeSettingsPageState();
}

class _ThemeSettingsPageState extends State<ThemeSettingsPage> {
  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final comic = theme.comic3D;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pengaturan Tema'),
        actions: [
          IconButton(
            tooltip: 'Reset warna',
            onPressed: theme.loading ? null : () => theme.reset(),
            icon: const Icon(Icons.restart_alt_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            _sectionLabel(context, 'MODE TAMPILAN', 'Pilih tampilan aplikasi. Tersimpan permanen di HP.'),
            const SizedBox(height: 12),
            _styleSelector(theme),
            const SizedBox(height: 22),
            _sectionLabel(
              context,
              comic ? 'KUSTOMISASI WARNA TEMA COMIC' : 'KUSTOMISASI WARNA TEMA DEFAULT',
              'Atur 4 kanal warna sesuka hati (HEX) untuk hasil selaras & memukau.',
            ),
            const SizedBox(height: 12),
            if (comic) ...[
              // index.html "Warna sendiri": Utama, Aksen, Latar, Garis.
              // Kartu/panel (paper2), teks samar (muted) dan warna teks di atas
              // tombol (on-p / on-a) diturunkan otomatis dari 4 warna ini.
              _channelEditor(
                context,
                theme,
                label: 'Utama',
                subtitle: 'Tombol utama, judul, banner, dan elemen aktif',
                color: ThemeProvider.currentPrimary,
                onApply: (c) => theme.setCustomChannels(primary: c),
              ),
              const SizedBox(height: 10),
              _channelEditor(
                context,
                theme,
                label: 'Aksen',
                subtitle: 'Tombol aktif, label, dan highlight kuning',
                color: ThemeProvider.currentSecondary,
                onApply: (c) => theme.setCustomChannels(secondary: c),
              ),
              const SizedBox(height: 10),
              _channelEditor(
                context,
                theme,
                label: 'Latar',
                subtitle: 'Warna kertas layar & halaman aplikasi',
                color: ThemeProvider.comicPaper,
                onApply: (c) => theme.setCustomChannels(background: c),
              ),
              const SizedBox(height: 10),
              _channelEditor(
                context,
                theme,
                label: 'Garis',
                subtitle: 'Garis tepi, bayangan keras, dan teks',
                color: ThemeProvider.comicInk,
                onApply: (c) => theme.setCustomChannels(border: c),
              ),
            ] else ...[
              _channelEditor(
                context,
                theme,
                label: 'Warna Latar Layar (Background)',
                subtitle: 'Latar belakang layar & halaman aplikasi',
                color: ThemeProvider.background,
                onApply: (c) => theme.setCustomChannels(background: c),
              ),
              const SizedBox(height: 10),
              _channelEditor(
                context,
                theme,
                label: 'Warna Aksen Utama (Primary)',
                subtitle: 'Tombol utama, highlight, icon, dan elemen aktif',
                color: ThemeProvider.currentPrimary,
                onApply: (c) => theme.setCustomChannels(primary: c),
              ),
              const SizedBox(height: 10),
              _channelEditor(
                context,
                theme,
                label: 'Warna Kartu & Panel (Surface)',
                subtitle: 'Permukaan kartu menu, popup, dan modal',
                color: ThemeProvider.surface,
                onApply: (c) => theme.setCustomChannels(surface: c),
              ),
              const SizedBox(height: 10),
              _channelEditor(
                context,
                theme,
                label: 'Warna Border & Garis Tepi',
                subtitle: 'Garis batas kartu, separator, dan outline',
                color: ThemeProvider.border,
                onApply: (c) => theme.setCustomChannels(border: c),
              ),
            ],
            const SizedBox(height: 22),
            Text('TEMPLATE WARNA', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            SizedBox(
              height: 54,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                // Komik & Klasik masing-masing punya list preset sendiri —
                // tidak pernah tercampur/bentrok antar mode.
                itemCount: ThemeProvider.activePresets.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  final p = ThemeProvider.activePresets[i];
                  return _presetChip(context, p, p.id == theme.presetId, () => theme.select(p));
                },
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: theme.loading
                    ? null
                    : () async {
                        await theme.resetCustomChannels();
                        await theme.reset();
                      },
                icon: const Icon(Icons.restart_alt_rounded),
                label: Text('RESET KE WARNA ASLI DEFAULT (${comic ? 'COMIC' : 'CLASSIC'})'),
              ),
            ),
            const SizedBox(height: 26),
            Text('CONTOH TAMPILAN LANGSUNG', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            _livePreview(theme),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(BuildContext context, String title, String subtitle) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
      const SizedBox(height: 4),
      Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
    ],
  );

  // ─── Mode Tampilan: Classic vs Comic 3D ──────────────────────────────
  Widget _styleSelector(ThemeProvider theme) => Row(
    children: [
      Expanded(
        child: _modeCard(
          title: 'Classic Original',
          subtitle: 'Palet warna bebas',
          icon: Icons.terminal_rounded,
          active: !theme.comic3D,
          comicStyle: false,
          dots: const [Color(0xFF2979FF), Color(0xFF1565C0), Color(0xFFE3F2FD)],
          onTap: () => theme.setStyle('classic'),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: _modeCard(
          title: '3D Comic',
          subtitle: 'Kertas & tinta 3D',
          icon: Icons.auto_awesome_rounded,
          active: theme.comic3D,
          comicStyle: true,
          dots: const [],
          onTap: () => theme.setStyle('comic3d'),
        ),
      ),
    ],
  );

  Widget _modeCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool active,
    required bool comicStyle,
    required List<Color> dots,
    required VoidCallback onTap,
  }) {
    final bg = comicStyle ? ThemeProvider.comicPaper : Colors.white;
    final ink = comicStyle ? ThemeProvider.comicInk : const Color(0xFF1565C0);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: active ? ink : Colors.black12, width: active ? 2.2 : 1.2),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: comicStyle ? ThemeProvider.comicYellow : const Color(0xFFE3F2FD),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: comicStyle ? ThemeProvider.comicInk : const Color(0xFF1565C0), size: 20),
                  ),
                  if (active)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(20)),
                      child: const Text('AKTIF', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Text(title, style: TextStyle(color: ink, fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 2),
              Text(subtitle, style: TextStyle(color: ink.withOpacity(.65), fontSize: 11.5)),
              const SizedBox(height: 10),
              if (comicStyle)
                SizedBox(
                  height: 16,
                  child: CustomPaint(painter: _DotPainter(color: ink.withOpacity(.25)), size: const Size(double.infinity, 16)),
                )
              else
                Row(
                  children: dots
                      .map((c) => Padding(
                            padding: const EdgeInsets.only(right: 6),
                            child: Container(width: 16, height: 16, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
                          ))
                      .toList(),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── 4-channel hex color customizer ──────────────────────────────────
  Widget _channelEditor(
    BuildContext context,
    ThemeProvider theme, {
    required String label,
    required String subtitle,
    required Color color,
    required ValueChanged<Color> onApply,
  }) {
    final hex = '#${color.value.toRadixString(16).substring(2).toUpperCase()}';
    final controller = TextEditingController(text: hex);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).colorScheme.outline.withOpacity(.3)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _openPicker(context, color, onApply),
            child: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Theme.of(context).colorScheme.outline.withOpacity(.4)),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                const SizedBox(height: 2),
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 92,
            child: TextField(
              controller: controller,
              textCapitalization: TextCapitalization.characters,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
              decoration: const InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                border: OutlineInputBorder(),
              ),
              onSubmitted: (v) {
                final parsed = _parseHex(v);
                if (parsed != null) onApply(parsed);
              },
            ),
          ),
          IconButton(
            tooltip: 'Pilih warna',
            icon: const Icon(Icons.colorize_rounded, size: 20),
            onPressed: () => _openPicker(context, color, onApply),
          ),
        ],
      ),
    );
  }

  Color? _parseHex(String v) {
    var hex = v.trim().replaceFirst('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    if (hex.length != 8) return null;
    final n = int.tryParse(hex, radix: 16);
    return n == null ? null : Color(n);
  }

  void _openPicker(BuildContext context, Color initial, ValueChanged<Color> onApply) {
    var hsv = HSVColor.fromColor(initial);
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          final hex = '#${hsv.toColor().value.toRadixString(16).substring(2).toUpperCase()}';
          return AlertDialog(
            title: const Text('Pilih Warna'),
            content: SizedBox(
              width: 300,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    height: 52,
                    decoration: BoxDecoration(color: hsv.toColor(), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.black12)),
                    alignment: Alignment.center,
                    child: Text(hex, style: TextStyle(color: hsv.value > .6 ? Colors.black : Colors.white, fontWeight: FontWeight.w900)),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(labelText: 'HEX', isDense: true, border: OutlineInputBorder()),
                    controller: TextEditingController(text: hex),
                    onSubmitted: (v) {
                      final parsed = _parseHex(v);
                      if (parsed != null) setDialogState(() => hsv = HSVColor.fromColor(parsed));
                    },
                  ),
                  _slider('Hue', hsv.hue, 360, (v) => setDialogState(() => hsv = hsv.withHue(v))),
                  _slider('Saturation', hsv.saturation, 1, (v) => setDialogState(() => hsv = hsv.withSaturation(v))),
                  _slider('Brightness', hsv.value, 1, (v) => setDialogState(() => hsv = hsv.withValue(v))),
                ],
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
              FilledButton(
                onPressed: () {
                  onApply(hsv.toColor());
                  Navigator.pop(ctx);
                },
                child: const Text('Pakai'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _slider(String label, double value, double max, ValueChanged<double> onChanged) => Column(
    children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(fontSize: 12)),
        Text(max == 360 ? '${value.round()}°' : '${(value * 100).round()}%', style: const TextStyle(fontSize: 12)),
      ]),
      Slider(value: value.clamp(0, max), min: 0, max: max, onChanged: onChanged),
    ],
  );

  // ─── Preset chips ─────────────────────────────────────────────────────
  Widget _presetChip(BuildContext context, AppThemePreset p, bool selected, VoidCallback onTap) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(27),
      child: Ink(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(27),
          border: Border.all(
            color: selected ? p.primary : Theme.of(context).colorScheme.outline.withOpacity(.3),
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 14, height: 14, margin: const EdgeInsets.only(right: 3), decoration: BoxDecoration(color: p.primary, shape: BoxShape.circle)),
          Container(width: 14, height: 14, margin: const EdgeInsets.only(right: 3), decoration: BoxDecoration(color: p.secondary, shape: BoxShape.circle)),
          if (p.background != null)
            Container(
              width: 14,
              height: 14,
              margin: const EdgeInsets.only(right: 3),
              decoration: BoxDecoration(
                color: p.background,
                shape: BoxShape.circle,
                border: Border.all(color: p.border ?? Colors.black26, width: 1),
              ),
            ),
          const SizedBox(width: 6),
          Text(p.name, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: selected ? p.primary : null)),
        ]),
      ),
    ),
  );

  // ─── Live preview, mirrors "CONTOH TAMPILAN LANGSUNG" ───────────────
  Widget _livePreview(ThemeProvider theme) {
    final comic = theme.comic3D;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ThemeProvider.background,
        borderRadius: BorderRadius.circular(comic ? 18 : 20),
        border: Border.all(color: ThemeProvider.border, width: comic ? 2.5 : 1.2),
        boxShadow: comic ? [BoxShadow(color: ThemeProvider.border.withOpacity(.45), offset: const Offset(4, 5))] : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(color: ThemeProvider.currentPrimary, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [
              Icon(Icons.bolt_rounded, color: comic ? ThemeProvider.comicOnPrimary : Colors.white),
              const SizedBox(width: 10),
              Expanded(child: Text('DARK LIGHT WORKSPACE', style: TextStyle(color: comic ? ThemeProvider.comicOnPrimary : Colors.white, fontWeight: FontWeight.w900))),
              Icon(Icons.tune_rounded, color: comic ? ThemeProvider.comicOnPrimary.withOpacity(.7) : Colors.white70, size: 18),
            ]),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: ThemeProvider.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider.border.withOpacity(.4))),
            child: Row(children: [
              Container(width: 36, height: 36, decoration: BoxDecoration(color: ThemeProvider.currentPrimary.withOpacity(.15), borderRadius: BorderRadius.circular(9)), child: Icon(Icons.grid_view_rounded, color: ThemeProvider.currentPrimary, size: 18)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Harmonis & Selaras', style: TextStyle(color: ThemeProvider.text, fontWeight: FontWeight.w800, fontSize: 13)),
                    Text('Semua elemen & teks otomatis kontras dan nyaman dibaca.', style: TextStyle(color: ThemeProvider.textSub, fontSize: 11.5)),
                  ],
                ),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: ThemeProvider.currentPrimary,
                  foregroundColor: comic ? ThemeProvider.comicOnPrimary : null,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                onPressed: () {},
                child: const Text('TOMBOL UTAMA', style: TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(side: BorderSide(color: ThemeProvider.currentPrimary), padding: const EdgeInsets.symmetric(vertical: 13)),
                onPressed: () {},
                child: Text('AKSEN KEDUA', style: TextStyle(color: ThemeProvider.currentPrimary, fontWeight: FontWeight.w900)),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}

class _DotPainter extends CustomPainter {
  final Color color;
  _DotPainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    for (double x = 2; x < size.width; x += 8) {
      canvas.drawCircle(Offset(x, size.height / 2), 1.4, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DotPainter oldDelegate) => oldDelegate.color != color;
}
