import 'dart:convert';
import 'package:http/http.dart' as http;

/// ───────────────────────────────────────────────────────────────────────
/// Domain server API Aq.
///
/// Dulu domain ini di-hardcode di 16+ file (admin_page.dart, bug_sender.dart,
/// login_page.dart, dst). Sekarang SATU-SATUNYA tempat domain didefinisikan
/// adalah di sini, dan nilainya diisi otomatis saat app start oleh
/// [loadBaseUrl] dari file config.json yang disimpan di repo GitHub.
///
/// Keuntungan: kalau domain server ganti, Anda tinggal edit config.json di
/// GitHub — tidak perlu build ulang APK sama sekali. Semua 25+ file yang
/// `import 'api_config.dart';` otomatis ikut pakai domain baru begitu user
/// buka app lagi.
/// ───────────────────────────────────────────────────────────────────────

/// Nilai sementara sebelum [loadBaseUrl] selesai, dan fallback kalau GitHub
/// tidak bisa diakses sama sekali (misal device offline total saat startup).
String baseUrl = "http://dotszstrxpanel.r-cloud.my.id:25600";

/// URL raw config.json di GitHub.
/// GANTI "USERNAME" dan "REPO" di bawah ini ke repo GitHub Anda sendiri.
/// Isi file config.json di repo itu cukup:
///   { "base_url": "http://domain-baru-anda.com:25600" }
const String _remoteConfigUrl =
    "https://raw.githubusercontent.com/Sellv-Ridh/Apps-Config/main/config.json";

/// Dipanggil sekali di main.dart, sebelum runApp(), supaya baseUrl terisi
/// nilai terbaru dari GitHub sebelum ada halaman yang memakainya.
Future<void> loadBaseUrl() async {
  try {
    final res = await http
        .get(Uri.parse(_remoteConfigUrl))
        .timeout(const Duration(seconds: 8));

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      final remoteUrl = data["base_url"];
      if (remoteUrl != null && remoteUrl.toString().trim().isNotEmpty) {
        baseUrl = remoteUrl.toString().trim();
      }
    }
  } catch (_) {
    // Gagal ambil config.json (offline / repo belum ada / dsb) → tetap
    // pakai nilai fallback di atas, app tetap bisa jalan.
  }
}
