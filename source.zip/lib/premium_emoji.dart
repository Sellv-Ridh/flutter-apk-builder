import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Premium emoji badge shown next to the username. The user picks it from
/// a sheet opened by tapping the badge; the choice is stored per username.

const List<String> kSyamPremiumEmojis = [
  '📁', '📂', '📝', '📣', '📬', '🔎', '🔍', '🔐', '🔥', '🕷️',
  '🕸️', '🖤', '💥', '🗿', '🚑', '🚓', '🚕', '🚗', '🟩', '🖥️',
  '🏜️', '🛸', '🎨', '🔷', '🐦', '⭐',
];

const List<String> kSmileyEmojis = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
  '🙂', '😉', '😍', '🥰', '😘', '😎', '🤩', '🥳', '😏', '😭',
  '😡', '🤯', '😴', '🤔', '😈', '👻', '💀', '🤖', '👑', '💎',
  '🌟', '❤️', '🔥', '⚡',
];

// Normalize (trim + lowercase) so a stray space or case difference coming
// back from the login API never causes a silent key mismatch between the
// session that saved the emoji and the session that tries to load it.
/// Makes the premium emoji badge "alive": a gentle continuous float + pulse,
/// not tied to any theme so it looks right in both Classic and Comic 3D.
class AnimatedEmojiBadge extends StatefulWidget {
  final String emoji;
  final double size;
  const AnimatedEmojiBadge({super.key, required this.emoji, this.size = 16});

  @override
  State<AnimatedEmojiBadge> createState() => _AnimatedEmojiBadgeState();
}

class _AnimatedEmojiBadgeState extends State<AnimatedEmojiBadge> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, child) {
        final t = Curves.easeInOut.transform(_ctrl.value);
        return Transform.translate(
          offset: Offset(0, -3.5 * t),
          child: Transform.scale(
            scale: 1.0 + 0.10 * t,
            child: Transform.rotate(angle: (t - 0.5) * 0.12, child: child),
          ),
        );
      },
      child: Text(widget.emoji, style: TextStyle(fontSize: widget.size)),
    );
  }
}

String _prefKey(String username) => 'premium_emoji_${username.trim().toLowerCase()}';

Future<String?> loadPremiumEmoji(String username) async {
  final prefs = await SharedPreferences.getInstance();
  final v = prefs.getString(_prefKey(username));
  return (v == null || v.isEmpty) ? null : v;
}

Future<void> savePremiumEmoji(String username, String? emoji) async {
  final prefs = await SharedPreferences.getInstance();
  if (emoji == null || emoji.isEmpty) {
    await prefs.remove(_prefKey(username));
  } else {
    await prefs.setString(_prefKey(username), emoji);
  }
}

/// Opens the picker. [onChanged] is called with the new value (null = removed).
Future<void> showPremiumEmojiPicker(
  BuildContext context, {
  required String username,
  required String? current,
  required ValueChanged<String?> onChanged,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => _PremiumEmojiSheet(
      username: username,
      current: current,
      onChanged: onChanged,
    ),
  );
}

class _PremiumEmojiSheet extends StatefulWidget {
  final String username;
  final String? current;
  final ValueChanged<String?> onChanged;

  const _PremiumEmojiSheet({
    required this.username,
    required this.current,
    required this.onChanged,
  });

  @override
  State<_PremiumEmojiSheet> createState() => _PremiumEmojiSheetState();
}

class _PremiumEmojiSheetState extends State<_PremiumEmojiSheet> {
  int _tab = 0;
  late String? _selected = widget.current;

  Future<void> _pick(String? emoji) async {
    await savePremiumEmoji(widget.username, emoji);
    widget.onChanged(emoji);
    if (mounted) setState(() => _selected = emoji);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final list = _tab == 0 ? kSyamPremiumEmojis : kSmileyEmojis;
    final bottom = MediaQuery.of(context).padding.bottom;
    return Container(
      height: MediaQuery.of(context).size.height * 0.72,
      decoration: const BoxDecoration(
        color: Color(0xFFF7F9FC),
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
      padding: EdgeInsets.fromLTRB(16, 12, 16, 16 + bottom),
      child: Column(
        children: [
          Container(
            width: 44,
            height: 5,
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F0FB),
                  borderRadius: BorderRadius.circular(18),
                ),
                alignment: Alignment.center,
                child: const Text('⭐', style: TextStyle(fontSize: 26)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('Syam Emoji Premium',
                        style: TextStyle(
                            color: Color(0xFF1B2A41),
                            fontSize: 18,
                            fontWeight: FontWeight.bold)),
                    SizedBox(height: 2),
                    Text('Pilih emoji untuk profil Anda',
                        style: TextStyle(color: Color(0xFF5B6B82), fontSize: 13)),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close_rounded, color: Color(0xFF1B2A41)),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: const Color(0xFFEAF0F7),
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              children: [
                _tabBtn(0, '⭐ Syam Premium'),
                _tabBtn(1, '😀 Smileys & Faces'),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Expanded(
            child: GridView.count(
              crossAxisCount: 5,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              children: list.map((e) {
                final sel = _selected == e;
                return GestureDetector(
                  onTap: () => _pick(e),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: sel ? const Color(0xFF1F6FD1) : const Color(0xFFE1E7F0),
                        width: sel ? 2 : 1,
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Text(e, style: const TextStyle(fontSize: 28)),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFFD63A4F),
                backgroundColor: const Color(0xFFFFEEF0),
                side: const BorderSide(color: Color(0xFFFFC4CC)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
              ),
              onPressed: () => _pick(null),
              icon: const Icon(Icons.delete_outline_rounded),
              label: const Text('Hapus Syam Emoji',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabBtn(int i, String label) {
    final on = _tab == i;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = i),
        child: Container(
          height: 42,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: on ? const Color(0xFF1F6FD1) : Colors.transparent,
            borderRadius: BorderRadius.circular(26),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: on ? Colors.white : const Color(0xFF5B6B82),
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}
