import 'dart:async';
import 'dart:io';

import 'package:app_links/app_links.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:window_manager/window_manager.dart';

import './core/anime/providers/animeonsen.dart';
import './core/app/logging.dart';
import './core/app/runtimeDatas.dart';
import './core/app/version.dart';
import './core/data/preferences.dart';
import './core/data/settings.dart';
import './core/data/theme.dart';
import './ui/models/notification.dart';
import './ui/models/providers/appProvider.dart';
import './ui/models/providers/mainNavProvider.dart';
import './ui/models/snackBar.dart';
import './ui/models/sources.dart';
import './ui/models/widgets/appWrapper.dart';
import './ui/pages/info.dart';
import './ui/pages/mainNav.dart';
import './ui/theme/themes.dart';
import './ui/theme/types.dart';

/// ───────────────────────────────────────────────────────────────────────
/// Integrasi modul Anime (AnimeStream/otax) ke dalam Aq.
///
/// Modul ini awalnya adalah aplikasi Flutter berdiri sendiri (punya main()
/// sendiri). Di sini diubah menjadi satu widget (`HomeAnimePage`) yang bisa
/// dipanggil dari dashboard/tools_gateway Aq lewat Navigator biasa, tanpa
/// menjalankan proses init-nya dua kali dan tanpa bentrok dengan main()
/// milik Aq.
/// ───────────────────────────────────────────────────────────────────────

bool _animeStreamInitialized = false;

/// Menginisialisasi seluruh dependensi modul anime (Hive box, settings,
/// tema, token AnimeOnsen, notifikasi, dan daftar sumber/provider anime).
/// Aman dipanggil berkali-kali — hanya benar-benar jalan sekali.
Future<void> ensureAnimeStreamInitialized() async {
  if (_animeStreamInitialized) return;

  WidgetsFlutterBinding.ensureInitialized();

  // Inisialisasi versi app (modul anime butuh instance-nya sendiri)
  await AppVersion.init();

  if (!Hive.isBoxOpen('settings')) {
    await Hive.initFlutter(!Platform.isAndroid ? "animestream" : null);
  }

  await _loadAndAssignSettings();

  if (Platform.isWindows) {
    await windowManager.ensureInitialized();
  }

  AnimeOnsen().checkAndUpdateToken();

  NotificationService().init();

  final sm = SourceManager.instance;
  sm
    ..addSources(sm.inbuiltSources)
    ..loadProviders(clearBeforeLoading: false);

  _animeStreamInitialized = true;
}

Future<void> _loadAndAssignSettings() async {
  await Settings().getSettings().then((settings) => {
        currentUserSettings = settings,
        Logs.app.log("[STARTUP] Loaded user settings"),
      });

  await UserPreferences.getUserPreferences().then((pref) {
    userPreferences = pref;
    Logs.app.log("[STARTUP] Loaded user preferences");
  });

  await getTheme().then((themeId) {
    if ((themeId > availableThemes.length && !kDebugMode) || themeId < 1) {
      Logs.app.log("[STARTUP] Failed to apply theme with ID $themeId, Applying default theme");
      showToast("Failed to apply theme. Using default theme");
      setTheme(01);
      themeId = 01;
    }

    final darkMode = currentUserSettings!.darkMode!;

    ThemeItem? theme = availableThemes.where((theme) => theme.id == themeId).toList().firstOrNull;

    theme ??= availableThemes.first;

    if (darkMode) {
      appTheme = theme.theme;
      appTheme.backgroundColor =
          (currentUserSettings!.amoledBackground ?? false) ? Colors.black : theme.theme.backgroundColor;
    } else {
      appTheme = AnimeStreamTheme(
        accentColor: theme.lightVariant.accentColor,
        textMainColor: theme.lightVariant.textMainColor,
        textSubColor: theme.lightVariant.textSubColor,
        backgroundColor: theme.lightVariant.backgroundColor,
        backgroundSubColor: theme.lightVariant.backgroundSubColor,
        modalSheetBackgroundColor: theme.lightVariant.modalSheetBackgroundColor,
        onAccent: theme.lightVariant.onAccent,
      );
    }

    Logs.app.log("[STARTUP] Loaded theme of ID $themeId (${theme!.name})");
  });
}

/// Widget yang dipanggil dari menu Anime di dashboard/tools_gateway Aq.
/// Menunggu inisialisasi selesai, lalu menampilkan app anime (lengkap
/// dengan navigasi, player, downloader, dan sync akun) di dalam
/// MaterialApp terpisah (nested), supaya tema & routing-nya tidak bentrok
/// dengan MaterialApp utama Aq.
class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage> {
  late final Future<void> _initFuture;

  @override
  void initState() {
    super.initState();
    _initFuture = ensureAnimeStreamInitialized();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _initFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            backgroundColor: Color(0xFF050A12),
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.hasError) {
          Logs.app.log(snapshot.error.toString(), addToBuffer: true);
          return Scaffold(
            backgroundColor: const Color(0xFF050A12),
            appBar: AppBar(
              backgroundColor: const Color(0xFF0A1525),
              title: const Text('Anime', style: TextStyle(color: Colors.white)),
              iconTheme: const IconThemeData(color: Colors.white),
            ),
            body: Center(
              child: Text(
                'Gagal memuat modul Anime:\n${snapshot.error}',
                style: const TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
              ),
            ),
          );
        }

        return ChangeNotifierProvider(
          create: (context) => AppProvider(),
          child: const AnimeStream(),
        );
      },
    );
  }
}

/// Sub-app anime (MaterialApp bersarang), dipindahkan dari main() asli
/// modul otax/AnimeStream, tanpa perubahan logika — hanya tidak lagi
/// dipanggil lewat runApp() melainkan dirender sebagai widget biasa.
class AnimeStream extends StatefulWidget {
  const AnimeStream();

  static final GlobalKey<ScaffoldMessengerState> snackbarKey = GlobalKey<ScaffoldMessengerState>();
  static final navigatorKey = GlobalKey<NavigatorState>();

  @override
  State<AnimeStream> createState() => AnimeStreamState();
}

class AnimeStreamState extends State<AnimeStream> {
  StreamSubscription<Uri>? _sub;
  late AppLinks _appLinks;

  @override
  void initState() {
    super.initState();
    _listenDeepLinkCall();

    AwesomeNotifications().setListeners(
      onActionReceivedMethod: NotificationController.onActionReceivedMethod,
      onNotificationCreatedMethod: NotificationController.onNotificationCreatedMethod,
      onNotificationDisplayedMethod: NotificationController.onNotificationDisplayedMethod,
      onDismissActionReceivedMethod: NotificationController.onDismissActionReceivedMethod,
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  void _listenDeepLinkCall() {
    _appLinks = AppLinks();
    _sub = _appLinks.uriLinkStream.listen((uri) {
      if (uri.scheme == "astrm") {
        Logs.app.log("Invoked DeepLink uri: ${uri.toString()}");
        String host = uri.host;
        switch (host) {
          case "info":
            {
              final id = int.tryParse(uri.queryParameters['id'] ?? "nothing");
              if (id != null) {
                AnimeStream.navigatorKey.currentState?.push(
                  MaterialPageRoute(
                    builder: (context) => AppWrapper(
                      firstPage: Info(id: id),
                    ),
                  ),
                );
                break;
              }
            }
          default:
            floatingSnackBar("BAD-DEEPLINK: Host $host not recognized!");
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion(
      value: SystemUiOverlayStyle(
        statusBarIconBrightness: (currentUserSettings?.darkMode ?? true) ? Brightness.light : Brightness.dark,
        statusBarColor: Colors.black.withValues(alpha: 0.002),
        systemNavigationBarColor: Colors.black.withValues(alpha: 0.002),
      ),
      child: DynamicColorBuilder(
        builder: (lightScheme, darkScheme) {
          late AnimeStreamTheme scheme;

          if (currentUserSettings?.darkMode ?? true) {
            scheme = AnimeStreamTheme(
              accentColor: darkScheme?.primary ?? appTheme.accentColor,
              backgroundColor: (currentUserSettings?.amoledBackground ?? false)
                  ? Colors.black
                  : darkScheme?.surface ?? appTheme.backgroundColor,
              backgroundSubColor: darkScheme?.secondaryContainer ?? appTheme.backgroundSubColor,
              textMainColor: darkScheme?.onSurface ?? appTheme.textMainColor,
              textSubColor: darkScheme?.onSurfaceVariant ?? appTheme.textSubColor,
              modalSheetBackgroundColor: darkScheme?.surface ?? appTheme.modalSheetBackgroundColor,
              onAccent: darkScheme?.onPrimary ?? appTheme.onAccent,
            );
          } else {
            scheme = AnimeStreamTheme(
              accentColor: lightScheme?.primary ?? appTheme.accentColor,
              backgroundColor: lightScheme?.surface ?? appTheme.accentColor,
              backgroundSubColor: lightScheme?.secondaryContainer ?? appTheme.backgroundSubColor,
              textMainColor: lightScheme?.onSurface ?? appTheme.textMainColor,
              textSubColor: lightScheme?.onSurfaceVariant ?? appTheme.textSubColor,
              modalSheetBackgroundColor: lightScheme?.surface ?? appTheme.modalSheetBackgroundColor,
              onAccent: lightScheme?.onPrimary ?? appTheme.onAccent,
            );
          }

          if (currentUserSettings?.materialTheme ?? false) {
            appTheme = scheme;
          }

          final themeProvider = Provider.of<AppProvider>(context);

          return MaterialApp(
            title: 'Animestream',
            navigatorKey: AnimeStream.navigatorKey,
            scaffoldMessengerKey: AnimeStream.snackbarKey,
            theme: ThemeData(
              useMaterial3: true,
              brightness: themeProvider.isDark ? Brightness.dark : Brightness.light,
              textTheme: Theme.of(context).textTheme.apply(bodyColor: appTheme.textMainColor, fontFamily: "NotoSans"),
              scaffoldBackgroundColor: appTheme.backgroundColor,
              bottomSheetTheme: BottomSheetThemeData(backgroundColor: appTheme.modalSheetBackgroundColor),
              colorScheme: ColorScheme.fromSeed(
                brightness: themeProvider.isDark ? Brightness.dark : Brightness.light,
                seedColor: (currentUserSettings?.materialTheme ?? false) ? scheme.accentColor : appTheme.accentColor,
              ),
              iconTheme: IconThemeData(color: appTheme.textMainColor),
            ),
            home: ChangeNotifierProvider(
              create: (context) => MainNavProvider(),
              child: Platform.isWindows ? AppWrapper(firstPage: MainNavigator()) : MainNavigator(),
            ),
            debugShowCheckedModeBanner: false,
          );
        },
      ),
    );
  }
}
