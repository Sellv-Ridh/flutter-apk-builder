import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'theme_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:video_player/video_player.dart';
import 'package:file_picker/file_picker.dart';

import 'api_config.dart';
import 'verified_badge.dart';


MediaType _proofContentType(String path) {
  final ext = path.toLowerCase().split('.').last;
  switch (ext) {
    case 'png': return MediaType('image', 'png');
    case 'gif': return MediaType('image', 'gif');
    case 'webp': return MediaType('image', 'webp');
    case 'heic': return MediaType('image', 'heic');
    case 'heif': return MediaType('image', 'heif');
    case 'bmp': return MediaType('image', 'bmp');
    case 'jpg':
    case 'jpeg':
    default: return MediaType('image', 'jpeg');
  }
}

class _ProfileStat extends StatelessWidget {
  final String value;
  final String label;
  const _ProfileStat({required this.value, required this.label, super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white60, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class TiktokPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const TiktokPage({super.key, required this.sessionKey, required this.username, required this.role});
  @override
  State<TiktokPage> createState() => _TiktokPageState();
}

class _TiktokPageState extends State<TiktokPage> {
  final PageController _feed = PageController();
  final ImagePicker _picker = ImagePicker();
  final TextEditingController _search = TextEditingController();
  final List<Map<String, dynamic>> _posts = [];
  final List<Map<String, dynamic>> _lives = [];
  final Map<int, VideoPlayerController> _videos = {};
  Timer? _livePoll;
  bool _loading = true;
  bool _uploading = false;
  bool _searching = false;
  bool _muted = false;
  int _tab = 0;
  int _current = 0;
  List<String> _following = [];
  List<Map<String, dynamic>> _searchUsers = [];
  List<Map<String, dynamic>> _searchPosts = [];
  final Set<String> _expandedCaptions = <String>{};
  final Set<String> _hiddenPosts = <String>{};
  Timer? _searchDebounce;
  String? _heartPostId;
  Timer? _heartTimer;
  String _myAvatarUrl = '';
  String _myDisplayName = '';
  int _myAvatarVersion = DateTime.now().millisecondsSinceEpoch;

  Uri get _api => Uri.parse(baseUrl);

  @override
  void initState() {
    super.initState();
    // TikTok ships its own fixed red/black theme: suppress the global
    // comic/anime skin for as long as this page is on screen.
    ThemeProvider.pushOwnTheme();
    // Render the TikTok surface edge-to-edge. The dashboard chrome is not part
    // of this route, so video can occupy the complete display area.
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarDividerColor: Colors.transparent,
    ));
    _refreshAll();
    _livePoll = Timer.periodic(const Duration(seconds: 8), (_) => _loadLives(silent: true));
  }

  @override
  void dispose() {
    ThemeProvider.popOwnTheme();
    _livePoll?.cancel();
    _feed.dispose();
    _searchDebounce?.cancel();
    _heartTimer?.cancel();
    _search.dispose();
    for (final v in _videos.values) {
      v.dispose();
    }
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarIconBrightness: Brightness.light,
    ));
    super.dispose();
  }

  Future<void> _refreshAll() async {
    await Future.wait([_loadFeed(), _loadFollowing(), _loadLives(), _loadMyProfile()]);
  }

  Future<void> _loadMyProfile() async {
    try {
      final r = await http.get(_api.replace(path: '/api/tiktok/profile', queryParameters: {'key': widget.sessionKey, 'username': widget.username})).timeout(const Duration(seconds: 12));
      final d = jsonDecode(r.body);
      if (r.statusCode == 200 && d['valid'] == true && d['profile'] is Map && mounted) {
        final p = Map<String, dynamic>.from(d['profile']);
        setState(() {
          _myAvatarUrl = '${p['avatar_url'] ?? ''}';
          _myDisplayName = '${p['display_name'] ?? widget.username}';
          _myAvatarVersion = DateTime.now().millisecondsSinceEpoch;
        });
      }
    } catch (_) {}
  }

  String _avatarUrlFor(String username, dynamic fallback) {
    if (username == widget.username && _myAvatarUrl.isNotEmpty) {
      final sep = _myAvatarUrl.contains('?') ? '&' : '?';
      return '${_myAvatarUrl}${sep}v=$_myAvatarVersion';
    }
    return '${fallback ?? ''}';
  }

  Future<void> _loadFeed() async {
    try {
      final r = await http.get(_api.replace(path: '/api/tiktok/feed', queryParameters: {'key': widget.sessionKey})).timeout(const Duration(seconds: 15));
      final d = jsonDecode(r.body);
      if (r.statusCode == 200 && d['valid'] == true && d['posts'] is List) {
        for (final v in _videos.values) {
          v.pause();
          v.dispose();
        }
        _videos.clear();
        _posts
          ..clear()
          ..addAll(List<Map<String, dynamic>>.from(d['posts']));
      }
    } catch (_) {
      _toast('Feed gagal dimuat. Coba lagi.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadFollowing() async {
    try {
      final r = await http.get(_api.replace(path: '/api/tiktok/following', queryParameters: {'key': widget.sessionKey})).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && d['following'] is List && mounted) {
        setState(() => _following = List<String>.from(d['following']));
      }
    } catch (_) {}
  }

  Future<void> _loadLives({bool silent = false}) async {
    try {
      final r = await http.get(_api.replace(path: '/api/tiktok/live/list', queryParameters: {'key': widget.sessionKey})).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (r.statusCode == 200 && d['valid'] == true && d['lives'] is List && mounted) {
        setState(() {
          _lives
            ..clear()
            ..addAll(List<Map<String, dynamic>>.from(d['lives']));
        });
      }
    } catch (_) {
      if (!silent) _toast('LIVE sedang tidak tersedia.');
    }
  }

  List<Map<String, dynamic>> get _visiblePosts {
    Iterable<Map<String, dynamic>> r = _posts.where((p) => !_hiddenPosts.contains('${p['post_id']}'));
    if (_tab == 1) r = r.where((p) => _following.contains('${p['username']}'));
    final q = _search.text.trim().toLowerCase();
    if (q.isNotEmpty) r = r.where((p) => '${p['username']} ${p['caption']}'.toLowerCase().contains(q));
    return r.toList();
  }


  void _onSearchChanged(String value) {
    _searchDebounce?.cancel();
    final q = value.trim();
    if (q.length < 2) { if (mounted) setState(() { _searchUsers = []; _searchPosts = []; }); return; }
    _searchDebounce = Timer(const Duration(milliseconds: 350), () async {
      try {
        final r = await http.get(_api.replace(path: '/api/tiktok/search', queryParameters: {'key': widget.sessionKey, 'q': q})).timeout(const Duration(seconds: 10));
        final d = jsonDecode(r.body);
        if (d['valid'] == true && mounted) setState(() {
          _searchUsers = d['users'] is List ? List<Map<String, dynamic>>.from(d['users']) : [];
          _searchPosts = d['posts'] is List ? List<Map<String, dynamic>>.from(d['posts']) : [];
        });
      } catch (_) {}
    });
  }

  Future<void> _uploadVideo() async {
    final f = await _picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 10));
    if (f != null) await _uploadMedia(f, 'video');
  }

  Future<void> _uploadPhoto() async {
    final f = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 95, preferredCameraDevice: CameraDevice.rear);
    if (f != null) await _uploadMedia(f, 'image');
  }

  Future<void> _uploadGif() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['gif']);
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    await _uploadMedia(XFile(path, name: result.files.single.name, mimeType: 'image/gif'), 'gif');
  }

  Future<void> _uploadMedia(XFile file, String type) async {
    if (_uploading) return;
    final caption = await _captionDialog(type == 'video' ? 'Posting video' : type == 'gif' ? 'Posting GIF' : 'Posting foto');
    if (caption == null) return;
    setState(() => _uploading = true);
    try {
      final req = http.MultipartRequest('POST', _api.replace(path: '/api/tiktok/upload-media'));
      req.fields['key'] = widget.sessionKey;
      req.fields['caption'] = caption;
      req.fields['media_type'] = type;
      req.files.add(await http.MultipartFile.fromPath('media', file.path, filename: file.name));
      final response = await req.send().timeout(const Duration(minutes: 8));
      final body = await response.stream.bytesToString();
      Map<String, dynamic> d;
      try { d = Map<String, dynamic>.from(jsonDecode(body)); } catch (_) { d = {'valid': false, 'message': 'Server upload error (${response.statusCode}).'}; }
      if (response.statusCode >= 200 && response.statusCode < 300 && d['valid'] == true) {
        await _loadFeed();
        if (mounted && _posts.isNotEmpty) {
          _feed.jumpToPage(0);
        }
        _toast(type == 'video' ? 'Video berhasil diposting.' : type == 'gif' ? 'GIF berhasil diposting.' : 'Foto berhasil diposting.');
      } else {
        _toast(d['message']?.toString() ?? 'Upload gagal.');
      }
    } catch (e) {
      _toast('Upload gagal: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  Future<String?> _captionDialog(String title) async {
    final c = TextEditingController();
    final value = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF101116),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(ctx).viewInsets.bottom + 18),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          TextField(controller: c, maxLength: 220, maxLines: 4, decoration: const InputDecoration(hintText: 'Tulis caption... #fyp', filled: true, fillColor: Color(0xFF1B1D24), border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(18)), borderSide: BorderSide.none))),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('POST'))),
        ]),
      ),
    );
    c.dispose();
    return value;
  }

  void _doubleTapLike(Map<String, dynamic> post) {
    _heartTimer?.cancel();
    setState(() => _heartPostId = '${post['post_id']}');
    _heartTimer = Timer(const Duration(milliseconds: 850), () {
      if (mounted) setState(() => _heartPostId = null);
    });
    if (post['liked'] != true) {
      _like(post);
    }
  }

  Future<void> _like(Map<String, dynamic> post) async {
    try {
      final r = await http.post(_api.replace(path: '/api/tiktok/like'), body: {'key': widget.sessionKey, 'post_id': '${post['post_id']}'}).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && mounted) setState(() { post['liked'] = d['liked'] == true; post['likes'] = d['likes'] ?? 0; });
    } catch (_) { _toast('Like gagal.'); }
  }

  Future<void> _follow(String username) async {
    if (username == widget.username) return;
    try {
      final r = await http.post(_api.replace(path: '/api/tiktok/follow'), body: {'key': widget.sessionKey, 'username': username}).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && mounted) {
        final yes = d['following'] == true;
        setState(() {
          if (yes) { if (!_following.contains(username)) _following.add(username); } else { _following.remove(username); }
        });
      }
    } catch (_) { _toast('Follow gagal.'); }
  }

  Future<void> _showComments(Map<String, dynamic> post) async {
    try {
      final r = await http.get(_api.replace(path: '/api/tiktok/comments', queryParameters: {'key': widget.sessionKey, 'post_id': '${post['post_id']}'})).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] != true) throw Exception();
      final comments = List<Map<String, dynamic>>.from((d['comments'] ?? const []).map((x) => Map<String, dynamic>.from(x)));
      if (!mounted) return;
      final c = TextEditingController();
      Map<String, dynamic>? replyingTo;
      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black54,
        builder: (ctx) => StatefulBuilder(builder: (ctx, setModal) {
          final media = MediaQuery.of(ctx);
          final h = media.size.height;
          final keyboard = media.viewInsets.bottom;
          final sheetHeight = keyboard > 0 ? (h * .72).clamp(360.0, 720.0) : (h * .92).clamp(480.0, 900.0);
          Future<void> send({String? parentId}) async {
            final text = c.text.trim();
            if (text.isEmpty) return;
            try {
              final path = parentId == null ? '/api/tiktok/comments' : '/api/tiktok/comment/reply';
              final body = {'key': widget.sessionKey, 'post_id': '${post['post_id']}', 'text': text, if (parentId != null) 'comment_id': parentId};
              final rr = await http.post(_api.replace(path: path), body: body).timeout(const Duration(seconds: 8));
              final dd = jsonDecode(rr.body);
              if (dd['valid'] == true) {
                if (parentId == null) {
                  comments.insert(0, Map<String, dynamic>.from(dd['comment']));
                  post['comments'] = dd['comments'] ?? comments.length;
                } else {
                  final parent = comments.cast<Map<String,dynamic>?>().firstWhere((x) => x?['id']?.toString() == parentId, orElse: () => null);
                  if (parent != null) {
                    final replies = List<Map<String,dynamic>>.from(parent['replies'] ?? const []);
                    replies.add(Map<String,dynamic>.from(dd['reply']));
                    parent['replies'] = replies;
                  }
                }
                c.clear(); replyingTo = null; setModal(() {}); if (mounted) setState(() {});
              }
            } catch (_) { _toast(parentId == null ? 'Komentar gagal dikirim.' : 'Balasan gagal dikirim.'); }
          }
          Widget item(Map<String,dynamic> x, {int depth = 0}) {
            final uname='${x['username'] ?? ''}'; final display='${x['display_name'] ?? uname}'; final verified=x['verified']==true;
            final liked=x['liked']==true; final likes=int.tryParse('${x['likes'] ?? 0}') ?? 0;
            final replies=List<Map<String,dynamic>>.from(x['replies'] ?? const []);
            return Padding(
              padding: EdgeInsets.fromLTRB(depth == 0 ? 12 : 54, 7, 12, 2),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                Row(crossAxisAlignment: CrossAxisAlignment.start, children:[
                  _avatar(uname,size: depth==0?38:30,url:'${x['avatar_url'] ?? ''}'), const SizedBox(width:10),
                  Expanded(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                    Row(children:[Flexible(child:Text(display,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70,fontSize:12,fontWeight:FontWeight.w800))),if(verified)...[const SizedBox(width:4),tiktokBlueTick(size:14)]]),
                    const SizedBox(height:3), Text('${x['text'] ?? ''}',style:const TextStyle(fontSize:14,height:1.25)),
                    const SizedBox(height:5), Row(children:[Text('@$uname',style:const TextStyle(color:Colors.white38,fontSize:10)),const SizedBox(width:12),GestureDetector(onTap:(){replyingTo=x; c.text=''; setModal((){});},child:const Text('Balas',style:TextStyle(color:Colors.white60,fontSize:10,fontWeight:FontWeight.w700))),if(likes>0)...[const SizedBox(width:14),Text('$likes suka',style:const TextStyle(color:Colors.white38,fontSize:10))]])
                  ])),
                  const SizedBox(width:6),
                  GestureDetector(onTap:() async { try { final rr=await http.post(_api.replace(path:'/api/tiktok/comment/like'),body:{'key':widget.sessionKey,'post_id':'${post['post_id']}','comment_id':'${x['id']}'}).timeout(const Duration(seconds:8)); final dd=jsonDecode(rr.body); if(dd['valid']==true){x['liked']=dd['liked']==true;x['likes']=dd['likes']??0;setModal((){});}}catch(_){_toast('Like komentar gagal.');}},child:Padding(padding:const EdgeInsets.only(top:13),child:Icon(liked?Icons.favorite_rounded:Icons.favorite_border_rounded,size:19,color:liked?const Color(0xFFFF3B5C):Colors.white38)))
                ]),
                if(replies.isNotEmpty) ...replies.map((r)=>item(r,depth:1)),
              ]),
            );
          }
          return AnimatedPadding(duration: const Duration(milliseconds: 180), curve: Curves.easeOut, padding: EdgeInsets.only(bottom: keyboard), child: Align(alignment: Alignment.bottomCenter, child: Container(height:sheetHeight,decoration:const BoxDecoration(color:Color(0xFF101114),borderRadius:BorderRadius.vertical(top:Radius.circular(22))),child:Column(children:[
            const SizedBox(height:9),Container(width:38,height:4,decoration:BoxDecoration(color:Colors.white30,borderRadius:BorderRadius.all(Radius.circular(10)))),
            Padding(padding:const EdgeInsets.fromLTRB(16,14,16,12),child:Row(children:[Expanded(child:Center(child:Text('${comments.length} komentar',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900)))),IconButton(onPressed:()=>Navigator.pop(ctx),icon:const Icon(Icons.close_rounded,color:Colors.white54))])),
            const Divider(height:1,color:Colors.white10),
            Expanded(child:comments.isEmpty?const Center(child:Text('Belum ada komentar. Jadilah yang pertama.',style:TextStyle(color:Colors.white54))):ListView(padding:const EdgeInsets.only(top:5,bottom:10),children:comments.map((x)=>item(x)).toList())),
            SafeArea(top:false,child:Padding(padding:const EdgeInsets.fromLTRB(12,6,12,10),child:Column(children:[
              if(replyingTo!=null)Align(alignment:Alignment.centerLeft,child:Padding(padding:const EdgeInsets.only(bottom:6,left:8),child:Row(children:[const Icon(Icons.reply_rounded,size:15,color:Color(0xFF20A9FF)),const SizedBox(width:5),Expanded(child:Text('Membalas @${replyingTo!['username']}',style:const TextStyle(color:Colors.white54,fontSize:11))),GestureDetector(onTap:(){replyingTo=null;setModal((){});},child:const Icon(Icons.close,size:16,color:Colors.white38))]))),
              Row(children:[_avatar(widget.username,size:34,url:_avatarUrlFor(widget.username, '')),const SizedBox(width:9),Expanded(child:TextField(controller:c,textInputAction:TextInputAction.send,onSubmitted:(_)=>send(parentId:replyingTo?['id']?.toString()),decoration:InputDecoration(hintText:replyingTo==null?'Tambahkan komentar...':'Tulis balasan...',filled:true,fillColor:const Color(0xFF1B1D22),contentPadding:const EdgeInsets.symmetric(horizontal:15,vertical:11),border:const OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(22)),borderSide:BorderSide.none)))),const SizedBox(width:5),Material(color:const Color(0xFF20A9FF),shape:const CircleBorder(),child:IconButton(tooltip:'Kirim',onPressed:()=>send(parentId:replyingTo?['id']?.toString()),icon:const Icon(Icons.send_rounded,color:Colors.white,size:20)))]),
            ])))
          ])),
        ));
        }),
      );
      c.dispose();
    } catch (_) { _toast('Komentar gagal dimuat.'); }
  }

  Future<void> _viewPost(Map<String, dynamic> post) async {
    try {
      final r = await http.post(_api.replace(path: '/api/tiktok/view'), body: {'key': widget.sessionKey, 'post_id': '${post['post_id']}'}).timeout(const Duration(seconds: 5));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && mounted) setState(() => post['views'] = d['views'] ?? post['views'] ?? 0);
    } catch (_) {}
  }

  Future<void> _savePost(Map<String, dynamic> post) async {
    try {
      final r = await http.post(_api.replace(path: '/api/tiktok/save'), body: {'key': widget.sessionKey, 'post_id': '${post['post_id']}'}).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && mounted) { setState(() => post['saved'] = d['saved'] == true); _toast(d['saved'] == true ? 'Disimpan ke koleksi.' : 'Dihapus dari koleksi.'); }
    } catch (_) { _toast('Gagal menyimpan postingan.'); }
  }

  Future<void> _showNotifications() async {
    try {
      final r = await http.get(_api.replace(path: '/api/tiktok/notifications', queryParameters: {'key': widget.sessionKey})).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      final items = d['notifications'] is List ? List<Map<String,dynamic>>.from(d['notifications']) : <Map<String,dynamic>>[];
      if (!mounted) return;
      showModalBottomSheet(context: context, backgroundColor: const Color(0xFF101116), isScrollControlled: true, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))), builder: (ctx) => SizedBox(height: MediaQuery.of(ctx).size.height*.72, child: Column(children: [
        const Padding(padding: EdgeInsets.all(18), child: Align(alignment: Alignment.centerLeft, child: Text('Aktivitas', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)))),
        const Divider(height: 1, color: Colors.white12),
        Expanded(child: items.isEmpty ? const Center(child: Text('Belum ada aktivitas.')) : ListView.separated(padding: const EdgeInsets.all(12), itemCount: items.length, separatorBuilder: (_,__) => const Divider(color: Colors.white10), itemBuilder: (_,i) { final x=items[i]; return ListTile(leading: CircleAvatar(child: Icon(x['type']=='like'?Icons.favorite:x['type']=='follow'?Icons.person_add_alt_1:Icons.mode_comment_outlined)), title: Text('${x['text'] ?? ''}'), subtitle: Text('${x['created_at'] ?? ''}', style: const TextStyle(color: Colors.white54, fontSize: 11))); })),
      ])));
      await http.post(_api.replace(path: '/api/tiktok/notifications/read'), body: {'key': widget.sessionKey}).timeout(const Duration(seconds: 5));
    } catch (_) { _toast('Aktivitas gagal dimuat.'); }
  }

  Future<void> _sharePost(Map<String, dynamic> post) async {
    final url = '${post['video_url'] ?? ''}';
    if (url.isNotEmpty) await Share.share(url, subject: 'DEY TikTok');
  }

  Future<void> _downloadPost(Map<String, dynamic> post) async {
    final url = '${post['video_url'] ?? ''}';
    if (url.isEmpty) return;
    try {
      _toast('Menyiapkan download...');
      final r = await http.get(Uri.parse(url)).timeout(const Duration(minutes: 4));
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception();
      final dir = await getTemporaryDirectory();
      final ext = '${post['media_type']}' == 'gif' ? 'gif' : '${post['media_type']}' == 'image' ? 'jpg' : 'mp4';
      final f = File('${dir.path}/dey_tiktok_${post['post_id']}.$ext');
      await f.writeAsBytes(r.bodyBytes, flush: true);
      await Share.shareXFiles([XFile(f.path)], text: 'DEY TikTok');
    } catch (_) { _toast('Download gagal.'); }
  }

  Future<void> _openProfile(String username) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => TiktokProfilePage(sessionKey: widget.sessionKey, username: username, following: _following.contains(username), onFollow: () => _follow(username))));
    await _loadFollowing();
    await _loadMyProfile();
  }

  Future<void> _createLive() async {
    try {
      final r = await http.post(_api.replace(path: '/api/tiktok/live/create'), body: {'key': widget.sessionKey, 'title': 'LIVE @${widget.username}'}).timeout(const Duration(seconds: 12));
      final d = jsonDecode(r.body);
      if (d['valid'] == true) {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => TiktokLiveHostPage(sessionKey: widget.sessionKey, username: widget.username, liveId: '${d['live']['live_id']}')));
        await _loadLives();
      } else { _toast(d['message'] ?? 'LIVE gagal dibuat.'); }
    } catch (_) { _toast('LIVE gagal dibuat.'); }
  }

  Future<void> _openCoins() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => TiktokCoinPage(sessionKey: widget.sessionKey, username: widget.username)));
  }

  Future<void> _showLiveList() async {
    await _loadLives();
    if (!mounted) return;
    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0C0D10),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setModal) => SizedBox(
        height: MediaQuery.of(ctx).size.height * .78,
        child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 12), child: Row(children: [const Text('LIVE Sekarang', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)), const Spacer(), const _LiveBadge()])),
          const Divider(height: 1, color: Colors.white12),
          Expanded(child: _lives.isEmpty ? const Center(child: Text('Belum ada LIVE aktif.')) : RefreshIndicator(onRefresh: () async { await _loadLives(); setModal(() {}); }, child: ListView.separated(padding: const EdgeInsets.all(14), itemCount: _lives.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) { final live = _lives[i]; return ListTile(contentPadding: const EdgeInsets.all(10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), tileColor: const Color(0xFF17191F), leading: Stack(children: [_avatar('${live['username']}', size: 52), const Positioned(right: 0, bottom: 0, child: _LiveBadge())]), title: Row(children: [Flexible(child: Text('@${live['username']}', style: const TextStyle(fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis)), if (live['verified'] == true) ...[const SizedBox(width: 4), tiktokBlueTick(size: 15)]]), subtitle: Text('${live['viewer_count'] ?? 0} penonton · ${live['title'] ?? 'LIVE sekarang'}'), trailing: FilledButton(onPressed: () async { Navigator.pop(ctx); await Navigator.push(context, MaterialPageRoute(builder: (_) => TiktokLiveViewerPage(sessionKey: widget.sessionKey, liveId: '${live['live_id']}', host: '${live['username']}', hostVerified: live['verified'] == true))); await _loadLives(); }, child: const Text('TONTON'))); }))),
        ]),
      )),
    );
  }

  Future<void> _showCreateMenu() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF101116),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.all(18), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Buat postingan', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('Foto, video, GIF, atau LIVE', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _createTile(Icons.videocam_rounded, 'Video', _uploadVideo, ctx)),
          const SizedBox(width: 9),
          Expanded(child: _createTile(Icons.photo_rounded, 'Foto', _uploadPhoto, ctx)),
          const SizedBox(width: 9),
          Expanded(child: _createTile(Icons.gif_box_rounded, 'GIF', _uploadGif, ctx)),
          const SizedBox(width: 9),
          Expanded(child: _createTile(Icons.live_tv_rounded, 'LIVE', _createLive, ctx)),
        ]),
      ]))),
    );
  }

  Widget _createTile(IconData icon, String label, VoidCallback tap, BuildContext sheetContext) => InkWell(onTap: () { Navigator.pop(sheetContext); Future.microtask(tap); }, borderRadius: BorderRadius.circular(18), child: Container(padding: const EdgeInsets.symmetric(vertical: 17), decoration: BoxDecoration(color: const Color(0xFF191B21), borderRadius: BorderRadius.circular(18)), child: Column(children: [Icon(icon, size: 29), const SizedBox(height: 7), Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11))])));

  Widget _avatar(String username, {double size = 48, String? url}) {
    final has = url != null && url.isNotEmpty;
    return Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.5), color: const Color(0xFF242833)), child: ClipOval(child: has ? Image.network(url!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _avatarLetter(username, size)) : _avatarLetter(username, size)));
  }

  Widget _avatarLetter(String username, double size) => Center(child: Text(username.isEmpty ? '?' : username.substring(0, 1).toUpperCase(), style: TextStyle(fontSize: size * .36, fontWeight: FontWeight.w900)));

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  }

  Widget _topBar() => Positioned(
    top: 0,
    left: 0,
    right: 0,
    child: SafeArea(
      bottom: false,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.black87, Colors.black45, Colors.transparent],
          ),
        ),
        child: _searching
            ? Row(children: [
                IconButton(
                  splashRadius: 22,
                  onPressed: () => setState(() { _searching = false; _search.clear(); _searchUsers = []; }),
                  icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                ),
                Expanded(
                  child: Container(
                    height: 42,
                    decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(22)),
                    child: TextField(
                      controller: _search,
                      autofocus: true,
                      onChanged: (v) { setState(() {}); _onSearchChanged(v); },
                      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search_rounded, color: Colors.white70),
                        hintText: 'Cari creator, video, atau LIVE',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.only(top: 10),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
              ])
            : Row(children: [
                IconButton(
                  splashRadius: 22,
                  onPressed: () => setState(() => _searching = true),
                  icon: const Icon(Icons.search_rounded, color: Colors.white),
                ),
                const Spacer(),
                _topTab('Mengikuti', 1),
                const SizedBox(width: 22),
                _topTab('Untuk Anda', 0),
                const Spacer(),
                GestureDetector(
                  onTap: _openCoins,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.white24),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.monetization_on_rounded, color: Color(0xFFFFD54F), size: 18),
                      SizedBox(width: 5),
                      Text('Koin', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
                    ]),
                  ),
                ),
                IconButton(onPressed: _showLiveList, tooltip: 'LIVE', icon: const Icon(Icons.live_tv_rounded)),
                IconButton(onPressed: _showNotifications, tooltip: 'Notifikasi', icon: const Icon(Icons.notifications_none_rounded)),
              ]),
      ),
    ),
  );

  Widget _topTab(String text, int value) => GestureDetector(onTap: () { setState(() => _tab = value); if (_feed.hasClients && _visiblePosts.isNotEmpty) _feed.jumpToPage(0); }, child: Column(mainAxisSize: MainAxisSize.min, children: [Text(text, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: _tab == value ? Colors.white : Colors.white54)), const SizedBox(height: 5), AnimatedContainer(duration: const Duration(milliseconds: 160), width: _tab == value ? 34 : 0, height: 3, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)))]));

  Widget _bottomBar() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: SafeArea(
        top: false,
        child: Container(
          height: 72,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.transparent, Colors.black87],
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _nav(Icons.home_filled, 'Beranda', () {}),
              _nav(Icons.explore_outlined, 'Temukan', () => setState(() => _searching = true)),
              GestureDetector(
                onTap: _showCreateMenu,
                child: Container(
                  width: 50,
                  height: 38,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(11),
                    boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 10)],
                  ),
                  child: const Icon(Icons.add, color: Colors.black, size: 29),
                ),
              ),
              _nav(Icons.live_tv_rounded, 'LIVE', _showLiveList),
              _nav(Icons.person_outline_rounded, 'Profil', () => _openProfile(widget.username)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _nav(IconData icon, String label, VoidCallback onTap) => GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onTap,
    child: SizedBox(
      width: 66,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 24, color: Colors.white),
          const SizedBox(height: 4),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: Colors.white)),
        ],
      ),
    ),
  );

  Widget _emptyFeed() => Center(child: Padding(padding: const EdgeInsets.only(bottom: 70), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.play_circle_outline_rounded, size: 70, color: Colors.white54), const SizedBox(height: 14), Text(_tab == 1 ? 'Belum mengikuti creator' : 'Belum ada video', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(_tab == 1 ? 'Ikuti creator agar videonya muncul di sini.' : 'Jadilah yang pertama posting.'), const SizedBox(height: 20), FilledButton.icon(onPressed: _showCreateMenu, icon: const Icon(Icons.add), label: const Text('BUAT POSTINGAN'))])));

  void _preloadVideoAt(List<Map<String, dynamic>> posts, int index) {
    if (index < 0 || index >= posts.length) return;
    final post = posts[index];
    if ('${post['media_type'] ?? 'video'}' != 'video') return;
    final url = '${post['video_url'] ?? ''}';
    if (url.isEmpty || _videos.containsKey(index)) return;
    final c = VideoPlayerController.networkUrl(Uri.parse(url));
    _videos[index] = c;
    c.initialize().then((_) async {
      if (!mounted) return;
      await c.setLooping(true);
      await c.setVolume(_muted ? 0 : 1);
      if (index == _current) await c.play();
      if (mounted) setState(() {});
    }).catchError((_) {
      if (_videos[index] == c) { _videos.remove(index); }
      c.dispose();
    });
  }

  void _hidePost(Map<String, dynamic> post) {
    final id = '${post['post_id']}';
    if (id.isEmpty) return;
    setState(() => _hiddenPosts.add(id));
  }

  Future<void> _postMenu(Map<String, dynamic> post) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF111318),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 8),
        ListTile(leading: const Icon(Icons.link_rounded), title: const Text('Salin tautan'), onTap: () => Navigator.pop(ctx, 'copy')),
        ListTile(leading: const Icon(Icons.not_interested_rounded), title: const Text('Tidak tertarik'), onTap: () => Navigator.pop(ctx, 'hide')),
        ListTile(leading: const Icon(Icons.flag_outlined), title: const Text('Laporkan'), onTap: () => Navigator.pop(ctx, 'report')),
        const SizedBox(height: 8),
      ])),
    );
    if (!mounted || action == null) return;
    if (action == 'copy') {
      await Clipboard.setData(ClipboardData(text: '${post['video_url'] ?? ''}'));
      _toast('Tautan disalin.');
    } else if (action == 'hide') {
      _hidePost(post);
      _toast('Postingan disembunyikan dari feed.');
    } else if (action == 'report') {
      _toast('Laporan dicatat.');
    }
  }

  Widget _buildPost(Map<String, dynamic> post, int i) {
    final url = '${post['video_url'] ?? ''}';
    final type = '${post['media_type'] ?? 'video'}';
    if (type == 'image') return _mediaStack(post, i, Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined, size: 58))));
    if (type == 'gif') return _mediaStack(post, i, Image.network(url, fit: BoxFit.cover, gaplessPlayback: true, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined, size: 58))));
    VideoPlayerController? c = _videos[i];
    if (c == null && url.isNotEmpty) {
      c = VideoPlayerController.networkUrl(Uri.parse(url));
      _videos[i] = c;
      c.initialize().then((_) async { if (!mounted) return; await c!.setLooping(true); await c!.setVolume(_muted ? 0 : 1); if (i == _current) await c!.play(); setState(() {}); }).catchError((_) {});
    }
    final media = c != null && c.value.isInitialized ? GestureDetector(onTap: () async { if (c!.value.isPlaying) await c.pause(); else await c.play(); if (mounted) setState(() {}); }, child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)))) : const Center(child: CircularProgressIndicator());
    return _mediaStack(post, i, media);
  }

  Widget _mediaStack(Map<String, dynamic> post, int i, Widget media) => Stack(fit: StackFit.expand, children: [
    GestureDetector(onDoubleTap: () => _doubleTapLike(post), child: media),
    const Positioned.fill(child: IgnorePointer(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black38, Colors.transparent, Colors.black87]))))),
    _postHeader(post),
    _postInfo(post),
    _sideActions(post),
    if (_heartPostId == '${post['post_id']}')
      const Center(child: IgnorePointer(child: _HeartBurst())),
    if (i == _current && '${post['media_type'] ?? 'video'}' == 'video')
      Positioned(left: 0, right: 0, bottom: 0, child: _videoProgress(i)),
  ]);

  Widget _videoProgress(int i) {
    final c = _videos[i];
    if (c == null || !c.value.isInitialized) return const SizedBox.shrink();
    return VideoProgressIndicator(c, allowScrubbing: true, padding: EdgeInsets.zero, colors: const VideoProgressColors(playedColor: Colors.white, bufferedColor: Colors.white38, backgroundColor: Colors.white12));
  }

  Widget _postHeader(Map<String, dynamic> post) => Positioned(
    top: 58,
    left: 14,
    right: 12,
    child: Row(children: [
      GestureDetector(
        onTap: () => _openProfile('${post['username']}'),
        child: Container(
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white70, width: 1.2)),
          child: _avatar('${post['username']}', size: 44, url: _avatarUrlFor('${post['username']}', post['avatar_url'])),
        ),
      ),
      const SizedBox(width: 9),
      Expanded(
        child: GestureDetector(
          onTap: () => _openProfile('${post['username']}'),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Flexible(child: Text('@${post['username']}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis)),
              if (post['verified'] == true) ...[const SizedBox(width: 4), tiktokBlueTick(size: 17)],
            ]),
            Text('${post['username']}' == widget.username && _myDisplayName.isNotEmpty ? _myDisplayName : '${post['display_name'] ?? 'DEY TikTok'}', style: const TextStyle(fontSize: 11, color: Colors.white70), overflow: TextOverflow.ellipsis),
          ]),
        ),
      ),
      if ('${post['username']}' != widget.username)
        OutlinedButton(
          onPressed: () => _follow('${post['username']}'),
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.white,
            side: BorderSide(color: _following.contains('${post['username']}') ? Colors.white38 : Colors.white),
            minimumSize: const Size(0, 34),
            padding: const EdgeInsets.symmetric(horizontal: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          child: Text(_following.contains('${post['username']}') ? 'Mengikuti' : 'Ikuti', style: const TextStyle(fontWeight: FontWeight.w900)),
        ),
    ]),
  );

  Widget _postInfo(Map<String, dynamic> post) {
    final id = '${post['post_id']}';
    final caption = '${post['caption'] ?? ''}'.trim();
    final expanded = _expandedCaptions.contains(id);
    return Positioned(
      left: 14,
      right: 76,
      bottom: 86,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Flexible(child: Text('@${post['username']}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis)),
          if (post['verified'] == true) ...[const SizedBox(width: 4), tiktokBlueTick(size: 15)],
          const Spacer(),
          IconButton(onPressed: () => _postMenu(post), padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 32, height: 32), icon: const Icon(Icons.more_horiz_rounded, size: 22, color: Colors.white)),
        ]),
        const SizedBox(height: 3),
        if (caption.isNotEmpty)
          GestureDetector(
            onTap: () => setState(() { if (expanded) { _expandedCaptions.remove(id); } else { _expandedCaptions.add(id); } }),
            child: RichText(
              text: TextSpan(style: const TextStyle(fontSize: 14, height: 1.22, fontWeight: FontWeight.w600, color: Colors.white), children: [
                TextSpan(text: expanded || caption.length <= 110 ? caption : '${caption.substring(0, 110)}…'),
                if (caption.length > 110) TextSpan(text: expanded ? '  lebih sedikit' : '  selengkapnya', style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          )
        else
          const Text('Video baru di DEY TikTok', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Text('${post['views'] ?? 0} tayangan · ${post['likes'] ?? 0} suka · ${post['comments'] ?? 0} komentar', style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 7),
        GestureDetector(
          onTap: () => _toast('Sound ini belum memiliki halaman audio.'),
          child: const Row(
            children: [
              Icon(Icons.music_note_rounded, size: 15),
              SizedBox(width: 4),
              Expanded(
                child: Text(
                  'Original sound · DEY APP',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _sideActions(Map<String, dynamic> post) => Positioned(
    right: 8,
    bottom: 104,
    child: Column(children: [
      GestureDetector(
        onTap: () => _openProfile('${post['username']}'),
        child: Stack(clipBehavior: Clip.none, children: [
          _avatar('${post['username']}', size: 48, url: _avatarUrlFor('${post['username']}', post['avatar_url'])),
          if ('${post['username']}' != widget.username)
            Positioned(bottom: -7, left: 14, child: Container(width: 21, height: 21, decoration: const BoxDecoration(color: Color(0xFFFF2D55), shape: BoxShape.circle), child: const Icon(Icons.add, size: 15))),
        ]),
      ),
      const SizedBox(height: 19),
      _ActionButton(icon: '${post['liked']}' == 'true' ? Icons.favorite_rounded : Icons.favorite_border_rounded, value: '${post['likes'] ?? 0}', active: '${post['liked']}' == 'true', onTap: () => _like(post)),
      const SizedBox(height: 18),
      _ActionButton(icon: Icons.mode_comment_rounded, value: '${post['comments'] ?? 0}', onTap: () => _showComments(post)),
      const SizedBox(height: 18),
      _ActionButton(icon: '${post['saved']}' == 'true' ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, value: 'Simpan', active: '${post['saved']}' == 'true', onTap: () => _savePost(post)),
      const SizedBox(height: 18),
      _ActionButton(icon: Icons.share_rounded, value: 'Bagikan', onTap: () => _sharePost(post)),
      const SizedBox(height: 18),
      _ActionButton(icon: _muted ? Icons.volume_off_rounded : Icons.volume_up_rounded, value: '', onTap: () { setState(() => _muted = !_muted); for (final c in _videos.values) c.setVolume(_muted ? 0 : 1); }),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final posts = _visiblePosts;
    return Scaffold(backgroundColor: Colors.black, body: Stack(children: [if (_loading) const Center(child: CircularProgressIndicator()) else if (posts.isEmpty) _emptyFeed() else PageView.builder(controller: _feed, scrollDirection: Axis.vertical, itemCount: posts.length, onPageChanged: (i) async {
          _current = i;
          if (mounted) setState(() {});
          if (i < posts.length) {
            _viewPost(posts[i]);
            _preloadVideoAt(posts, i);
            _preloadVideoAt(posts, i + 1);
            _preloadVideoAt(posts, i - 1);
          }
          for (final e in _videos.entries) {
            if (e.key == i) { await e.value.play(); } else { await e.value.pause(); }
          }
        }, itemBuilder: (_, i) => _buildPost(posts[i], i)), _topBar(), if (_searching && _search.text.trim().length >= 2 && (_searchUsers.isNotEmpty || _searchPosts.isNotEmpty))
        Positioned(top: 58, left: 10, right: 10, child: SafeArea(top: false, child: Container(constraints: const BoxConstraints(maxHeight: 420), decoration: BoxDecoration(color: const Color(0xFF111318), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white12)), child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(8), children: [
          if (_searchUsers.isNotEmpty) ...[
            const Padding(padding: EdgeInsets.fromLTRB(8, 4, 8, 8), child: Text('AKUN', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w900))),
            ..._searchUsers.map((u) { final name='${u['username']}'; return ListTile(onTap: () { _search.clear(); _searchUsers=[]; _searchPosts=[]; _searching=false; setState(() {}); _openProfile(name); }, leading: _avatar(name,size:44,url:'${u['avatar_url'] ?? ''}'), title: Row(children:[Flexible(child:Text('@$name',style:const TextStyle(fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis)),if(u['verified']==true)...[const SizedBox(width:4),tiktokBlueTick(size:14)]]), subtitle: Text('${u['display_name'] ?? name} · ${u['followers'] ?? 0} pengikut'), trailing: const Icon(Icons.chevron_right_rounded)); }),
          ],
          if (_searchPosts.isNotEmpty) ...[
            const Padding(padding: EdgeInsets.fromLTRB(8, 10, 8, 8), child: Text('VIDEO', style: TextStyle(color: Colors.white54, fontSize: 11, fontWeight: FontWeight.w900))),
            ..._searchPosts.take(6).map((x) { final name='${x['username']}'; return ListTile(onTap: () { _search.clear(); _searchUsers=[]; _searchPosts=[]; _searching=false; setState(() {}); _openProfile(name); }, leading: Container(width:48,height:48,decoration:BoxDecoration(color:Colors.white10,borderRadius:BorderRadius.circular(8)),child: const Icon(Icons.play_arrow_rounded)), title: Row(children:[Flexible(child:Text('@$name',style:const TextStyle(fontWeight:FontWeight.w900),overflow:TextOverflow.ellipsis)),if(x['verified']==true)...[const SizedBox(width:4),tiktokBlueTick(size:13)]]), subtitle: Text('${x['caption'] ?? 'Video'} · ${x['views'] ?? 0} tayangan',maxLines:1,overflow:TextOverflow.ellipsis)); }),
          ],
        ])))),
        _bottomBar(), if (_uploading) Positioned.fill(child: Container(color: Colors.black.withOpacity(.82), child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(), SizedBox(height: 14), Text('Mengupload...', style: TextStyle(fontWeight: FontWeight.w900))]))))]));
  }
}

class _HeartBurst extends StatefulWidget {
  const _HeartBurst();
  @override State<_HeartBurst> createState() => _HeartBurstState();
}

class _HeartBurstState extends State<_HeartBurst> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 650))..forward();
  late final Animation<double> _scale = CurvedAnimation(parent: _c, curve: Curves.elasticOut);
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ScaleTransition(scale: _scale, child: const Icon(Icons.favorite_rounded, color: Colors.white, size: 118, shadows: [Shadow(color: Colors.black54, blurRadius: 20)]));
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String value;
  final bool active;
  final VoidCallback onTap;
  const _ActionButton({required this.icon, required this.value, required this.onTap, this.active = false});
  @override
  Widget build(BuildContext context) => GestureDetector(
    behavior: HitTestBehavior.opaque,
    onTap: onTap,
    child: SizedBox(
      width: 58,
      child: Column(children: [
        Icon(icon, size: 31, color: active ? const Color(0xFFFF2D55) : Colors.white, shadows: const [Shadow(color: Colors.black54, blurRadius: 5)]),
        if (value.isNotEmpty) ...[
          const SizedBox(height: 3),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, shadows: [Shadow(color: Colors.black54, blurRadius: 4)])),
        ],
      ]),
    ),
  );
}

class _LiveBadge extends StatelessWidget {
  const _LiveBadge();
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: Colors.redAccent, borderRadius: BorderRadius.circular(8)), child: const Text('LIVE', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11)));
}


Widget tiktokBlueTick({double size = 18}) => BlueVerifiedBadge(size: size);

class TiktokProfilePage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final bool following;
  final VoidCallback onFollow;
  const TiktokProfilePage({super.key, required this.sessionKey, required this.username, required this.following, required this.onFollow});
  @override State<TiktokProfilePage> createState()=>_TiktokProfilePageState();
}

class _TiktokProfilePageState extends State<TiktokProfilePage> {
  Map<String,dynamic>? _profile;
  List<Map<String,dynamic>> _posts=[];
  bool _loading=true,_saving=false,_following=false;
  int _profileTab = 0;
  List<Map<String,dynamic>> _likedPosts = [];
  Uri get _api=>Uri.parse(baseUrl);

  @override void initState(){super.initState();_following=widget.following;_load();}
  Future<void> _load() async{
    try{
      final r=await Future.wait([
        http.get(_api.replace(path:'/api/tiktok/profile',queryParameters:{'key':widget.sessionKey,'username':widget.username})).timeout(const Duration(seconds:12)),
        http.get(_api.replace(path:'/api/tiktok/profile/posts',queryParameters:{'key':widget.sessionKey,'username':widget.username,'mode':'all'})).timeout(const Duration(seconds:12)),
        http.get(_api.replace(path:'/api/tiktok/profile/posts',queryParameters:{'key':widget.sessionKey,'username':widget.username,'mode':'liked'})).timeout(const Duration(seconds:12)),
      ]);
      final pd=jsonDecode(r[0].body);final ad=jsonDecode(r[1].body);final ld=jsonDecode(r[2].body);
      if(mounted)setState((){_profile=pd['profile'] is Map?Map<String,dynamic>.from(pd['profile']):null;_posts=ad['posts'] is List?List<Map<String,dynamic>>.from(ad['posts']):[];_likedPosts=ld['posts'] is List?List<Map<String,dynamic>>.from(ld['posts']):[];_following=pd['profile']?['is_following']==true;_loading=false;});
    }catch(_){if(mounted)setState(()=>_loading=false);}
  }
  Future<void> _follow() async{try{final r=await http.post(_api.replace(path:'/api/tiktok/follow'),body:{'key':widget.sessionKey,'username':widget.username}).timeout(const Duration(seconds:8));final d=jsonDecode(r.body);if(d['valid']==true&&mounted){setState(()=>_following=d['following']==true);widget.onFollow();}}catch(_){}}

  Future<void> _editProfile() async {
    final p = _profile ?? {};
    final name = TextEditingController(text: '${p['display_name'] ?? widget.username}');
    final about = TextEditingController(text: '${p['about'] ?? ''}');
    XFile? avatar;

    Future<void> save(StateSetter setSheet, BuildContext sheetContext) async {
      if (_saving) return;
      setSheet(() => _saving = true);
      try {
        final req = http.MultipartRequest('POST', _api.replace(path: '/api/tiktok/profile/edit'));
        req.fields.addAll({
          'key': widget.sessionKey,
          'display_name': name.text.trim(),
          'about': about.text.trim(),
        });
        if (avatar != null) {
          req.files.add(await http.MultipartFile.fromPath(
            'avatar',
            avatar!.path,
            filename: avatar!.name,
            contentType: _proofContentType(avatar!.path),
          ));
        }
        final response = await req.send().timeout(const Duration(seconds: 60));
        final raw = await response.stream.bytesToString();
        final data = jsonDecode(raw);
        if (response.statusCode < 200 || response.statusCode >= 300 || data['valid'] != true) {
          throw Exception(data['message'] ?? 'Profil gagal disimpan');
        }
        if (sheetContext.mounted) Navigator.pop(sheetContext);
        await _load();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Profil TikTok berhasil diperbarui.')),
          );
        }
      } catch (e) {
        if (sheetContext.mounted) {
          ScaffoldMessenger.of(sheetContext).showSnackBar(
            SnackBar(content: Text('Gagal: ${e.toString().replaceFirst('Exception: ', '')}')),
          );
        }
      } finally {
        if (mounted) setState(() => _saving = false);
      }
    }

    try {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: const Color(0xFF111318),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        builder: (sheetContext) {
          return StatefulBuilder(
            builder: (sheetContext, setSheet) {
              final oldAvatar = '${p['avatar_url'] ?? ''}';
              ImageProvider? image;
              if (avatar != null) {
                image = FileImage(File(avatar!.path));
              } else if (oldAvatar.isNotEmpty) {
                image = NetworkImage(oldAvatar);
              }
              return Padding(
                padding: EdgeInsets.fromLTRB(
                  20,
                  14,
                  20,
                  MediaQuery.of(sheetContext).viewInsets.bottom + 22,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 42,
                          height: 4,
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(9),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'Edit profil TikTok',
                        style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Foto, nama, dan bio akan tampil di profil, komentar, LIVE, dan chat.',
                        style: TextStyle(color: Colors.white54),
                      ),
                      const SizedBox(height: 18),
                      Center(
                        child: GestureDetector(
                          onTap: () async {
                            final picked = await ImagePicker().pickImage(
                              source: ImageSource.gallery,
                              imageQuality: 92,
                            );
                            if (picked != null) setSheet(() => avatar = picked);
                          },
                          child: Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              CircleAvatar(
                                radius: 52,
                                backgroundColor: const Color(0xFF20232B),
                                backgroundImage: image,
                                child: image == null
                                    ? Text(
                                        widget.username.isEmpty
                                            ? '?'
                                            : widget.username[0].toUpperCase(),
                                        style: const TextStyle(
                                          fontSize: 36,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      )
                                    : null,
                              ),
                              Container(
                                width: 38,
                                height: 38,
                                decoration: const BoxDecoration(
                                  color: Color(0xFF20A9FF),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.camera_alt_rounded, size: 19),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: name,
                        maxLength: 40,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                        decoration: const InputDecoration(
                          labelText: 'Nama tampilan',
                          prefixIcon: Icon(Icons.person_outline_rounded),
                          filled: true,
                          fillColor: Color(0xFF1A1C22),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(16)),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: about,
                        maxLength: 120,
                        maxLines: 3,
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          labelText: 'Bio',
                          prefixIcon: Icon(Icons.notes_rounded),
                          filled: true,
                          fillColor: Color(0xFF1A1C22),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(16)),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: FilledButton.icon(
                          onPressed: _saving ? null : () => save(setSheet, sheetContext),
                          icon: _saving
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.check_rounded),
                          label: const Text('SIMPAN PROFIL'),
                        ),
                      ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              );
            },
          );
        },
      );
    } finally {
      name.dispose();
      about.dispose();
    }
  }

  Widget _avatar(double size, {String? url}){final u=url ?? '${_profile?['avatar_url']??''}';return Container(width:size,height:size,decoration:BoxDecoration(shape:BoxShape.circle,gradient:const LinearGradient(colors:[Color(0xFF20A9FF),Color(0xFF7B4DFF)]),boxShadow:[BoxShadow(color:Color(0x5520A9FF),blurRadius:20)]),padding:const EdgeInsets.all(3),child:ClipOval(child:u.isNotEmpty?Image.network(u,fit:BoxFit.cover,errorBuilder:(_,__,___)=>_letter(size)):Container(color:const Color(0xFF181A20),child:_letter(size))));}
  Widget _letter(double s)=>Center(child:Text(widget.username.isEmpty?'?':widget.username[0].toUpperCase(),style:TextStyle(fontSize:s*.38,fontWeight:FontWeight.w900)));
  Widget _stat(String v,String l)=>Expanded(child:Column(children:[Text(v,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:3),Text(l,style:const TextStyle(color:Colors.white54,fontSize:12))]));

  @override
  Widget build(BuildContext context) {
    final p = _profile ?? {};
    final mine = widget.username == (_profile?['username'] ?? widget.username);
    final verified = p['verified'] == true;
    final about = '${p['about'] ?? ''}';
    final display = '${p['display_name'] ?? widget.username}';
    return Scaffold(
      backgroundColor: Colors.black,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : CustomScrollView(
              slivers: [
                SliverAppBar(
                  pinned: true,
                  expandedHeight: 76,
                  backgroundColor: Colors.black,
                  surfaceTintColor: Colors.black,
                  titleSpacing: 4,
                  title: Row(children: [
                    Flexible(child: Text('@${widget.username}', style: const TextStyle(fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis)),
                    if (verified) ...[const SizedBox(width: 5), tiktokBlueTick(size: 18)],
                  ]),
                  actions: [
                    if (mine)
                      IconButton(onPressed: _editProfile, tooltip: 'Edit profil', icon: const Icon(Icons.edit_outlined)),
                    if (mine)
                      IconButton(
                        onPressed: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => TiktokBlueTickPage(sessionKey: widget.sessionKey, username: widget.username)));
                          await _load();
                        },
                        tooltip: 'Centang biru',
                        icon: tiktokBlueTick(size: 22),
                      ),
                    IconButton(
                      onPressed: () => Share.share('Lihat profil @$display di DEY TikTok'),
                      tooltip: 'Bagikan profil',
                      icon: const Icon(Icons.share_outlined),
                    ),
                  ],
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                        Stack(clipBehavior: Clip.none, children: [
                          Container(
                            padding: const EdgeInsets.all(2),
                            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white24)),
                            child: _avatar(88, url: '${p['avatar_url'] ?? ''}'),
                          ),
                          if (verified)
                            Positioned(right: -2, bottom: -1, child: tiktokBlueTick(size: 25)),
                        ]),
                        const SizedBox(width: 18),
                        Expanded(
                          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                            _stat('${_posts.length}', 'Postingan'),
                            _stat('${p['followers'] ?? 0}', 'Pengikut'),
                            _stat('${p['following'] ?? 0}', 'Mengikuti'),
                            _stat('${p['likes'] ?? 0}', 'Suka'),
                          ]),
                        ),
                      ]),
                      const SizedBox(height: 14),
                      Row(children: [
                        Flexible(child: Text(display, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis)),
                        if (verified) ...[const SizedBox(width: 5), tiktokBlueTick(size: 18)],
                      ]),
                      const SizedBox(height: 2),
                      Text('@${widget.username}', style: const TextStyle(color: Colors.white54, fontSize: 13)),
                      if (about.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text(about, style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.25)),
                      ],
                      const SizedBox(height: 14),
                      Row(children: [
                        Expanded(
                          child: SizedBox(
                            height: 42,
                            child: mine
                                ? OutlinedButton(onPressed: _editProfile, style: OutlinedButton.styleFrom(side: const BorderSide(color: Colors.white24), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Text('Edit profil', style: TextStyle(fontWeight: FontWeight.w900)))
                                : FilledButton(onPressed: _follow, style: FilledButton.styleFrom(backgroundColor: _following ? const Color(0xFF25272D) : const Color(0xFF20A9FF), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: Text(_following ? 'Mengikuti' : 'Ikuti', style: const TextStyle(fontWeight: FontWeight.w900))),
                          ),
                        ),
                        const SizedBox(width: 8),
                        SizedBox(height: 42, width: 46, child: OutlinedButton(onPressed: () => Share.share('Lihat profil @$display di DEY TikTok'), style: OutlinedButton.styleFrom(padding: EdgeInsets.zero, side: const BorderSide(color: Colors.white24), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), child: const Icon(Icons.share_outlined, size: 19))),
                      ]),
                    ]),
                  ),
                ),
                SliverPersistentHeader(
                  pinned: true,
                  delegate: _TikTokProfileTabsDelegate(active: _profileTab, onTap: (v) => setState(() => _profileTab = v)),
                ),
                if ((_profileTab == 0 ? _posts : _likedPosts).isEmpty)
                  const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('Belum ada postingan', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.w700))))
                else
                  SliverPadding(
                    padding: const EdgeInsets.all(3),
                    sliver: SliverGrid(
                      delegate: SliverChildBuilderDelegate((ctx, i) {
                        final sourcePosts = _profileTab == 0 ? _posts : _likedPosts;
                        final x = sourcePosts[i];
                        final url = '${x['video_url']}';
                        return Stack(fit: StackFit.expand, children: [
                          if ('${x['media_type']}' == 'image' || '${x['media_type']}' == 'gif')
                            Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF17191F)))
                          else
                            VideoPlayerThumbnail(url: url),
                          const Positioned.fill(child: IgnorePointer(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black54]))))),
                          Positioned(left: 7, bottom: 6, child: Row(children: [const Icon(Icons.play_arrow_rounded, size: 15), const SizedBox(width: 2), Text('${x['views'] ?? 0}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800))])),
                        ]);
                      }, childCount: (_profileTab == 0 ? _posts : _likedPosts).length),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, childAspectRatio: .72),
                    ),
                  ),
              ],
            ),
    );
  }
}

class _TikTokProfileTabsDelegate extends SliverPersistentHeaderDelegate {
  final int active;
  final ValueChanged<int> onTap;
  const _TikTokProfileTabsDelegate({required this.active, required this.onTap});
  @override double get minExtent => 50;
  @override double get maxExtent => 50;
  @override Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) => Container(
    decoration: const BoxDecoration(color: Colors.black, border: Border(top: BorderSide(color: Colors.white10), bottom: BorderSide(color: Colors.white10))),
    child: Row(children: [
      Expanded(child: InkWell(onTap: () => onTap(0), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.grid_on_rounded, size: 21, color: active == 0 ? Colors.white : Colors.white38), const SizedBox(height: 3), AnimatedContainer(duration: const Duration(milliseconds: 160), width: active == 0 ? 34 : 0, height: 2, color: Colors.white)])))),
      Expanded(child: InkWell(onTap: () => onTap(1), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.favorite_border_rounded, size: 21, color: active == 1 ? Colors.white : Colors.white38), const SizedBox(height: 3), AnimatedContainer(duration: const Duration(milliseconds: 160), width: active == 1 ? 34 : 0, height: 2, color: Colors.white)])))),
    ]),
  );
  @override bool shouldRebuild(covariant _TikTokProfileTabsDelegate oldDelegate) => oldDelegate.active != active;
}


class VideoPlayerThumbnail extends StatefulWidget {
  final String url;
  const VideoPlayerThumbnail({super.key, required this.url});
  @override State<VideoPlayerThumbnail> createState() => _VideoPlayerThumbnailState();
}
class _VideoPlayerThumbnailState extends State<VideoPlayerThumbnail> {
  VideoPlayerController? c;
  @override void initState() { super.initState(); c = VideoPlayerController.networkUrl(Uri.parse(widget.url))..initialize().then((_) { if (mounted) setState(() {}); }).catchError((_) {}); }
  @override void dispose() { c?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => c != null && c!.value.isInitialized ? FittedBox(fit: BoxFit.cover, child: SizedBox(width: c!.value.size.width, height: c!.value.size.height, child: VideoPlayer(c!))) : const ColoredBox(color: Color(0xFF17191F));
}

Future<List<Map<String, dynamic>>> _fetchTikTokIce(String key) async {
  final uri = Uri.parse(baseUrl).replace(
    path: '/api/chat/private/ice',
    queryParameters: {'session_key': key},
  );
  final r = await http.get(uri).timeout(const Duration(seconds: 12));
  if (r.statusCode != 200) {
    throw Exception('ICE API HTTP ${r.statusCode}');
  }
  final d = jsonDecode(r.body);
  if (d is Map && d['valid'] == true && d['iceServers'] is List) {
    final servers = List<Map<String, dynamic>>.from(
      (d['iceServers'] as List).map((e) => Map<String, dynamic>.from(e as Map)),
    );
    if (servers.isNotEmpty) return servers;
  }
  throw Exception('TURN Xirsys belum tersedia');
}

class TiktokLiveHostPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String liveId;
  const TiktokLiveHostPage({super.key, required this.sessionKey, required this.username, required this.liveId});
  @override State<TiktokLiveHostPage> createState() => _TiktokLiveHostPageState();
}

class _TiktokLiveHostPageState extends State<TiktokLiveHostPage> {
  IO.Socket? _socket;
  MediaStream? _stream;
  final RTCVideoRenderer _renderer = RTCVideoRenderer();
  final Map<String, RTCPeerConnection> _peers = {};
  final Map<String, List<RTCIceCandidate>> _pendingPeerIce = {};
  final Set<String> _peerRemoteReady = {};
  Timer? _heartbeat;
  Timer? _audioRouteTimer;
  bool _starting = true;
  bool _ending = false;
  int _viewers = 0;
  List<Map<String, dynamic>> _ice = [];
  final List<Map<String,dynamic>> _comments = [];

  @override void initState() { super.initState(); _start(); }

  Future<void> _configureAudio() async {
    try {
      await Helper.setAndroidAudioConfiguration(AndroidAudioConfiguration(
        androidAudioMode: AndroidAudioMode.inCommunication,
        androidAudioFocusMode: AndroidAudioFocusMode.gain,
        forceHandleAudioRouting: true,
      ));
    } catch (_) {}
    try { await Helper.setSpeakerphoneOn(true); } catch (_) {}
  }

  Future<void> _start() async {
    try {
      final cam = await Permission.camera.request();
      final mic = await Permission.microphone.request();
      if (!cam.isGranted || !mic.isGranted) throw Exception('Izin kamera/microphone ditolak');
      await _renderer.initialize();
      await _configureAudio();
      _ice = await _fetchTikTokIce(widget.sessionKey);

      final constraints = <String, dynamic>{
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
          'channelCount': 1,
        },
        'video': {
          'facingMode': 'user',
          'width': {'ideal': 720, 'max': 1280},
          'height': {'ideal': 1280, 'max': 1280},
          'frameRate': {'ideal': 24, 'max': 30},
        },
      };
      _stream = await navigator.mediaDevices.getUserMedia(constraints);
      for (final t in _stream!.getAudioTracks()) {
        t.enabled = true;
        try { await Helper.setMicrophoneMute(false, t); } catch (_) {}
      }
      for (final t in _stream!.getVideoTracks()) { t.enabled = true; }
      _renderer.srcObject = _stream;

      _socket = IO.io(baseUrl, IO.OptionBuilder()
          .setTransports(['websocket'])
          .enableReconnection()
          .setReconnectionAttempts(10)
          .setReconnectionDelay(1000)
          .disableAutoConnect()
          .build());
      _bindSocket();
      _socket!.connect();
      _heartbeat = Timer.periodic(const Duration(seconds: 8), (_) => _sendHeartbeat());
      _audioRouteTimer = Timer.periodic(const Duration(seconds: 2), (_) => _configureAudio());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('LIVE gagal dimulai: $e')));
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  Map<String, dynamic> _pcConfig() => {
    'iceServers': _ice,
    'sdpSemantics': 'unified-plan',
    'bundlePolicy': 'max-bundle',
    'rtcpMuxPolicy': 'require',
    'iceCandidatePoolSize': 10,
    'iceTransportPolicy': 'all',
  };

  void _bindSocket() {
    _socket!.onConnect((_) {
      _socket!.emit('tiktok:live:host', {'key': widget.sessionKey, 'live_id': widget.liveId});
      _sendHeartbeat();
    });
    _socket!.on('tiktok:live:viewer', (d) => _makeOffer('${d['viewer_id']}'));
    _socket!.on('tiktok:live:answer', (d) async {
      final peerId = '${d['viewer_id'] ?? ''}';
      final pc = _peers[peerId];
      final sdp = d['sdp']?.toString();
      if (pc == null || sdp == null || sdp.isEmpty) return;
      try {
        await pc.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
        _peerRemoteReady.add(peerId);
        final queued = _pendingPeerIce.remove(peerId) ?? <RTCIceCandidate>[];
        for (final c in queued) { try { await pc.addCandidate(c); } catch (_) {} }
      } catch (e) {
        _dropPeer(peerId);
      }
    });
    _socket!.on('tiktok:live:ice', (d) async {
      final candidate = d['candidate'];
      final peerId = '${d['peer_id'] ?? ''}';
      if (candidate == null || peerId.isEmpty) return;
      final c = RTCIceCandidate(
        candidate is Map ? candidate['candidate']?.toString() : candidate.toString(),
        d['sdpMid']?.toString() ?? (candidate is Map ? candidate['sdpMid']?.toString() : null),
        int.tryParse('${d['sdpMLineIndex'] ?? (candidate is Map ? candidate['sdpMLineIndex'] : null)}'),
      );
      final pc = _peers[peerId];
      if (pc == null || !_peerRemoteReady.contains(peerId)) {
        (_pendingPeerIce[peerId] ??= []).add(c);
        return;
      }
      try { await pc.addCandidate(c); } catch (_) {}
    });
    _socket!.on('tiktok:live:viewer_count', (d) {
      if (mounted) setState(() => _viewers = int.tryParse('${d['count']}') ?? _viewers);
    });
    _socket!.on('tiktok:live:comment', (d) {
      if (mounted) setState(() => _comments.insert(0, Map<String,dynamic>.from(d)));
    });
    _socket!.on('tiktok:live:gift', (d) {
      if (mounted) setState(() => _comments.insert(0, {'username':d['username'],'text':'🎁 ${d['gift'] ?? 'Gift'}','verified':d['verified']==true}));
    });
    _socket!.onDisconnect((_) {});
  }

  Future<void> _sendHeartbeat() async {
    try {
      await http.post(Uri.parse(baseUrl).replace(path: '/api/tiktok/live/heartbeat'), body: {
        'key': widget.sessionKey,
        'live_id': widget.liveId,
      }).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  Future<void> _makeOffer(String viewerId) async {
    if (_stream == null || viewerId.isEmpty || _peers.containsKey(viewerId)) return;
    try {
      final pc = await createPeerConnection(_pcConfig());
      _peers[viewerId] = pc;
      for (final t in _stream!.getTracks()) { await pc.addTrack(t, _stream!); }
      pc.onIceCandidate = (c) {
        if (c.candidate != null && c.candidate!.isNotEmpty) {
          _socket?.emit('tiktok:live:ice', {
            'to': viewerId,
            'candidate': c.candidate,
            'sdpMid': c.sdpMid,
            'sdpMLineIndex': c.sdpMLineIndex,
          });
        }
      };
      pc.onConnectionState = (state) {
        if (state == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
            state == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
          _dropPeer(viewerId);
        }
        if (mounted) setState(() => _viewers = _peers.length);
      };
      pc.onIceConnectionState = (state) {
        if (state == RTCIceConnectionState.RTCIceConnectionStateFailed) {
          try { pc.restartIce(); } catch (_) {}
        }
      };
      final offer = await pc.createOffer({'offerToReceiveAudio': false, 'offerToReceiveVideo': false});
      await pc.setLocalDescription(offer);
      _socket?.emit('tiktok:live:offer', {'to': viewerId, 'sdp': offer.sdp, 'type': offer.type});
      if (mounted) setState(() => _viewers = _peers.length);
    } catch (_) {
      _dropPeer(viewerId);
    }
  }

  void _dropPeer(String id) {
    final pc = _peers.remove(id);
    _peerRemoteReady.remove(id);
    _pendingPeerIce.remove(id);
    try { pc?.close(); } catch (_) {}
    if (mounted) setState(() => _viewers = _peers.length);
  }

  Future<void> _end() async {
    if (_ending) return;
    setState(() => _ending = true);
    _heartbeat?.cancel();
    _audioRouteTimer?.cancel();
    try { await http.post(Uri.parse(baseUrl).replace(path: '/api/tiktok/live/end'), body: {'key': widget.sessionKey, 'live_id': widget.liveId}); } catch (_) {}
    _socket?.emit('tiktok:live:end', {'live_id': widget.liveId});
    for (final pc in _peers.values) { try { await pc.close(); } catch (_) {} }
    _peers.clear();
    for (final t in _stream?.getTracks() ?? <MediaStreamTrack>[]) { try { t.stop(); } catch (_) {} }
    try { await _stream?.dispose(); } catch (_) {}
    _socket?.dispose();
    _renderer.srcObject = null;
    await _renderer.dispose();
    if (mounted) Navigator.pop(context);
  }

  @override void dispose() {
    _heartbeat?.cancel();
    _audioRouteTimer?.cancel();
    for (final pc in _peers.values) { try { pc.close(); } catch (_) {} }
    for (final t in _stream?.getTracks() ?? <MediaStreamTrack>[]) { try { t.stop(); } catch (_) {} }
    try { _stream?.dispose(); } catch (_) {}
    _socket?.dispose();
    _renderer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          RTCVideoView(_renderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover, mirror: true),
          Positioned(
            top: 0, left: 0, right: 0,
            child: SafeArea(child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                const _LiveBadge(), const SizedBox(width: 9),
                Text('@${widget.username}', style: const TextStyle(fontWeight: FontWeight.w900)),
                const Spacer(), Text('$_viewers penonton', style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
            )),
          ),
          Positioned(
            left: 12, right: 12, bottom: 88,
            child: SizedBox(
              height: 150,
              child: ListView(children: _comments.take(6).map((x)=>Padding(padding:const EdgeInsets.only(bottom:7),child:Row(mainAxisSize:MainAxisSize.min,children:[Flexible(child:Text('${x['display_name'] ?? x['username']}: ${x['text']}',style:const TextStyle(fontWeight:FontWeight.w700,shadows:[Shadow(color:Colors.black54,blurRadius:4)]))),if(x['verified']==true)...[const SizedBox(width:4),tiktokBlueTick(size:14)]]))).toList()),
            ),
          ),
          if (_starting) const Center(child: CircularProgressIndicator()),
          Positioned(
            bottom: 24, left: 0, right: 0,
            child: Center(child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
              onPressed: _ending ? null : _end,
              icon: const Icon(Icons.stop_circle),
              label: const Text('AKHIRI LIVE'),
            )),
          ),
        ],
      ),
    );
  }
}

class TiktokLiveViewerPage extends StatefulWidget {
  final String sessionKey;
  final String liveId;
  final String host;
  final bool hostVerified;
  const TiktokLiveViewerPage({super.key, required this.sessionKey, required this.liveId, required this.host, this.hostVerified = false});
  @override State<TiktokLiveViewerPage> createState() => _TiktokLiveViewerPageState();
}

class _TiktokLiveViewerPageState extends State<TiktokLiveViewerPage> {
  IO.Socket? _socket;
  RTCPeerConnection? _pc;
  final RTCVideoRenderer _renderer = RTCVideoRenderer();
  List<Map<String, dynamic>> _ice = [];
  bool _loading = true;
  bool _connected = false;
  bool _audioReceived = false;
  final List<RTCIceCandidate> _pendingIce = [];
  MediaStream? _remoteStream;
  bool _remoteReady = false;
  Timer? _audioRouteTimer;
  final TextEditingController _comment = TextEditingController();
  final List<Map<String,dynamic>> _comments = [];
  String? _hostSocket;

  @override void initState() { super.initState(); _join(); }

  Future<void> _configureAudio() async {
    try {
      await Helper.setAndroidAudioConfiguration(AndroidAudioConfiguration(
        androidAudioMode: AndroidAudioMode.inCommunication,
        androidAudioFocusMode: AndroidAudioFocusMode.gain,
        forceHandleAudioRouting: true,
      ));
    } catch (_) {}
    try { await Helper.setSpeakerphoneOn(true); } catch (_) {}
  }

  Map<String, dynamic> _pcConfig() => {
    'iceServers': _ice,
    'sdpSemantics': 'unified-plan',
    'bundlePolicy': 'max-bundle',
    'rtcpMuxPolicy': 'require',
    'iceCandidatePoolSize': 10,
    'iceTransportPolicy': 'all',
  };

  Future<void> _join() async {
    try {
      await _renderer.initialize();
      await _configureAudio();
      _ice = await _fetchTikTokIce(widget.sessionKey);
      _socket = IO.io(baseUrl, IO.OptionBuilder()
          .setTransports(['websocket'])
          .enableReconnection()
          .setReconnectionAttempts(10)
          .setReconnectionDelay(1000)
          .disableAutoConnect()
          .build());
      _bindSocket();
      _socket!.connect();
      _audioRouteTimer = Timer.periodic(const Duration(seconds: 2), (_) => _configureAudio());
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('LIVE gagal dibuka: $e')));
      }
    }
  }

  void _bindSocket() {
    _socket!.onConnect((_) => _socket!.emit('tiktok:live:join', {'key': widget.sessionKey, 'live_id': widget.liveId}));
    _socket!.on('tiktok:live:offer', _handleOffer);
    _socket!.on('tiktok:live:ice', _handleIce);
    _socket!.on('tiktok:live:comment', (d) { if (mounted) setState(() => _comments.insert(0, Map<String,dynamic>.from(d))); });
    _socket!.on('tiktok:live:gift', (d) { if (mounted) setState(() => _comments.insert(0, {'username':d['username'],'text':'🎁 ${d['gift'] ?? 'Gift'}','verified':d['verified']==true})); });
    _socket!.on('tiktok:live:ended', (_) { if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('LIVE sudah berakhir.'))); Navigator.pop(context); } });
    _socket!.on('tiktok:live:error', (d) { if (mounted) { setState(() => _loading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${d['message'] ?? 'LIVE error'}'))); } });
  }

  Future<void> _handleOffer(dynamic data) async {
    try {
      final sdp = data is Map ? data['sdp']?.toString() : null;
      if (sdp == null || sdp.isEmpty) return;
      _hostSocket = data['from']?.toString();
      await _pc?.close();
      _pc = await createPeerConnection(_pcConfig());
      _remoteReady = false;
      _audioReceived = false;

      _pc!.onTrack = (event) async {
        try { event.track.enabled = true; } catch (_) {}
        if (event.track.kind == 'audio') {
          _audioReceived = true;
          try { await Helper.setVolume(1.0, event.track); } catch (_) {}
          await _configureAudio();
        }
        try {
          if (event.streams.isNotEmpty) {
            _renderer.srcObject = event.streams.first;
            _remoteStream = event.streams.first;
          } else {
            _remoteStream ??= await createLocalMediaStream('tiktok-live-remote');
            await _remoteStream!.addTrack(event.track);
            _renderer.srcObject = _remoteStream;
          }
        } catch (_) {}
        if (mounted) setState(() { _loading = false; _connected = true; });
      };
      _pc!.onAddStream = (stream) async {
        _renderer.srcObject = stream;
        for (final t in stream.getAudioTracks()) {
          try { t.enabled = true; } catch (_) {}
          try { await Helper.setVolume(1.0, t); } catch (_) {}
        }
        await _configureAudio();
        if (mounted) setState(() { _loading = false; _connected = true; _audioReceived = stream.getAudioTracks().isNotEmpty; });
      };
      _pc!.onIceCandidate = (c) {
        if (c.candidate != null && c.candidate!.isNotEmpty && _hostSocket != null) {
          _socket?.emit('tiktok:live:ice', {
            'to': _hostSocket,
            'candidate': c.candidate,
            'sdpMid': c.sdpMid,
            'sdpMLineIndex': c.sdpMLineIndex,
          });
        }
      };
      _pc!.onConnectionState = (state) {
        if (state == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
          _configureAudio();
          if (mounted) setState(() { _connected = true; _loading = false; });
        } else if (state == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
          if (mounted) setState(() { _connected = false; _loading = false; });
          try { _pc?.restartIce(); } catch (_) {}
        }
      };
      _pc!.onIceConnectionState = (state) {
        if (state == RTCIceConnectionState.RTCIceConnectionStateConnected || state == RTCIceConnectionState.RTCIceConnectionStateCompleted) {
          _configureAudio();
          if (mounted) setState(() { _connected = true; _loading = false; });
        }
      };

      await _pc!.setRemoteDescription(RTCSessionDescription(sdp, 'offer'));
      _remoteReady = true;
      for (final c in List<RTCIceCandidate>.from(_pendingIce)) { try { await _pc!.addCandidate(c); } catch (_) {} }
      _pendingIce.clear();
      final answer = await _pc!.createAnswer({'offerToReceiveAudio': true, 'offerToReceiveVideo': true});
      await _pc!.setLocalDescription(answer);
      _socket?.emit('tiktok:live:answer', {'to': _hostSocket, 'viewer_id': _socket?.id, 'sdp': answer.sdp, 'type': answer.type});
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('LIVE media error: $e')));
      }
    }
  }

  Future<void> _handleIce(dynamic data) async {
    if (data is! Map || data['candidate'] == null) return;
    final raw = data['candidate'];
    final c = RTCIceCandidate(
      raw is Map ? raw['candidate']?.toString() : raw.toString(),
      data['sdpMid']?.toString() ?? (raw is Map ? raw['sdpMid']?.toString() : null),
      int.tryParse('${data['sdpMLineIndex'] ?? (raw is Map ? raw['sdpMLineIndex'] : null)}'),
    );
    if (_pc == null || !_remoteReady) { _pendingIce.add(c); return; }
    try { await _pc!.addCandidate(c); } catch (_) {}
  }

  Future<void> _sendGift(String gift) async {
    try {
      final r = await http.post(Uri.parse(baseUrl).replace(path: '/api/tiktok/coins/gift'), body: {'key': widget.sessionKey, 'live_id': widget.liveId, 'gift': gift}).timeout(const Duration(seconds: 8));
      final d = jsonDecode(r.body);
      if (d['valid'] != true) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${d['message'] ?? 'Gift gagal'}'))); return; }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${d['gift']?['emoji'] ?? '🎁'} Gift terkirim · saldo ${d['coins'] ?? 0} koin')));
    } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gagal mengirim gift.'))); }
  }

  void _sendComment() {
    final text = _comment.text.trim();
    if (text.isEmpty) return;
    _socket?.emit('tiktok:live:comment', {'key': widget.sessionKey, 'live_id': widget.liveId, 'text': text});
    _comment.clear();
  }

  @override void dispose() {
    _audioRouteTimer?.cancel();
    _comment.dispose();
    try { _remoteStream?.dispose(); } catch (_) {}
    try { _pc?.close(); } catch (_) {}
    _socket?.dispose();
    _renderer.dispose();
    super.dispose();
  }

  Widget _avatar(String username, {double size = 48, String? url}) {
    final u = (url ?? '').trim();
    return Container(width: size, height: size, decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF20232A)), child: ClipOval(child: u.isNotEmpty ? Image.network(u, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _avatarLetter(username, size)) : _avatarLetter(username, size)));
  }

  Widget _avatarLetter(String username, double size) => Center(child: Text(username.isEmpty ? '?' : username.substring(0, 1).toUpperCase(), style: TextStyle(fontSize: size * .36, fontWeight: FontWeight.w900)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          RTCVideoView(_renderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
          const Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black54, Colors.transparent, Colors.black87],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: const BoxDecoration(color: Colors.black45, shape: BoxShape.circle),
                        child: const Icon(Icons.close_rounded),
                      ),
                    ),
                    const SizedBox(width: 9),
                    const _LiveBadge(),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Row(
                        children: [
                          Flexible(
                            child: Text(
                              '@${widget.host}',
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                          if (widget.hostVerified) ...[
                            const SizedBox(width: 4),
                            tiktokBlueTick(size: 16),
                          ],
                        ],
                      ),
                    ),
                    if (_connected) const Icon(Icons.wifi_rounded, size: 18),
                  ],
                ),
              ),
            ),
          ),
          if (_loading) const Center(child: CircularProgressIndicator()),
          if (!_loading && !_connected)
            const Center(child: Text('Menunggu koneksi LIVE...', style: TextStyle(fontWeight: FontWeight.w800))),
          Positioned(
            left: 12,
            right: 12,
            bottom: 92,
            child: SizedBox(
              height: 220,
              child: ListView.builder(
                itemCount: _comments.length > 9 ? 9 : _comments.length,
                itemBuilder: (context, index) {
                  final x = _comments[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        _avatar('${x['username'] ?? ''}', size: 28, url: '${x['avatar_url'] ?? ''}'),
                        const SizedBox(width: 7),
                        Flexible(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                            decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
                            child: Wrap(
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Text(
                                  '${x['display_name'] ?? x['username']}: ${x['text']}',
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                                ),
                                if (x['verified'] == true) ...[
                                  const SizedBox(width: 4),
                                  tiktokBlueTick(size: 13),
                                ],
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
          Positioned(
            right: 10,
            bottom: 112,
            child: Column(
              children: [
                _ActionButton(icon: Icons.favorite_rounded, value: '', onTap: () {}),
                const SizedBox(height: 18),
                GestureDetector(
                  onTap: () => _sendGift('Rose'),
                  child: Container(
                    width: 48,
                    height: 48,
                    decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                    child: const Icon(Icons.card_giftcard_rounded, color: Colors.pinkAccent, size: 25),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 18,
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: const Color(0xDD101217),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: TextField(
                        controller: _comment,
                        onSubmitted: (_) => _sendComment(),
                        decoration: const InputDecoration(
                          hintText: 'Kirim komentar...',
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(horizontal: 17, vertical: 13),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: _sendComment,
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: const BoxDecoration(color: Color(0xFF20A9FF), shape: BoxShape.circle),
                      child: const Icon(Icons.send_rounded),
                    ),
                  ),
                  const SizedBox(width: 7),
                  PopupMenuButton<String>(
                    onSelected: _sendGift,
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'Rose', child: Text('🌹 Rose · 1 koin')),
                      PopupMenuItem(value: 'Love', child: Text('❤️ Love · 3 koin')),
                      PopupMenuItem(value: 'Fire', child: Text('🔥 Fire · 5 koin')),
                      PopupMenuItem(value: 'Diamond', child: Text('💎 Diamond · 20 koin')),
                      PopupMenuItem(value: 'Rocket', child: Text('🚀 Rocket · 50 koin')),
                    ],
                    child: Container(
                      width: 48,
                      height: 48,
                      decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                      child: const Icon(Icons.card_giftcard_rounded, color: Colors.pinkAccent),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class TiktokCoinPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const TiktokCoinPage({super.key, required this.sessionKey, required this.username});
  @override State<TiktokCoinPage> createState() => _TiktokCoinPageState();
}

class _TiktokCoinPageState extends State<TiktokCoinPage> {
  bool _loading=true, _busy=false;
  int _coins=0;
  List<Map<String,dynamic>> _packages=[];
  List<Map<String,dynamic>> _history=[];
  Map<String,dynamic> _payment={};
  final ImagePicker _picker=ImagePicker();

  Uri get _api=>Uri.parse(baseUrl);
  @override void initState(){super.initState(); _load();}

  Future<void> _load() async {
    try {
      final results=await Future.wait([
        http.get(_api.replace(path:'/api/tiktok/coins/config',queryParameters:{'key':widget.sessionKey})).timeout(const Duration(seconds:10)),
        http.get(_api.replace(path:'/api/tiktok/coins/history',queryParameters:{'key':widget.sessionKey})).timeout(const Duration(seconds:10)),
      ]);
      final c=jsonDecode(results[0].body), h=jsonDecode(results[1].body);
      if(c['valid']==true){_coins=num.tryParse('${c['coins']}')?.toInt()??0; _packages=List<Map<String,dynamic>>.from(c['packages']??[]); _payment=Map<String,dynamic>.from(c['payment']??{});}
      if(h['valid']==true){_coins=num.tryParse('${h['coins']}')?.toInt()??_coins; _history=List<Map<String,dynamic>>.from(h['purchases']??[]);}
    }catch(_){if(mounted)_toast('Gagal memuat koin.');}
    finally{if(mounted)setState(()=>_loading=false);}
  }
  int _num(dynamic x)=>int.tryParse('$x')??0;
  String _rp(int n)=>'Rp${n.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+$)'),(_)=>'.')}';
  void _toast(String x){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));}

  Future<void> _buy(Map<String,dynamic> pack) async {
    if(_busy)return;
    setState(()=>_busy=true);
    try{
      final r=await http.post(_api.replace(path:'/api/tiktok/coins/purchase'),body:{'key':widget.sessionKey,'coins':'${pack['coins']}','price':'${pack['price']}'}).timeout(const Duration(seconds:10));
      final d=jsonDecode(r.body); if(d['valid']!=true)throw Exception(d['message']??'Gagal membuat transaksi');
      final id='${d['purchase']['id']}';
      if(!mounted)return;
      await showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:const Color(0xFF101116),shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(28))),builder:(ctx)=>_ProofSheet(sessionKey:widget.sessionKey,purchaseId:id,coins:_num(pack['coins']),price:_num(pack['price']),payment:_payment,onDone:(){Navigator.pop(ctx);_load();}));
    }catch(e){_toast('Pembelian gagal: ${e.toString().replaceFirst('Exception: ','')}');}
    finally{if(mounted)setState(()=>_busy=false);}
  }

  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor:Colors.black,appBar:AppBar(backgroundColor:Colors.black,title:const Text('Koin DEY',style:TextStyle(fontWeight:FontWeight.w900)),actions:[Padding(padding:const EdgeInsets.symmetric(horizontal:14),child:Center(child:Text('🪙 $_coins',style:const TextStyle(fontWeight:FontWeight.w900))))]),body:_loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF252733),Color(0xFF101116)]),border:Border.all(color:Colors.white12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Saldo Koin',style:TextStyle(color:Colors.white60)),const SizedBox(height:5),Text('🪙 $_coins',style:const TextStyle(fontSize:32,fontWeight:FontWeight.w900)),const SizedBox(height:5),const Text('Koin dipakai untuk mengirim gift saat LIVE.',style:TextStyle(color:Colors.white70))])),
      const SizedBox(height:20),const Text('Beli Koin',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:10),
      ..._packages.map((p)=>Padding(padding:const EdgeInsets.only(bottom:9),child:ListTile(tileColor:const Color(0xFF17191F),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),leading:const CircleAvatar(backgroundColor:Color(0xFF262832),child:Text('🪙')),title:Text('${p['coins']} Koin',style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(_rp(_num(p['price']))),trailing:FilledButton(onPressed:_busy?null:()=>_buy(p),child:const Text('BELI'))))),
      const SizedBox(height:14),const Text('Riwayat Pembelian',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),
      if(_history.isEmpty)const Padding(padding:EdgeInsets.all(18),child:Text('Belum ada transaksi.')) else ..._history.map((x)=>ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:4),leading:const Icon(Icons.receipt_long_rounded),title:Text('${x['coins']} koin · ${_rp(_num(x['price']))}'),subtitle:Text('${x['id']} · ${x['status']}'))),
    ])));
  }
}

class _ProofSheet extends StatefulWidget {
  final String sessionKey,purchaseId; final int coins,price; final Map<String,dynamic> payment; final VoidCallback onDone;
  const _ProofSheet({required this.sessionKey,required this.purchaseId,required this.coins,required this.price,required this.payment,required this.onDone});
  @override State<_ProofSheet> createState()=>_ProofSheetState();
}
class _ProofSheetState extends State<_ProofSheet>{
  XFile? _proof; bool _sending=false;
  Future<void> _pick() async { final f=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:92); if(f!=null&&mounted)setState(()=>_proof=f); }
  String _rp(int n)=>'Rp${n.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+$)'),(_)=>'.')}';
  Future<void> _send() async {
    if(_proof==null)return;setState(()=>_sending=true);
    try{final req=http.MultipartRequest('POST',Uri.parse(baseUrl).replace(path:'/api/tiktok/coins/purchase/proof'));req.headers['Accept']='application/json';req.fields['key']=widget.sessionKey;req.fields['purchase_id']=widget.purchaseId;req.files.add(await http.MultipartFile.fromPath('proof',_proof!.path,filename:_proof!.name,contentType:_proofContentType(_proof!.path)));final r=await req.send().timeout(const Duration(seconds:45));final raw=await r.stream.bytesToString();Map<String,dynamic> d;try{d=Map<String,dynamic>.from(jsonDecode(raw) as Map);}catch(_){throw Exception('Server mengembalikan respons tidak valid (${r.statusCode})');}if(r.statusCode<200||r.statusCode>=300||d['valid']!=true)throw Exception(d['message']??'Bukti ditolak');if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Bukti transfer terkirim. Menunggu verifikasi admin.')));widget.onDone();}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal: ${e.toString().replaceFirst('Exception: ','')}')));}finally{if(mounted)setState(()=>_sending=false);}
  }
  @override Widget build(BuildContext context)=>Padding(padding:EdgeInsets.fromLTRB(18,18,18,MediaQuery.of(context).viewInsets.bottom+18),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Pembayaran Koin',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('${widget.coins} Koin · ${_rp(widget.price)}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:14),if('${widget.payment['qr_url']??''}'.isNotEmpty)Center(child:Container(width:220,height:220,padding:const EdgeInsets.all(10),color:Colors.white,child:Image.network('${widget.payment['qr_url']}',fit:BoxFit.contain,errorBuilder:(_,__,___)=>const Center(child:Text('QR tidak dapat dimuat'))))) else Container(width:double.infinity,padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:const Color(0xFF191B21),borderRadius:BorderRadius.circular(16)),child:const Text('QR pembayaran belum diatur admin. Hubungi admin untuk mendapatkan QR.')),const SizedBox(height:12),if('${widget.payment['name']??''}'.isNotEmpty)Text('Penerima: ${widget.payment['name']}',style:const TextStyle(fontWeight:FontWeight.w800)),if('${widget.payment['number']??''}'.isNotEmpty)Text('Nomor/Rekening: ${widget.payment['number']}',style:const TextStyle(color:Colors.white70)),const SizedBox(height:16),OutlinedButton.icon(onPressed:_sending?null:_pick,icon:const Icon(Icons.image_rounded),label:Text(_proof==null?'PILIH BUKTI TRANSFER':_proof!.name),style:OutlinedButton.styleFrom(minimumSize:const Size(double.infinity,50))),const SizedBox(height:10),FilledButton.icon(onPressed:_sending||_proof==null?null:_send,icon:_sending?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.send_rounded),label:const Text('KIRIM BUKTI'),style:FilledButton.styleFrom(minimumSize:const Size(double.infinity,50)))])));
}


class TiktokBlueTickPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const TiktokBlueTickPage({super.key, required this.sessionKey, required this.username});
  @override State<TiktokBlueTickPage> createState() => _TiktokBlueTickPageState();
}

class _TiktokBlueTickPageState extends State<TiktokBlueTickPage> {
  final ImagePicker _picker = ImagePicker();
  bool _loading=true, _busy=false;
  bool _verified=false;
  String? _verifiedUntil;
  List<Map<String,dynamic>> _plans=[];
  Map<String,dynamic> _payment={};
  List<Map<String,dynamic>> _history=[];

  Uri get _api => Uri.parse(baseUrl);

  String _rp(num n) => 'Rp${n.toInt().toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+$)'), (m)=>'${m[1]}.')}';

  @override void initState(){super.initState();_load();}

  Future<void> _load() async {
    try{
      final a=await http.get(_api.replace(path:'/api/tiktok/blue/config',queryParameters:{'key':widget.sessionKey})).timeout(const Duration(seconds:10));
      final b=await http.get(_api.replace(path:'/api/tiktok/blue/history',queryParameters:{'key':widget.sessionKey})).timeout(const Duration(seconds:10));
      final c=Map<String,dynamic>.from(jsonDecode(a.body));
      final h=Map<String,dynamic>.from(jsonDecode(b.body));
      if(mounted)setState((){
        _verified=c['verified']==true;
        _verifiedUntil=c['verified_until']?.toString();
        _plans=c['plans'] is List?List<Map<String,dynamic>>.from((c['plans'] as List).map((x)=>Map<String,dynamic>.from(x))):[];
        _payment=c['payment'] is Map?Map<String,dynamic>.from(c['payment']):{};
        _history=h['purchases'] is List?List<Map<String,dynamic>>.from((h['purchases'] as List).map((x)=>Map<String,dynamic>.from(x))):[];
        _loading=false;
      });
    }catch(e){if(mounted)setState(()=>_loading=false);}
  }

  String _expiryText(){
    if(!_verified)return 'Belum terverifikasi';
    if(_verifiedUntil==null||_verifiedUntil!.isEmpty)return 'Permanen';
    try{return 'Aktif sampai ${DateTime.parse(_verifiedUntil!).toLocal()}';}catch(_){return 'Aktif';}
  }

  Future<void> _buy(Map<String,dynamic> plan) async {
    if(_busy)return;
    setState(()=>_busy=true);
    try{
      final r=await http.post(_api.replace(path:'/api/tiktok/blue/purchase'),body:{'key':widget.sessionKey,'plan_id':'${plan['id']}'}).timeout(const Duration(seconds:10));
      final d=Map<String,dynamic>.from(jsonDecode(r.body));
      if(r.statusCode<200||r.statusCode>=300||d['valid']!=true)throw Exception(d['message']??'Gagal membuat transaksi');
      final purchase=Map<String,dynamic>.from(d['purchase']??{});
      final payment=d['payment'] is Map?Map<String,dynamic>.from(d['payment']):_payment;
      if(mounted)await showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:const Color(0xFF101116),shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(28))),builder:(ctx)=>_BlueProofSheet(sessionKey:widget.sessionKey,purchaseId:'${purchase['id']}',planName:'${purchase['plan_name']}',price:int.tryParse('${purchase['price']}')??0,payment:payment,onDone:(){Navigator.pop(ctx);_load();}));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal: ${e.toString().replaceFirst('Exception: ','')}')));}
    finally{if(mounted)setState(()=>_busy=false);}
  }

  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:Colors.black,
    appBar:AppBar(backgroundColor:Colors.black,title:const Text('Centang Biru',style:TextStyle(fontWeight:FontWeight.w900)),actions:[IconButton(onPressed:_load,icon:const Icon(Icons.refresh_rounded))]),
    body:_loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xFF17243A),Color(0xFF101116)]),border:Border.all(color:Colors.white12)),child:Row(children:[const BlueVerifiedBadge(size:42),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Centang biru',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text(_expiryText(),style:const TextStyle(color:Colors.white70))]))])),
      const SizedBox(height:16),
      const Text('Pilih paket',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
      const SizedBox(height:8),
      ..._plans.map((p)=>Padding(padding:const EdgeInsets.only(bottom:10),child:ListTile(tileColor:const Color(0xFF17191F),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),leading:const BlueVerifiedBadge(size:22),title:Text('${p['name']}',style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(_rp(num.tryParse('${p['price']}')??0)),trailing:FilledButton(onPressed:_busy?null:()=>_buy(p),child:const Text('BELI'))))),
      if('${_payment['qr_url']??''}'.isEmpty)const Padding(padding:EdgeInsets.only(top:8),child:Text('QR pembayaran belum diatur admin.',style:TextStyle(color:Colors.orangeAccent))),
      const SizedBox(height:12),
      const Text('Riwayat',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),
      if(_history.isEmpty)const Padding(padding:EdgeInsets.all(14),child:Text('Belum ada transaksi.',style:TextStyle(color:Colors.white60))) else ..._history.map((x)=>ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:4),leading:const Icon(Icons.receipt_long_rounded),title:Text('${x['plan_name']} · ${_rp(num.tryParse('${x['price']}')??0)}'),subtitle:Text('${x['id']} · ${x['status']}')))
    ]))
  );
}

class _BlueProofSheet extends StatefulWidget {
  final String sessionKey,purchaseId,planName;
  final int price;
  final Map<String,dynamic> payment;
  final VoidCallback onDone;
  const _BlueProofSheet({required this.sessionKey,required this.purchaseId,required this.planName,required this.price,required this.payment,required this.onDone});
  @override State<_BlueProofSheet> createState()=>_BlueProofSheetState();
}
class _BlueProofSheetState extends State<_BlueProofSheet>{
  XFile? _proof; bool _sending=false;
  Future<void> _pick() async{final f=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:92);if(f!=null&&mounted)setState(()=>_proof=f);}
  Future<void> _send() async{
    if(_proof==null||_sending)return;
    setState(()=>_sending=true);
    try{
      final req=http.MultipartRequest('POST',Uri.parse(baseUrl).replace(path:'/api/tiktok/blue/purchase/proof'));
      req.headers['Accept']='application/json';
      req.fields['key']=widget.sessionKey;req.fields['purchase_id']=widget.purchaseId;
      req.files.add(await http.MultipartFile.fromPath('proof',_proof!.path,filename:_proof!.name,contentType:_proofContentType(_proof!.path)));
      final r=await req.send().timeout(const Duration(seconds:45));
      final raw=await r.stream.bytesToString();
      Map<String,dynamic> d;try{d=Map<String,dynamic>.from(jsonDecode(raw) as Map);}catch(_){throw Exception('Server mengembalikan respons tidak valid (${r.statusCode})');}
      if(r.statusCode<200||r.statusCode>=300||d['valid']!=true)throw Exception(d['message']??'Bukti ditolak');
      if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Bukti centang biru terkirim. Menunggu verifikasi admin.')));widget.onDone();}
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Gagal: ${e.toString().replaceFirst('Exception: ','')}')));}
    finally{if(mounted)setState(()=>_sending=false);}
  }
  @override Widget build(BuildContext context)=>Padding(padding:EdgeInsets.fromLTRB(18,18,18,MediaQuery.of(context).viewInsets.bottom+18),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('Pembayaran Centang Biru',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('${widget.planName} · ${_rp(widget.price)}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),
    const SizedBox(height:14),if('${widget.payment['qr_url']??''}'.isNotEmpty)Center(child:Container(width:220,height:220,padding:const EdgeInsets.all(10),color:Colors.white,child:Image.network('${widget.payment['qr_url']}',fit:BoxFit.contain,errorBuilder:(_,__,___)=>const Center(child:Text('QR tidak dapat dimuat'))))) else Container(width:double.infinity,padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:const Color(0xFF191B21),borderRadius:BorderRadius.circular(16)),child:const Text('QR pembayaran belum diatur admin. Hubungi admin.')),
    const SizedBox(height:12),if('${widget.payment['name']??''}'.isNotEmpty)Text('Penerima: ${widget.payment['name']}',style:const TextStyle(fontWeight:FontWeight.w800)),if('${widget.payment['number']??''}'.isNotEmpty)Text('Nomor/Rekening: ${widget.payment['number']}',style:const TextStyle(color:Colors.white70)),
    const SizedBox(height:16),OutlinedButton.icon(onPressed:_sending?null:_pick,icon:const Icon(Icons.image_rounded),label:Text(_proof==null?'PILIH BUKTI TRANSFER':_proof!.name),style:OutlinedButton.styleFrom(minimumSize:const Size(double.infinity,50))),const SizedBox(height:10),
    FilledButton.icon(onPressed:_sending||_proof==null?null:_send,icon:_sending?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.send_rounded),label:const Text('KIRIM BUKTI'),style:FilledButton.styleFrom(minimumSize:const Size(double.infinity,50)))
  ])));
}
String _rp(num n)=>'Rp${n.toInt().toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+$)'),(m)=>'${m[1]}.')}';

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});
  @override State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}
class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _url = TextEditingController();
  bool _loading = false;
  String? _result;
  VideoPlayerController? _video;
  String? _downloadUrl;
  @override void dispose() { _url.dispose(); _video?.dispose(); super.dispose(); }
  Future<void> _download() async { final raw = _url.text.trim(); if (raw.isEmpty) return; setState(() { _loading = true; _result = null; _downloadUrl = null; _video?.dispose(); _video = null; }); try { final r = await http.get(Uri.parse('https://api.siputzx.my.id/api/d/tiktok?url=${Uri.encodeComponent(raw)}')).timeout(const Duration(seconds: 30)); final d = jsonDecode(r.body); final urls = d['data']?['urls']; if (d['status'] == true && urls is List && urls.isNotEmpty) { _downloadUrl = urls.first.toString(); final c = VideoPlayerController.networkUrl(Uri.parse(_downloadUrl!)); _video = c; await c.initialize(); await c.setLooping(true); await c.play(); if (mounted) setState(() => _result = 'Video siap diputar'); } else if (mounted) setState(() => _result = 'Video tidak ditemukan'); } catch (_) { if (mounted) setState(() => _result = 'Gagal mengambil video'); } finally { if (mounted) setState(() => _loading = false); } }
  Future<void> _save() async { if (_downloadUrl == null) return; try { final r = await http.get(Uri.parse(_downloadUrl!)).timeout(const Duration(minutes: 3)); final dir = await getTemporaryDirectory(); final f = File('${dir.path}/dey_tiktok_download.mp4'); await f.writeAsBytes(r.bodyBytes, flush: true); await Share.shareXFiles([XFile(f.path)], text: 'DEY TikTok'); } catch (_) { if (mounted) setState(() => _result = 'Download gagal'); } }
  @override Widget build(BuildContext context) => Scaffold(backgroundColor: Colors.black, appBar: AppBar(title: const Text('TikTok Downloader'), backgroundColor: Colors.black), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextField(controller: _url, style: const TextStyle(color: Colors.white), decoration: InputDecoration(hintText: 'Tempel link TikTok', suffixIcon: IconButton(onPressed: _url.clear, icon: const Icon(Icons.clear)))), const SizedBox(height: 12), Row(children: [Expanded(child: FilledButton.icon(onPressed: _loading ? null : _download, icon: const Icon(Icons.search), label: const Text('CEK VIDEO'))), const SizedBox(width: 8), if (_downloadUrl != null) FilledButton.icon(onPressed: _save, icon: const Icon(Icons.download), label: const Text('SIMPAN'))]), const SizedBox(height: 18), if (_loading) const CircularProgressIndicator(), if (_result != null) Padding(padding: const EdgeInsets.all(8), child: Text(_result!)), if (_video != null && _video!.value.isInitialized) Expanded(child: AspectRatio(aspectRatio: _video!.value.aspectRatio, child: VideoPlayer(_video!)))])));
}
