import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

import 'music_player_service.dart';
import 'theme_provider.dart';

/// Global music layer. Dynamic Island di atas (fixed), tidak bisa digeser.
class MusicOverlayGate {
  static final ValueNotifier<bool> enabled = ValueNotifier<bool>(false);

  static void show() => enabled.value = true;
  static void hide() => enabled.value = false;
}

/// Opens the music search/results sheet from anywhere (e.g. the music page).
Future<void> showSpotifyResultsPanel(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withOpacity(.70),
    builder: (_) => const _MusicPanel(),
  );
}

class GlobalMusicOverlay extends StatefulWidget {
  final Widget child;
  const GlobalMusicOverlay({super.key, required this.child});

  @override
  State<GlobalMusicOverlay> createState() => _GlobalMusicOverlayState();
}

class _GlobalMusicOverlayState extends State<GlobalMusicOverlay>
    with SingleTickerProviderStateMixin {
  final MusicPlayerController controller = MusicPlayerController.instance;

  /// Expanded Dynamic Island (controls visible).
  bool _expanded = false;

  late final AnimationController _eqPulse;

  @override
  void initState() {
    super.initState();
    controller.addListener(_refresh);
    MusicOverlayGate.enabled.addListener(_refresh);
    _eqPulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    controller.removeListener(_refresh);
    MusicOverlayGate.enabled.removeListener(_refresh);
    _eqPulse.dispose();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _openPlayer() async {
    if (!mounted) return;
    setState(() => _expanded = false);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(.70),
      builder: (_) => const _MusicPanel(),
    );
  }

  void _toggleExpand() {
    setState(() => _expanded = !_expanded);
  }

  @override
  Widget build(BuildContext context) {
    if (!MusicOverlayGate.enabled.value) return widget.child;
    final current = controller.current;

    return Stack(
      fit: StackFit.expand,
      clipBehavior: Clip.none,
      children: <Widget>[
        widget.child,
        // Dynamic Island — fixed di atas, tidak bisa digeser
        if (current != null)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              bottom: false,
              child: Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: _DynamicIsland(
                    controller: controller,
                    expanded: _expanded,
                    eqPulse: _eqPulse,
                    onTap: _toggleExpand,
                    onOpenPanel: _openPlayer,
                    onCollapse: () => setState(() => _expanded = false),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

// ─────────────────────────────────────────────
//  DYNAMIC ISLAND (iPhone-style, fixed top)
// ─────────────────────────────────────────────
class _DynamicIsland extends StatelessWidget {
  final MusicPlayerController controller;
  final bool expanded;
  final AnimationController eqPulse;
  final VoidCallback onTap;
  final VoidCallback onOpenPanel;
  final VoidCallback onCollapse;

  const _DynamicIsland({
    required this.controller,
    required this.expanded,
    required this.eqPulse,
    required this.onTap,
    required this.onOpenPanel,
    required this.onCollapse,
  });

  @override
  Widget build(BuildContext context) {
    final track = controller.current!;
    final screenW = MediaQuery.sizeOf(context).width;

    // Collapsed slightly wider so play button fits; expanded = full controls
    final targetWidth = expanded
        ? math.min(screenW - 28, 360.0)
        : math.min(screenW * 0.62, 248.0);
    final targetHeight = expanded ? 72.0 : 38.0;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
      width: targetWidth,
      height: targetHeight,
      decoration: BoxDecoration(
        color: const Color(0xFF000000),
        borderRadius: BorderRadius.circular(expanded ? 28 : 22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
          if (controller.playing)
            BoxShadow(
              color: const Color(0xFF1DB954).withOpacity(0.22),
              blurRadius: 14,
              spreadRadius: 0.5,
            ),
        ],
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
          width: 0.5,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(expanded ? 28 : 22),
        child: expanded
            ? _ExpandedIsland(
                track: track,
                controller: controller,
                onOpenPanel: onOpenPanel,
                onCollapse: onCollapse,
                onBodyTap: onTap,
              )
            : _CollapsedIsland(
                track: track,
                controller: controller,
                eqPulse: eqPulse,
                onBodyTap: onTap,
                onLongPress: onOpenPanel,
              ),
      ),
    );
  }
}

class _CollapsedIsland extends StatelessWidget {
  final MusicTrack track;
  final MusicPlayerController controller;
  final AnimationController eqPulse;
  final VoidCallback onBodyTap;
  final VoidCallback onLongPress;

  const _CollapsedIsland({
    required this.track,
    required this.controller,
    required this.eqPulse,
    required this.onBodyTap,
    required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8, right: 4),
      child: Row(
        children: [
          // Area kiri (artwork + judul) → expand / panel
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: onBodyTap,
              onLongPress: onLongPress,
              child: Row(
                children: [
                  _Artwork(url: track.artwork, size: 24),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.2,
                      ),
                    ),
                  ),
                  if (controller.playing) ...[
                    const SizedBox(width: 4),
                    _MiniEq(pulse: eqPulse),
                  ],
                ],
              ),
            ),
          ),
          // Tombol Play / Pause — terpisah, tidak trigger expand
          Material(
            color: Colors.transparent,
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: controller.loading ? null : () => controller.toggle(),
              child: SizedBox(
                width: 34,
                height: 34,
                child: Center(
                  child: controller.loading
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 1.8,
                            color: Color(0xFF1DB954),
                          ),
                        )
                      : Icon(
                          controller.playing
                              ? Icons.pause_rounded
                              : Icons.play_arrow_rounded,
                          color: Colors.white,
                          size: 22,
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExpandedIsland extends StatelessWidget {
  final MusicTrack track;
  final MusicPlayerController controller;
  final VoidCallback onOpenPanel;
  final VoidCallback onCollapse;
  final VoidCallback onBodyTap;

  const _ExpandedIsland({
    required this.track,
    required this.controller,
    required this.onOpenPanel,
    required this.onCollapse,
    required this.onBodyTap,
  });

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 6, 8),
      child: Column(
        children: [
          Row(
            children: [
              // Artwork + text → collapse on tap
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: onBodyTap,
                  onLongPress: onOpenPanel,
                  child: Row(
                    children: [
                      _Artwork(url: track.artwork, size: 44),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              track.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              track.artist,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white60,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Tombol Play / Pause (hijau)
              Material(
                color: const Color(0xFF1DB954),
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: controller.loading ? null : () => controller.toggle(),
                  child: SizedBox(
                    width: 40,
                    height: 40,
                    child: Center(
                      child: controller.loading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.black,
                              ),
                            )
                          : Icon(
                              controller.playing
                                  ? Icons.pause_rounded
                                  : Icons.play_arrow_rounded,
                              color: Colors.black,
                              size: 26,
                            ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 4),
              // Buka panel musik
              Material(
                color: Colors.transparent,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: onOpenPanel,
                  child: const SizedBox(
                    width: 32,
                    height: 32,
                    child: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: Colors.white54,
                      size: 22,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(right: 6),
            child: Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(2),
                    child: LinearProgressIndicator(
                      minHeight: 2.5,
                      value: controller.progress.clamp(0.0, 1.0),
                      backgroundColor: Colors.white12,
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        Color(0xFF1DB954),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '${_fmt(controller.position)} / ${_fmt(controller.duration)}',
                  style: const TextStyle(
                    color: Colors.white38,
                    fontSize: 9.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Mini equalizer bars for collapsed island while playing.
class _MiniEq extends StatelessWidget {
  final AnimationController pulse;
  const _MiniEq({required this.pulse});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: pulse,
      builder: (context, _) {
        final t = pulse.value;
        return SizedBox(
          width: 14,
          height: 14,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _bar(4 + 6 * t),
              _bar(10 - 4 * t),
              _bar(6 + 5 * (1 - t)),
            ],
          ),
        );
      },
    );
  }

  Widget _bar(double h) {
    return Container(
      width: 2.5,
      height: h.clamp(3.0, 12.0),
      decoration: BoxDecoration(
        color: const Color(0xFF1DB954),
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ARTWORK
// ─────────────────────────────────────────────
class _Artwork extends StatelessWidget {
  final String? url;
  final double size;
  const _Artwork({required this.url, required this.size});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;

    final fallback = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: primary.withOpacity(.14),
        border: Border.all(color: primary.withOpacity(.30), width: 1),
      ),
      child: Icon(Icons.music_note_rounded, color: primary, size: size * .46),
    );

    final raw = (url ?? '').trim();
    if (raw.isEmpty) {
      return ClipOval(
        child: SizedBox(width: size, height: size, child: fallback),
      );
    }

    Widget img;
    if (raw.startsWith('http')) {
      img = Image.network(
        raw,
        width: size,
        height: size,
        fit: BoxFit.cover,
        filterQuality: FilterQuality.medium,
        errorBuilder: (_, __, ___) => fallback,
        loadingBuilder: (context, child, progress) =>
            progress == null ? child : fallback,
      );
    } else {
      img = Image.asset(
        raw,
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback,
      );
    }

    return ClipOval(
      child: SizedBox(width: size, height: size, child: img),
    );
  }
}

// ─────────────────────────────────────────────
//  PANEL MUSIK (bottom sheet)
// ─────────────────────────────────────────────
class _MusicPanel extends StatefulWidget {
  const _MusicPanel();

  @override
  State<_MusicPanel> createState() => _MusicPanelState();
}

class _MusicPanelState extends State<_MusicPanel> {
  final MusicPlayerController c = MusicPlayerController.instance;
  late final TextEditingController search;
  late final FocusNode searchFocus;

  @override
  void initState() {
    super.initState();
    search = TextEditingController(text: c.query);
    searchFocus = FocusNode();
    c.addListener(_refresh);
  }

  @override
  void dispose() {
    c.removeListener(_refresh);
    search.dispose();
    searchFocus.dispose();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    final height = MediaQuery.sizeOf(context).height;
    final panelHeight = math.min(height * .90, math.max(520.0, height * .84));

    return SafeArea(
      top: false,
      child: Container(
        height: panelHeight,
        decoration: BoxDecoration(
          color: ThemeProvider.background,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          border: Border.all(color: primary.withOpacity(.20)),
        ),
        child: Column(
          children: <Widget>[
            const SizedBox(height: 10),
            Container(
              width: 46,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 15, 12, 12),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: primary.withOpacity(.12),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.library_music_rounded, color: primary),
                  ),
                  const SizedBox(width: 11),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'DEY MUSIC',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Cari lagu lewat YouTube',
                          style: TextStyle(color: Colors.white54, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded, color: Colors.white54),
                  ),
                ],
              ),
            ),

            if (c.current != null) _NowPlaying(c: c),

            Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 6),
              child: Row(
                children: <Widget>[
                  Icon(Icons.search_rounded, color: primary, size: 16),
                  const SizedBox(width: 6),
                  Text(
                    'CARI LAGU',
                    style: TextStyle(
                      color: primary,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: search,
                focusNode: searchFocus,
                onChanged: c.scheduleSearch,
                onSubmitted: c.search,
                textInputAction: TextInputAction.search,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Cari lagu, artis...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: c.searching
                      ? const Padding(
                          padding: EdgeInsets.all(13),
                          child: SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      : IconButton(
                          onPressed: () => c.search(search.text),
                          icon: const Icon(Icons.arrow_forward_rounded),
                        ),
                ),
              ),
            ),

            if (c.error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 3),
                child: Row(
                  children: <Widget>[
                    const Icon(
                      Icons.info_outline_rounded,
                      color: Colors.orangeAccent,
                      size: 15,
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        c.error!,
                        style: const TextStyle(
                          color: Colors.orangeAccent,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            Expanded(
              child: c.results.isEmpty && !c.searching
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Ketik judul lagu atau nama artis lalu tekan cari.\nLagu akan diputar dari YouTube audio.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ),
                    )
                  : ListView.separated(
                      keyboardDismissBehavior:
                          ScrollViewKeyboardDismissBehavior.onDrag,
                      padding: const EdgeInsets.fromLTRB(14, 9, 14, 30),
                      itemCount: c.results.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 7),
                      itemBuilder: (_, index) =>
                          _TrackTile(track: c.results[index], c: c),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NowPlaying extends StatelessWidget {
  final MusicPlayerController c;
  const _NowPlaying({required this.c});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    final track = c.current!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: primary.withOpacity(.08),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: primary.withOpacity(.25)),
        ),
        child: Column(
          children: [
            Row(
              children: [
                _Artwork(url: track.artwork, size: 56),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        track.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        track.artist,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${_fmt(c.position)} / ${_fmt(c.duration)}',
                        style: const TextStyle(
                          color: Colors.white38,
                          fontSize: 9,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: c.toggle,
                  icon: Icon(
                    c.playing
                        ? Icons.pause_circle_filled_rounded
                        : Icons.play_circle_fill_rounded,
                    color: primary,
                    size: 40,
                  ),
                ),
                IconButton(
                  onPressed: c.stop,
                  icon: const Icon(
                    Icons.stop_circle_outlined,
                    color: Colors.white38,
                    size: 28,
                  ),
                ),
              ],
            ),
            Slider(
              value: c.progress.clamp(0.0, 1.0),
              onChanged: c.seek,
              activeColor: primary,
              inactiveColor: Colors.white12,
            ),
          ],
        ),
      ),
    );
  }
}

class _TrackTile extends StatelessWidget {
  final MusicTrack track;
  final MusicPlayerController c;
  const _TrackTile({required this.track, required this.c});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    final active = c.current?.key == track.key;
    return InkWell(
      borderRadius: BorderRadius.circular(17),
      onTap: () =>
          active && c.current?.hasPreview == true ? c.toggle() : c.play(track),
      child: Container(
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: active ? primary.withOpacity(.09) : ThemeProvider.card,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(
            color: active
                ? primary.withOpacity(.35)
                : Colors.white.withOpacity(.06),
          ),
        ),
        child: Row(
          children: <Widget>[
            _Artwork(url: track.artwork, size: 54),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    track.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white54, fontSize: 10.5),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    track.durationLabel != null
                        ? 'YOUTUBE • ${track.durationLabel}'
                        : 'YOUTUBE • ${_fmt(Duration(milliseconds: track.durationMs ?? 0))}',
                    style: TextStyle(
                      color: primary.withOpacity(.85),
                      fontSize: 8.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            c.loading && active
                ? SizedBox(
                    width: 29,
                    height: 29,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: primary,
                    ),
                  )
                : Icon(
                    active && c.playing
                        ? Icons.pause_circle_filled_rounded
                        : Icons.play_circle_fill_rounded,
                    color: primary,
                    size: 31,
                  ),
          ],
        ),
      ),
    );
  }
}

String _fmt(Duration duration) {
  final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}
