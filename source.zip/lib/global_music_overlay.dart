import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';

import 'music_player_service.dart';
import 'theme_provider.dart';

/// Global music layer. It sits above the current page, so the player follows
/// the user through dashboard/tools/profile/chat without replacing navigation.
class MusicOverlayGate {
  static final ValueNotifier<bool> enabled = ValueNotifier<bool>(false);

  static void show() => enabled.value = true;
  static void hide() => enabled.value = false;
}

/// Opens the Spotify search/results sheet from anywhere (e.g. the music page).
Future<void> showSpotifyResultsPanel(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withOpacity(.70),
    builder: (_) => const _MusicPanel(),
  );
}

class GlobalMusicOverlay extends StatefulWidget {
  final Widget child;
  const GlobalMusicOverlay({super.key, required this.child});

  @override
  State<GlobalMusicOverlay> createState() => _GlobalMusicOverlayState();
}

class _GlobalMusicOverlayState extends State<GlobalMusicOverlay> {
  final MusicPlayerController controller = MusicPlayerController.instance;

  Offset? _launcherPosition;
  Offset? _playerPosition;
  Offset? _dragOrigin;
  Offset? _dragStart;
  bool _compact = false;
  bool _dragging = false;

  @override
  void initState() {
    super.initState();
    controller.addListener(_refresh);
    MusicOverlayGate.enabled.addListener(_refresh);
  }

  @override
  void dispose() {
    controller.removeListener(_refresh);
    MusicOverlayGate.enabled.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _openPlayer() async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(.70),
      builder: (_) => const _MusicPanel(),
    );
  }

  Offset _clampOffset(
    Offset value,
    Size screen,
    Size child,
    double topMin,
    double bottomPadding,
  ) {
    final maxX = math.max(10.0, screen.width - child.width - 10.0);
    final maxY = math.max(topMin, screen.height - child.height - bottomPadding - 10.0);
    return Offset(
      value.dx.clamp(10.0, maxX).toDouble(),
      value.dy.clamp(topMin, maxY).toDouble(),
    );
  }

  void _startDrag(Offset globalPosition, Offset currentPosition) {
    _dragOrigin = globalPosition;
    _dragStart = currentPosition;
    if (mounted) setState(() => _dragging = true);
  }

  void _updateDrag(
    Offset globalPosition,
    Size screen,
    Size child,
    double topMin,
    double bottomPadding, {
    required bool launcher,
  }) {
    final origin = _dragOrigin;
    final start = _dragStart;
    if (origin == null || start == null) return;
    final delta = globalPosition - origin;
    final next = _clampOffset(start + delta, screen, child, topMin, bottomPadding);
    setState(() {
      if (launcher) {
        _launcherPosition = next;
      } else {
        _playerPosition = next;
      }
    });
  }

  void _endDrag(
    Size screen,
    Size child,
    double topMin,
    double bottomPadding, {
    required bool launcher,
  }) {
    final current = launcher ? _launcherPosition : _playerPosition;
    _dragOrigin = null;
    _dragStart = null;

    if (current == null) {
      if (mounted) setState(() => _dragging = false);
      return;
    }

    final maxX = math.max(10.0, screen.width - child.width - 10.0);
    final targetX = current.dx < (screen.width - child.width) / 2 ? 10.0 : maxX;
    final snapped = _clampOffset(
      Offset(targetX, current.dy),
      screen,
      child,
      topMin,
      bottomPadding,
    );

    setState(() {
      if (launcher) {
        _launcherPosition = snapped;
      } else {
        _playerPosition = snapped;
      }
      _dragging = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!MusicOverlayGate.enabled.value) return widget.child;
    final current = controller.current;
    return Stack(
      fit: StackFit.expand,
      clipBehavior: Clip.none,
      children: <Widget>[
        widget.child,
        // No round launcher bubble any more: music is opened from the Spotify
        // button in the dashboard header. The mini player only appears while
        // a track is playing.
        if (current != null) _buildFloating(context),
      ],
    );
  }

  Widget _positioned({
    required Widget child,
    required Offset position,
    required Size size,
    required bool launcher,
    required Size screen,
    required double safeBottom,
  }) {
    final topMin = 72.0;
    final bottomPadding = safeBottom + 8.0;
    final clamped = _clampOffset(position, screen, size, topMin, bottomPadding);

    if (_dragging) {
      return Positioned(left: clamped.dx, top: clamped.dy, child: child);
    }

    return AnimatedPositioned(
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOutCubic,
      left: clamped.dx,
      top: clamped.dy,
      child: child,
    );
  }

  Widget _buildFloating(BuildContext context) {
    final screen = MediaQuery.sizeOf(context);
    final safeBottom = MediaQuery.paddingOf(context).bottom;
    final compactSize = const Size(66, 66);
    final miniWidth = math.min(360.0, math.max(160.0, screen.width - 20.0));
    final childSize = _compact ? compactSize : Size(miniWidth, 74);
    final defaultPosition = Offset(
      10,
      screen.height - childSize.height - safeBottom - 88,
    );
    final position = _clampOffset(
      _playerPosition ?? defaultPosition,
      screen,
      childSize,
      72,
      safeBottom + 8,
    );

    final floating = GestureDetector(
      behavior: HitTestBehavior.translucent,
      onPanStart: (details) => _startDrag(details.globalPosition, position),
      onPanUpdate: (details) => _updateDrag(
        details.globalPosition,
        screen,
        childSize,
        72,
        safeBottom + 8,
        launcher: false,
      ),
      onPanEnd: (_) => _endDrag(
        screen,
        childSize,
        72,
        safeBottom + 8,
        launcher: false,
      ),
      child: _compact
          ? _CompactBubble(
              controller: controller,
              onOpen: _openPlayer,
              onExpand: () => setState(() => _compact = false),
            )
          : _MiniPlayer(
              controller: controller,
              width: miniWidth,
              onOpen: _openPlayer,
              onCompact: () => setState(() => _compact = true),
            ),
    );

    return _positioned(
      child: floating,
      position: position,
      size: childSize,
      launcher: false,
      screen: screen,
      safeBottom: safeBottom,
    );
  }
}

// ─────────────────────────────────────────────
//  MINI PLAYER (bentuk kapsul, tetap)
// ─────────────────────────────────────────────
class _MiniPlayer extends StatelessWidget {
  final MusicPlayerController controller;
  final double width;
  final VoidCallback onOpen;
  final VoidCallback onCompact;

  const _MiniPlayer({
    required this.controller,
    required this.width,
    required this.onOpen,
    required this.onCompact,
  });

  @override
  Widget build(BuildContext context) {
    final track = controller.current!;
    final primary = ThemeProvider.currentPrimary;
    return Material(
      color: Colors.transparent,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(37),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
          child: Container(
            width: width,
            height: 74,
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              color: const Color(0xE914141A),
              borderRadius: BorderRadius.circular(37),
              border: Border.all(color: primary.withOpacity(.36)),
              boxShadow: <BoxShadow>[
                BoxShadow(color: primary.withOpacity(.10), blurRadius: 28, offset: const Offset(0, 9)),
                BoxShadow(color: Colors.black.withOpacity(.34), blurRadius: 26, offset: const Offset(0, 10)),
              ],
            ),
            child: Row(
              children: <Widget>[
                _Artwork(url: track.artwork, size: 60),
                const SizedBox(width: 10),
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(13),
                    onTap: onOpen,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13),
                          ),
                          const SizedBox(height: 3),
                          Row(
                            children: <Widget>[
                              Icon(Icons.music_note_rounded, color: primary, size: 12),
                              const SizedBox(width: 3),
                              Expanded(
                                child: Text(
                                  track.artist,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white60, fontSize: 10.5),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 5),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: LinearProgressIndicator(
                              minHeight: 2,
                              value: controller.progress,
                              backgroundColor: Colors.white10,
                              valueColor: AlwaysStoppedAnimation<Color>(primary),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: controller.playing ? 'Pause' : 'Putar',
                  onPressed: controller.toggle,
                  icon: Icon(
                    controller.playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
                    color: primary,
                    size: 32,
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Kecilkan',
                  onPressed: onCompact,
                  icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white54, size: 23),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  BUBBLE KECIL (bulat)
// ─────────────────────────────────────────────
class _CompactBubble extends StatelessWidget {
  final MusicPlayerController controller;
  final VoidCallback onOpen;
  final VoidCallback onExpand;

  const _CompactBubble({required this.controller, required this.onOpen, required this.onExpand});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    return Container(
      width: 66,
      height: 66,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: const Color(0xF216161A),
        border: Border.all(color: primary.withOpacity(.55), width: 2),
        boxShadow: <BoxShadow>[
          BoxShadow(color: primary.withOpacity(.16), blurRadius: 22),
          BoxShadow(color: Colors.black.withOpacity(.28), blurRadius: 18, offset: const Offset(0, 7)),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          ClipOval(child: _Artwork(url: controller.current!.artwork, size: 54)),
          Material(
            color: Colors.transparent,
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: controller.toggle,
              child: Container(
                width: 31,
                height: 31,
                decoration: const BoxDecoration(color: Color(0xD9111116), shape: BoxShape.circle),
                child: Icon(controller.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: primary, size: 19),
              ),
            ),
          ),
          Positioned(
            right: -1,
            top: -1,
            child: Material(
              color: const Color(0xEE111116),
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: onOpen,
                child: Padding(
                  padding: const EdgeInsets.all(5),
                  child: Icon(Icons.open_in_full_rounded, color: primary, size: 12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ARTWORK — BULAT & NULLABLE
// ─────────────────────────────────────────────
class _Artwork extends StatelessWidget {
  final String? url;
  final double size;
  const _Artwork({required this.url, required this.size});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;

    final fallback = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: primary.withOpacity(.14),
        border: Border.all(color: primary.withOpacity(.30), width: 1),
      ),
      child: Icon(Icons.music_note_rounded, color: primary, size: size * .46),
    );

    final raw = (url ?? '').trim();
    if (raw.isEmpty) {
      return ClipOval(
        child: SizedBox(width: size, height: size, child: fallback),
      );
    }

    Widget img;
    if (raw.startsWith('asset:')) {
      img = fallback;
    } else if (raw.startsWith('http')) {
      img = Image.network(
        raw,
        width: size,
        height: size,
        fit: BoxFit.cover,
        filterQuality: FilterQuality.medium,
        errorBuilder: (_, __, ___) => fallback,
        loadingBuilder: (context, child, progress) =>
            progress == null ? child : fallback,
      );
    } else {
      img = Image.asset(
        raw,
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => fallback,
      );
    }

    return ClipOval(
      child: SizedBox(width: size, height: size, child: img),
    );
  }
}

// ─────────────────────────────────────────────
//  PANEL MUSIK (bottom sheet)
// ─────────────────────────────────────────────
class _MusicPanel extends StatefulWidget {
  const _MusicPanel();

  @override
  State<_MusicPanel> createState() => _MusicPanelState();
}

class _MusicPanelState extends State<_MusicPanel> {
  final MusicPlayerController c = MusicPlayerController.instance;
  late final TextEditingController search;
  late final FocusNode searchFocus;

  @override
  void initState() {
    super.initState();
    search = TextEditingController(text: c.query);
    searchFocus = FocusNode();
    c.addListener(_refresh);
  }

  @override
  void dispose() {
    c.removeListener(_refresh);
    search.dispose();
    searchFocus.dispose();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    final height = MediaQuery.sizeOf(context).height;
    final panelHeight = math.min(height * .90, math.max(520.0, height * .84));

    return SafeArea(
      top: false,
      child: Container(
        height: panelHeight,
        decoration: BoxDecoration(
          color: ThemeProvider.background,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          border: Border.all(color: primary.withOpacity(.20)),
          boxShadow: <BoxShadow>[BoxShadow(color: Colors.black.withOpacity(.38), blurRadius: 30, offset: const Offset(0, -8))],
        ),
        child: Column(
          children: <Widget>[
            const SizedBox(height: 10),
            Container(width: 46, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10))),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 15, 12, 12),
              child: Row(
                children: <Widget>[
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(color: primary.withOpacity(.12), shape: BoxShape.circle),
                    child: Icon(Icons.library_music_rounded, color: primary),
                  ),
                  const SizedBox(width: 11),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text('DEY MUSIC', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1)),
                        SizedBox(height: 2),
                        Text('Cari lagu lewat Spotify', style: TextStyle(color: Colors.white54, fontSize: 10)),
                      ],
                    ),
                  ),
                  IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded, color: Colors.white54)),
                ],
              ),
            ),

            // ─── NOW PLAYING ───
            if (c.current != null) _NowPlaying(c: c),

            // ─── DIVIDER ───
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 6),
              child: Row(
                children: <Widget>[
                  Icon(Icons.search_rounded, color: primary, size: 16),
                  const SizedBox(width: 6),
                  Text(
                    'CARI DI SPOTIFY',
                    style: TextStyle(
                      color: primary,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),

            // ─── SEARCH BAR ───
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: search,
                focusNode: searchFocus,
                onChanged: c.scheduleSearch,
                onSubmitted: c.search,
                textInputAction: TextInputAction.search,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Cari lagu, artis...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: c.searching
                      ? const Padding(padding: EdgeInsets.all(13), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
                      : IconButton(onPressed: () => c.search(search.text), icon: const Icon(Icons.arrow_forward_rounded)),
                ),
              ),
            ),

            if (c.error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 3),
                child: Row(
                  children: <Widget>[
                    const Icon(Icons.info_outline_rounded, color: Colors.orangeAccent, size: 15),
                    const SizedBox(width: 7),
                    Expanded(child: Text(c.error!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 11))),
                  ],
                ),
              ),

            Expanded(
              child: c.results.isEmpty && !c.searching
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Ketik judul lagu atau nama artis lalu tekan cari.\nLagu tanpa preview akan dibuka di Spotify.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white54, fontSize: 12),
                        ),
                      ),
                    )
                  : ListView.separated(
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      padding: const EdgeInsets.fromLTRB(14, 9, 14, 30),
                      itemCount: c.results.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 7),
                      itemBuilder: (_, index) => _TrackTile(track: c.results[index], c: c),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NowPlaying extends StatelessWidget {
  final MusicPlayerController c;
  const _NowPlaying({required this.c});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 2),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 2),
        decoration: BoxDecoration(
          color: primary.withOpacity(.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: primary.withOpacity(.16)),
        ),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                _Artwork(url: c.current!.artwork, size: 42),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(c.current!.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
                      Text(c.current!.artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 10)),
                    ],
                  ),
                ),
                Text('${_fmt(c.position)} / ${_fmt(c.duration)}', style: const TextStyle(color: Colors.white38, fontSize: 9)),
              ],
            ),
            Slider(value: c.progress, onChanged: c.seek, activeColor: primary, inactiveColor: Colors.white12),
          ],
        ),
      ),
    );
  }
}

class _TrackTile extends StatelessWidget {
  final MusicTrack track;
  final MusicPlayerController c;
  const _TrackTile({required this.track, required this.c});

  @override
  Widget build(BuildContext context) {
    final primary = ThemeProvider.currentPrimary;
    final active = c.current?.key == track.key;
    return InkWell(
      borderRadius: BorderRadius.circular(17),
      onTap: () => active && track.hasPreview ? c.toggle() : c.play(track),
      child: Container(
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: active ? primary.withOpacity(.09) : ThemeProvider.card,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: active ? primary.withOpacity(.35) : Colors.white.withOpacity(.06)),
        ),
        child: Row(
          children: <Widget>[
            _Artwork(url: track.artwork, size: 54),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(track.artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 10.5)),
                  const SizedBox(height: 4),
                  Text(track.hasPreview ? 'PREVIEW • ${_fmt(Duration(milliseconds: track.durationMs ?? 0))}' : 'BUKA DI SPOTIFY • ${_fmt(Duration(milliseconds: track.durationMs ?? 0))}', style: TextStyle(color: primary.withOpacity(.85), fontSize: 8.5, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(width: 6),
            c.loading && active
                ? SizedBox(width: 29, height: 29, child: CircularProgressIndicator(strokeWidth: 2.5, color: primary))
                : Icon(!track.hasPreview ? Icons.open_in_new_rounded : (active && c.playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded), color: primary, size: 31),
          ],
        ),
      ),
    );
  }
}

String _fmt(Duration duration) {
  final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}