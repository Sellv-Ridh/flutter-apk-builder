import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'app_background.dart';

class GlobalAnimeAtmosphere extends StatefulWidget {
  final Widget child;
  final String presetId;
  const GlobalAnimeAtmosphere({super.key, required this.child, required this.presetId});

  @override
  State<GlobalAnimeAtmosphere> createState() => _GlobalAnimeAtmosphereState();
}

class _GlobalAnimeAtmosphereState extends State<GlobalAnimeAtmosphere>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final preset = DragonBackgroundPresets.get(widget.presetId);
    if (!preset.anime) return widget.child;
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        IgnorePointer(
          child: RepaintBoundary(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, _) => CustomPaint(
                painter: _GlobalAtmospherePainter(
                  progress: _controller.value,
                  primary: preset.themePrimary ?? preset.glow,
                  secondary: preset.themeSecondary ?? preset.b,
                  seed: widget.presetId,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _GlobalAtmospherePainter extends CustomPainter {
  final double progress;
  final Color primary;
  final Color secondary;
  final String seed;
  _GlobalAtmospherePainter({required this.progress, required this.primary, required this.secondary, required this.seed});

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final t = progress * math.pi * 2;
    final glow = Paint()..maskFilter = const MaskFilter.blur(BlurStyle.normal, 42);
    final centers = <Offset>[
      Offset(size.width * (.16 + .06 * math.sin(t)), size.height * (.22 + .04 * math.cos(t * .7))),
      Offset(size.width * (.84 + .05 * math.cos(t * .8)), size.height * (.56 + .06 * math.sin(t))),
    ];
    final colors = <Color>[primary, secondary];
    for (var i = 0; i < centers.length; i++) {
      glow.color = colors[i].withOpacity(.035 + .015 * ((math.sin(t + i) + 1) / 2));
      canvas.drawCircle(centers[i], size.shortestSide * (.28 + i * .035), glow);
    }
    final r = math.Random(seed.codeUnits.fold<int>(11, (a, b) => a * 33 + b));
    final dot = Paint();
    for (var i = 0; i < 26; i++) {
      final x = r.nextDouble() * size.width + math.sin(t * (.4 + i % 3) + i) * 12;
      final y = (r.nextDouble() * size.height + progress * size.height * (.15 + (i % 4) * .04)) % size.height;
      dot.color = Color.lerp(Colors.white, colors[i % 2], .55)!.withOpacity(.025 + (i % 4) * .009);
      canvas.drawCircle(Offset(x, y), .6 + (i % 3) * .5, dot);
    }
    final sweepX = (progress * (size.width * 1.8)) - size.width * .4;
    final rect = Rect.fromLTWH(sweepX - size.width * .18, 0, size.width * .36, size.height);
    final sweep = Paint()..shader = LinearGradient(
      colors: [Colors.transparent, primary.withOpacity(.035), Colors.transparent],
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
    ).createShader(rect);
    canvas.drawRect(rect, sweep);
  }

  @override
  bool shouldRepaint(covariant _GlobalAtmospherePainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.primary != primary || oldDelegate.secondary != secondary || oldDelegate.seed != seed;
}
