import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

/// Weather feature: a compact chip for the dashboard and a full detail page.
/// Data comes from Open-Meteo (no API key). Location falls back to Tangerang,
/// the same fallback the prayer-time code uses.

const Color _wxTop = Color(0xFF0B2F3A);
const Color _wxBottom = Color(0xFF0A0F17);
const Color _wxCyan = Color(0xFF13A9C7);

class WeatherHour {
  final String time;
  final double temp;
  final int code;
  const WeatherHour(this.time, this.temp, this.code);
}

class WeatherDay {
  final DateTime date;
  final double tempMax;
  final double tempMin;
  final int code;
  const WeatherDay(this.date, this.tempMax, this.tempMin, this.code);
}

class WeatherData {
  final double temp;
  final double humidity;
  final double windSpeed;
  final double windDir;
  final int code;
  final bool isDay;
  final double? visibilityM;
  final List<WeatherHour> hours;
  final List<WeatherDay> days;

  const WeatherData({
    required this.temp,
    required this.humidity,
    required this.windSpeed,
    required this.windDir,
    required this.code,
    required this.isDay,
    required this.visibilityM,
    required this.hours,
    required this.days,
  });
}

class WeatherService {
  static const double _fallbackLat = -6.1783;
  static const double _fallbackLon = 106.6319;

  static Future<WeatherData> fetch() async {
    final loc = await _position();
    final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': loc.lat.toString(),
      'longitude': loc.lon.toString(),
      'current':
          'temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,weather_code,is_day',
      'hourly': 'temperature_2m,weather_code,visibility',
      'daily': 'weather_code,temperature_2m_max,temperature_2m_min',
      'timezone': 'auto',
      'forecast_days': '7',
      'wind_speed_unit': 'kmh',
    });
    final r = await http.get(uri).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) {
      throw Exception('Gagal memuat cuaca (HTTP ${r.statusCode})');
    }
    final j = jsonDecode(r.body) as Map<String, dynamic>;

    double d(Object? v) => (v as num?)?.toDouble() ?? 0;

    final cur = j['current'] as Map<String, dynamic>;
    final hourly = j['hourly'] as Map<String, dynamic>;
    final times = List<String>.from(hourly['time'] as List);
    final temps = (hourly['temperature_2m'] as List);
    final codes = (hourly['weather_code'] as List);
    final vis = (hourly['visibility'] as List?) ?? const [];

    var idx = times.indexOf(cur['time'] as String);
    if (idx < 0) idx = 0;

    final hours = <WeatherHour>[];
    for (var k = 0; k < 4; k++) {
      final i = idx + k * 3;
      if (i >= times.length) break;
      hours.add(WeatherHour(
        times[i].substring(11, 16),
        d(temps[i]),
        (codes[i] as num).toInt(),
      ));
    }

    final daily = j['daily'] as Map<String, dynamic>;
    final dTimes = List<String>.from(daily['time'] as List);
    final dCodes = daily['weather_code'] as List;
    final dMax = daily['temperature_2m_max'] as List;
    final dMin = daily['temperature_2m_min'] as List;
    final days = <WeatherDay>[];
    for (var i = 0; i < dTimes.length && i < 7; i++) {
      days.add(WeatherDay(
        DateTime.parse(dTimes[i]),
        d(dMax[i]),
        d(dMin[i]),
        (dCodes[i] as num).toInt(),
      ));
    }

    return WeatherData(
      temp: d(cur['temperature_2m']),
      humidity: d(cur['relative_humidity_2m']),
      windSpeed: d(cur['wind_speed_10m']),
      windDir: d(cur['wind_direction_10m']),
      code: (cur['weather_code'] as num).toInt(),
      isDay: (cur['is_day'] as num?) == 1,
      visibilityM: idx < vis.length && vis[idx] != null ? d(vis[idx]) : null,
      hours: hours,
      days: days,
    );
  }

  static Future<_Loc> _position() async {
    const fallback = _Loc(_fallbackLat, _fallbackLon);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return fallback;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return fallback;
      }
      final p = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      ).timeout(const Duration(seconds: 8));
      return _Loc(p.latitude, p.longitude);
    } catch (_) {
      return fallback;
    }
  }
}

class _Loc {
  final double lat;
  final double lon;
  const _Loc(this.lat, this.lon);
}

/// WMO weather code -> Indonesian label, icon.
String wxLabel(int c) {
  if (c == 0) return 'CERAH';
  if (c <= 2) return 'CERAH BERAWAN';
  if (c == 3) return 'BERAWAN';
  if (c == 45 || c == 48) return 'BERKABUT';
  if (c >= 51 && c <= 57) return 'GERIMIS';
  if (c >= 61 && c <= 67) return 'HUJAN';
  if (c >= 71 && c <= 77) return 'SALJU';
  if (c >= 80 && c <= 82) return 'HUJAN LOKAL';
  if (c >= 85 && c <= 86) return 'SALJU';
  if (c >= 95) return 'BADAI PETIR';
  return 'BERAWAN';
}

IconData wxIcon(int c, {bool isDay = true}) {
  if (c == 0) return isDay ? Icons.wb_sunny_rounded : Icons.nights_stay_rounded;
  if (c <= 3) return isDay ? Icons.wb_cloudy_rounded : Icons.cloud_rounded;
  if (c == 45 || c == 48) return Icons.foggy;
  if (c >= 51 && c <= 67) return Icons.grain_rounded;
  if (c >= 71 && c <= 77) return Icons.ac_unit_rounded;
  if (c >= 80 && c <= 82) return Icons.water_drop_rounded;
  if (c >= 85 && c <= 86) return Icons.ac_unit_rounded;
  if (c >= 95) return Icons.thunderstorm_rounded;
  return Icons.cloud_rounded;
}

Color wxIconColor(int c, {bool isDay = true}) {
  if (c == 0 && isDay) return const Color(0xFFFFD54F);
  if (c == 0) return const Color(0xFFD7C8FF);
  if (c <= 3) return isDay ? const Color(0xFFE3EEF7) : const Color(0xFFD7C8FF);
  if (c >= 95) return const Color(0xFFFFD54F);
  return const Color(0xFFB3E5FC);
}

const _monthsId = [
  'JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN', 'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES'
];
const _daysId = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN'];

String _fmtDate(DateTime d) =>
    '${_daysId[d.weekday - 1]}, ${d.day} ${_monthsId[d.month - 1]} ${d.year}';

/// Small chip shown on the dashboard. Tap opens [WeatherPage].
class WeatherChip extends StatefulWidget {
  const WeatherChip({super.key});

  @override
  State<WeatherChip> createState() => _WeatherChipState();
}

class _WeatherChipState extends State<WeatherChip> {
  WeatherData? _data;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await WeatherService.fetch();
      if (mounted) setState(() => _data = d);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = _data;
    return GestureDetector(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const WeatherPage()),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.35),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              d == null
                  ? (_failed ? Icons.cloud_off_rounded : Icons.hourglass_empty_rounded)
                  : wxIcon(d.code, isDay: d.isDay),
              size: 16,
              color: d == null ? Colors.white70 : wxIconColor(d.code, isDay: d.isDay),
            ),
            const SizedBox(width: 6),
            Text(
              d == null ? (_failed ? '--°C' : '...') : '${d.temp.round()}°C',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Full weather detail page (layout follows the reference screenshot).
class WeatherPage extends StatefulWidget {
  const WeatherPage({super.key});

  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  WeatherData? _data;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _error = null;
    });
    try {
      final d = await WeatherService.fetch();
      if (mounted) setState(() => _data = d);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _wxBottom,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_wxTop, _wxBottom],
            stops: [0.0, 0.45],
          ),
        ),
        child: SafeArea(
          child: _data == null
              ? _buildLoading()
              : RefreshIndicator(
                  onRefresh: _load,
                  child: _buildContent(_data!),
                ),
        ),
      ),
    );
  }

  Widget _buildLoading() {
    return Column(
      children: [
        _topBar(),
        Expanded(
          child: Center(
            child: _error == null
                ? const CircularProgressIndicator(color: _wxCyan)
                : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.cloud_off_rounded, color: Colors.white54, size: 48),
                      const SizedBox(height: 12),
                      const Text('Gagal memuat cuaca',
                          style: TextStyle(color: Colors.white70)),
                      const SizedBox(height: 12),
                      TextButton(onPressed: _load, child: const Text('Coba lagi')),
                    ],
                  ),
          ),
        ),
      ],
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            onPressed: () => Navigator.of(context).maybePop(),
          ),
          const Spacer(),
          const Icon(Icons.location_on_rounded, color: _wxCyan, size: 18),
        ],
      ),
    );
  }

  Widget _buildContent(WeatherData d) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 32),
      children: [
        _topBar(),
        const SizedBox(height: 8),
        Center(
          child: Icon(
            wxIcon(d.code, isDay: d.isDay),
            size: 120,
            color: wxIconColor(d.code, isDay: d.isDay),
          ),
        ),
        const SizedBox(height: 4),
        Center(
          child: Text(
            '${d.temp.round()}°',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 96,
              fontWeight: FontWeight.w900,
              height: 1,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Center(
          child: Text(
            wxLabel(d.code),
            style: const TextStyle(
              color: _wxCyan,
              fontSize: 22,
              fontWeight: FontWeight.w700,
              letterSpacing: 4,
            ),
          ),
        ),
        const SizedBox(height: 24),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 2.6,
              children: [
                _stat(Icons.water_drop_rounded, 'KELEMBAPAN', '${d.humidity.round()}%'),
                _stat(Icons.air_rounded, 'ANGIN', '${d.windSpeed.toStringAsFixed(1)} km/h'),
                _stat(Icons.explore_rounded, 'ARAH', _compass(d.windDir)),
                _stat(
                  Icons.visibility_rounded,
                  'JARAK PANDANG',
                  d.visibilityM == null
                      ? '-'
                      : d.visibilityM! >= 1000
                          ? '${(d.visibilityM! / 1000).toStringAsFixed(1)} km'
                          : '${d.visibilityM!.round()} m',
                ),
              ],
            ),
          ),
        ),
        _sectionTitle('PRAKIRAAN PER JAM'),
        SizedBox(
          height: 150,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            itemCount: d.hours.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) {
              final h = d.hours[i];
              return Container(
                width: 96,
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(h.time, style: const TextStyle(color: Colors.white60, fontSize: 13)),
                    const SizedBox(height: 8),
                    Icon(wxIcon(h.code), color: wxIconColor(h.code), size: 30),
                    const SizedBox(height: 8),
                    Text('${h.temp.round()}°',
                        style: const TextStyle(
                            color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  ],
                ),
              );
            },
          ),
        ),
        _sectionTitle('PRAKIRAAN 7 HARI'),
        ...d.days.map((day) => Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 5,
                      child: Text(_fmtDate(day.date),
                          style: const TextStyle(color: Colors.white, fontSize: 12)),
                    ),
                    Icon(wxIcon(day.code), color: wxIconColor(day.code), size: 22),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 4,
                      child: Text(wxLabel(day.code).toLowerCase(),
                          style: const TextStyle(color: Colors.white54, fontSize: 12)),
                    ),
                    Text('${day.tempMax.round()}°',
                        style: const TextStyle(
                            color: _wxCyan, fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 10),
                    Text('${day.tempMin.round()}°',
                        style: const TextStyle(color: Colors.white38, fontSize: 14)),
                  ],
                ),
              ),
            )),
      ],
    );
  }

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 26, 18, 12),
        child: Row(
          children: [
            Container(width: 4, height: 18, color: _wxCyan),
            const SizedBox(width: 10),
            Text(t,
                style: const TextStyle(
                    color: Colors.white, fontSize: 13, letterSpacing: 3)),
          ],
        ),
      );

  Widget _stat(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: _wxCyan, size: 22),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label,
                  style: const TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
              const SizedBox(height: 2),
              Text(value,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ],
    );
  }

  String _compass(double deg) {
    const dirs = ['U', 'UTL', 'T', 'TGR', 'S', 'BDS', 'B', 'BLU'];
    return dirs[((deg % 360) / 45).round() % 8];
  }
}
