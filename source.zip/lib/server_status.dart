import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';

/// Two compact cards for the dashboard profile card:
///   left  - STATUS SERVER : RAM used/total and CPU usage
///   right - PING SERVER   : round-trip time to the API and CPU load average
/// Data refreshes by itself every minute (and once right away).
///
/// Ping is measured from the phone to the API (GET /ping). RAM/CPU come from
/// GET /api/server/status, which index.js must provide (see the backend patch).
class ServerStatusRow extends StatefulWidget {
  final String sessionKey;
  const ServerStatusRow({super.key, required this.sessionKey});

  @override
  State<ServerStatusRow> createState() => _ServerStatusRowState();
}

class _ServerStatusRowState extends State<ServerStatusRow> {
  static const Duration _interval = Duration(minutes: 1);

  final http.Client _client = http.Client();
  Timer? _timer;
  bool _busy = false;
  bool _loaded = false;

  int? _pingMs;
  double? _ramUsed;
  double? _ramTotal;
  double? _cpuPercent;
  double? _load1;

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(_interval, (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _client.close();
    super.dispose();
  }

  Future<int?> _ping() async {
    // Two requests on the same client: the first pays for DNS/TLS setup, so
    // the lower of the two is the real round-trip time.
    int? best;
    for (var i = 0; i < 2; i++) {
      final sw = Stopwatch()..start();
      try {
        final r = await _client
            .get(Uri.parse('$baseUrl/ping'))
            .timeout(const Duration(seconds: 8));
        sw.stop();
        if (r.statusCode != 200) return best;
        final ms = sw.elapsedMilliseconds;
        if (best == null || ms < best) best = ms;
      } catch (_) {
        return best;
      }
    }
    return best;
  }

  Future<Map<String, dynamic>?> _stats() async {
    try {
      final uri = Uri.parse('$baseUrl/api/server/status')
          .replace(queryParameters: {'session_key': widget.sessionKey});
      final r = await _client.get(uri).timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) return null;
      final j = jsonDecode(r.body);
      if (j is Map && j['valid'] == true) return Map<String, dynamic>.from(j);
    } catch (_) {}
    return null;
  }

  double? _num(Object? v) => v is num ? v.toDouble() : null;

  Future<void> _refresh() async {
    if (_busy) return;
    _busy = true;
    try {
      final results = await Future.wait([_ping(), _stats()]);
      final ping = results[0] as int?;
      final s = results[1] as Map<String, dynamic>?;
      if (!mounted) return;
      final ram = s?['ram'] is Map ? Map<String, dynamic>.from(s!['ram']) : null;
      final cpu = s?['cpu'] is Map ? Map<String, dynamic>.from(s!['cpu']) : null;
      setState(() {
        _loaded = true;
        _pingMs = ping;
        _ramUsed = _num(ram?['used']);
        _ramTotal = _num(ram?['total']);
        _cpuPercent = _num(cpu?['percent']);
        _load1 = _num(cpu?['load1']);
      });
    } finally {
      _busy = false;
    }
  }

  String _bytes(double b) {
    const gb = 1024 * 1024 * 1024;
    const mb = 1024 * 1024;
    if (b >= gb) return '${(b / gb).toStringAsFixed(1)}GB';
    return '${(b / mb).toStringAsFixed(0)}MB';
  }

  String get _ramText {
    if (!_loaded) return 'RAM: ...';
    if (_ramUsed == null || _ramTotal == null) return 'RAM: -';
    return 'RAM: ${_bytes(_ramUsed!)}/${_bytes(_ramTotal!)}';
  }

  String get _cpuText {
    if (!_loaded) return 'CPU: ...';
    return _cpuPercent == null ? 'CPU: -' : 'CPU: ${_cpuPercent!.toStringAsFixed(2)}';
  }

  String get _pingText {
    if (!_loaded) return 'Ping: ...';
    return _pingMs == null ? 'Ping: timeout' : 'Ping: $_pingMs ms';
  }

  String get _loadText {
    if (!_loaded) return 'CPU Load: ...';
    return _load1 == null ? 'CPU Load: -' : 'CPU Load: ${_load1!.toStringAsFixed(2)}';
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: _card(
            icon: Icons.dns_rounded,
            title: 'STATUS SERVER',
            lines: [_ramText, _cpuText],
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _card(
            icon: Icons.speed_rounded,
            title: 'PING SERVER',
            lines: [_pingText, _loadText],
          ),
        ),
      ],
    );
  }

  Widget _card({
    required IconData icon,
    required String title,
    required List<String> lines,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.10),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.30), width: 1.2),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.white, size: 24),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _fit(title, const TextStyle(
                  color: Colors.white,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                  fontFamily: 'Orbitron',
                )),
                const SizedBox(height: 3),
                for (final l in lines)
                  _fit(l, TextStyle(
                    color: Colors.white.withOpacity(0.92),
                    fontSize: 11.5,
                    height: 1.35,
                  )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // scaleDown keeps long values (e.g. "RAM: 6.2GB/17.6GB") on one line
  // instead of overflowing on narrow screens.
  Widget _fit(String text, TextStyle style) => FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: Text(text, style: style, maxLines: 1),
      );
}
