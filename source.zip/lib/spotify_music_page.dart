import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'global_music_overlay.dart';
import 'music_player_service.dart';

// Fixed dark palette, matching the reference "music welcome" screen. It is
// intentionally independent of the app theme (like splash/login).
const Color _bgTop = Color(0xFF0B1628);
const Color _bgBottom = Color(0xFF070C14);
const Color _cyan = Color(0xFF6EC3F2);
const Color _teal = Color(0xFF2DD4BF);
const Color _blue = Color(0xFF2F80D6);
const Color _blueDark = Color(0xFF1F62B0);
const Color _field = Color(0xFF111A27);
const Color _fieldBorder = Color(0xFF263447);
const Color _playGreen = Color(0xFF1ED760);

/// Music screen backed by the Spotify Web API (via the backend proxy).
///
/// * [welcome] = true: shown right after login, before the dashboard. It has
///   "MASUK KE DASHBOARD" and "LEWATI MUSIK"; [nextBuilder] builds the dashboard.
/// * [welcome] = false: opened manually from the dashboard header button.
class SpotifyMusicPage extends StatefulWidget {
  final bool welcome;
  final WidgetBuilder? nextBuilder;

  const SpotifyMusicPage({super.key, this.welcome = false, this.nextBuilder})
      : assert(!welcome || nextBuilder != null,
            'nextBuilder is required in welcome mode');

  @override
  State<SpotifyMusicPage> createState() => _SpotifyMusicPageState();
}

class _SpotifyMusicPageState extends State<SpotifyMusicPage>
    with TickerProviderStateMixin {
  final MusicPlayerController _c = MusicPlayerController.instance;
  final TextEditingController _search = TextEditingController();
  final FocusNode _focus = FocusNode();

  late final AnimationController _spin = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 7),
  );
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat();

  bool _gateWasEnabled = false;
  bool _leaving = false;
  String? _hint;

  @override
  void initState() {
    super.initState();
    _search.text = _c.query;
    _c.addListener(_onPlayer);
    _syncSpin();

    // The floating music button/mini player would sit on top of this screen,
    // so hide it while this page is open and bring it back afterwards.
    _gateWasEnabled = MusicOverlayGate.enabled.value;
    WidgetsBinding.instance.addPostFrameCallback((_) => MusicOverlayGate.hide());
  }

  @override
  void dispose() {
    _c.removeListener(_onPlayer);
    if (!widget.welcome && _gateWasEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => MusicOverlayGate.show());
    }
    _spin.dispose();
    _pulse.dispose();
    _search.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onPlayer() {
    if (!mounted) return;
    _syncSpin();
    setState(() {});
  }

  void _syncSpin() {
    if (_c.playing) {
      if (!_spin.isAnimating) _spin.repeat();
    } else {
      _spin.stop();
    }
  }

  Future<void> _searchAndPlay() async {
    final q = _search.text.trim();
    FocusScope.of(context).unfocus();
    if (q.isEmpty) {
      setState(() => _hint = 'Ketik judul lagu atau nama artis dulu.');
      return;
    }
    setState(() => _hint = null);
    await _c.searchAndPlay(q);
  }

  Future<void> _enter({required bool keepMusic}) async {
    if (_leaving) return;
    _leaving = true;
    if (!keepMusic) await _c.stop();
    MusicOverlayGate.show();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: widget.nextBuilder!),
    );
  }

  String get _statusText {
    if (_c.searching) return 'MENCARI DI SPOTIFY...';
    if (_c.loading) return 'MEMUAT LAGU...';
    final t = _c.current;
    if (t != null) return '${t.title} · ${t.artist}';
    return 'DARK LIGHT AUDIO · SIAP MEMUTAR';
  }

  @override
  Widget build(BuildContext context) {
    final message = _hint ?? _c.error;

    final page = AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _bgBottom,
        resizeToAvoidBottomInset: true,
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [_bgTop, _bgBottom],
            ),
          ),
          child: Stack(
            children: [
              Positioned(right: -90, bottom: -70, child: _glow(260, const Color(0xFF0E7C66))),
              Positioned(left: -80, top: 140, child: _glow(230, _blueDark)),
              SafeArea(
                child: LayoutBuilder(
                  builder: (context, cons) {
                    final compact = cons.maxHeight < 720;
                    final disk = compact ? 190.0 : 244.0;
                    return SingleChildScrollView(
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      child: ConstrainedBox(
                        constraints: BoxConstraints(minHeight: cons.maxHeight),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _header(),
                            Column(
                              children: [
                                _Turntable(spin: _spin, playing: _c.playing, diameter: disk),
                                SizedBox(height: compact ? 16 : 26),
                                _EqDots(
                                  pulse: _pulse,
                                  active: _c.playing || _c.searching || _c.loading,
                                ),
                                const SizedBox(height: 16),
                                _statusPill(),
                                if (_c.current != null) _nowPlayingControls(),
                                if (message != null && message.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(28, 10, 28, 0),
                                    child: Text(
                                      message,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Color(0xFFFFB86B),
                                        fontSize: 11.5,
                                        height: 1.35,
                                      ),
                                    ),
                                  ),
                                if (_c.results.isNotEmpty)
                                  TextButton(
                                    onPressed: () => showSpotifyResultsPanel(context),
                                    child: Text(
                                      'LIHAT ${_c.results.length} HASIL LAINNYA',
                                      style: const TextStyle(
                                        color: _cyan,
                                        fontSize: 11,
                                        letterSpacing: 1.6,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                            _controls(),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (!widget.welcome) return page;

    // System back on the welcome screen = skip to the dashboard (keep music).
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _enter(keepMusic: true);
      },
      child: page,
    );
  }

  Widget _glow(double size, Color color) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [color.withOpacity(0.30), color.withOpacity(0)],
            ),
          ),
        ),
      );

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
      child: Column(
        children: [
          if (!widget.welcome)
            Align(
              alignment: Alignment.centerLeft,
              child: IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                onPressed: () => Navigator.of(context).maybePop(),
              ),
            )
          else
            const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 11,
                height: 11,
                decoration: const BoxDecoration(color: _cyan, shape: BoxShape.circle),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  widget.welcome ? 'SELAMAT DATANG DI DARK LIGHT' : 'MUSIK VIA SPOTIFY',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _cyan,
                    fontSize: 12.5,
                    letterSpacing: 3,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              'DARK LIGHT MUSIC',
              style: TextStyle(
                color: Colors.white,
                fontSize: 34,
                fontWeight: FontWeight.w800,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusPill() {
    final busy = _c.searching || _c.loading;
    return Container(
      constraints: const BoxConstraints(maxWidth: 320),
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 13),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _fieldBorder, width: 1.3),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          busy
              ? const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(strokeWidth: 2, color: _cyan),
                )
              : Container(
                  width: 11,
                  height: 11,
                  decoration: BoxDecoration(
                    color: _c.playing ? _playGreen : _cyan,
                    shape: BoxShape.circle,
                  ),
                ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              _statusText,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13.5,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _nowPlayingControls() {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Column(
        children: [
          SizedBox(
            width: 220,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: _c.progress,
                minHeight: 3,
                color: _cyan,
                backgroundColor: Colors.white12,
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                iconSize: 42,
                onPressed: _c.toggle,
                icon: Icon(
                  _c.playing
                      ? Icons.pause_circle_filled_rounded
                      : Icons.play_circle_fill_rounded,
                  color: _cyan,
                ),
              ),
              IconButton(
                iconSize: 34,
                onPressed: _c.stop,
                icon: const Icon(Icons.stop_circle_outlined, color: Colors.white54),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _controls() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
      child: Column(
        children: [
          TextField(
            controller: _search,
            focusNode: _focus,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _searchAndPlay(),
            onChanged: (_) {
              if (_hint != null) setState(() => _hint = null);
            },
            style: const TextStyle(color: Colors.white, fontSize: 15),
            cursorColor: _cyan,
            decoration: InputDecoration(
              hintText: 'Cari judul lagu atau nama artis...',
              hintStyle: const TextStyle(color: Color(0xFF7C8AA0), fontSize: 14.5),
              prefixIcon: const Padding(
                padding: EdgeInsets.only(left: 6),
                child: Icon(Icons.search_rounded, color: _cyan, size: 26),
              ),
              filled: true,
              fillColor: _field,
              contentPadding: const EdgeInsets.symmetric(vertical: 17, horizontal: 16),
              border: _fieldOutline(_fieldBorder),
              enabledBorder: _fieldOutline(_fieldBorder),
              focusedBorder: _fieldOutline(_cyan.withOpacity(0.7)),
            ),
          ),
          const SizedBox(height: 12),
          _PillButton(
            label: 'CARI & PUTAR',
            icon: Icons.music_note_rounded,
            loading: _c.searching || _c.loading,
            onTap: _searchAndPlay,
          ),
          if (widget.welcome) ...[
            const SizedBox(height: 12),
            _PillButton(
              label: 'MASUK KE DASHBOARD',
              icon: Icons.dashboard_rounded,
              onTap: () => _enter(keepMusic: true),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () => _enter(keepMusic: false),
              child: const Text(
                'LEWATI MUSIK',
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 13,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  OutlineInputBorder _fieldOutline(Color color) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(24),
        borderSide: BorderSide(color: color, width: 1.3),
      );
}

class _PillButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool loading;

  const _PillButton({
    required this.label,
    required this.icon,
    required this.onTap,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: loading ? 0.75 : 1,
      child: Container(
        height: 58,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_blue, _blueDark],
          ),
          borderRadius: BorderRadius.circular(29),
          border: Border.all(color: _cyan.withOpacity(0.35), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: _blue.withOpacity(0.28),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(29),
            onTap: loading ? null : onTap,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                loading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                      )
                    : Icon(icon, color: Colors.white, size: 24),
                const SizedBox(width: 12),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2.2,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Row of small dots that pulse like an equaliser while audio is active.
class _EqDots extends StatelessWidget {
  final Animation<double> pulse;
  final bool active;
  const _EqDots({required this.pulse, required this.active});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: pulse,
      builder: (context, _) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(9, (i) {
            final t = active
                ? (math.sin((pulse.value + i / 9) * 2 * math.pi) + 1) / 2
                : 0.35;
            final size = 5.0 + 3.5 * t;
            return Container(
              width: size,
              height: size,
              margin: const EdgeInsets.symmetric(horizontal: 4.5),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: (i.isEven ? _cyan : _teal).withOpacity(0.55 + 0.45 * t),
              ),
            );
          }),
        );
      },
    );
  }
}

/// Vinyl record that spins while music plays, with a tone arm that lowers
/// onto it.
class _Turntable extends StatelessWidget {
  final Animation<double> spin;
  final bool playing;
  final double diameter;

  const _Turntable({
    required this.spin,
    required this.playing,
    required this.diameter,
  });

  @override
  Widget build(BuildContext context) {
    final d = diameter;
    final boxW = d + 34;
    final boxH = d + 18;
    // The arm pivots around its own top-right corner area.
    final pivot = Alignment(((boxW - 14) / boxW) * 2 - 1, (14 / boxH) * 2 - 1);

    return SizedBox(
      width: boxW,
      height: boxH,
      child: Stack(
        children: [
          Positioned(
            left: 0,
            bottom: 0,
            width: d,
            height: d,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _blue.withOpacity(playing ? 0.42 : 0.22),
                    blurRadius: 46,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: RotationTransition(
                turns: spin,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CustomPaint(size: Size.square(d), painter: const _VinylPainter()),
                    Container(
                      width: d * 0.37,
                      height: d * 0.37,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF0E1A33),
                        border: Border.all(color: _cyan, width: 2.6),
                      ),
                      child: Icon(Icons.headphones_rounded, color: _cyan, size: d * 0.13),
                    ),
                    Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: AnimatedRotation(
              turns: playing ? 0.0 : -0.04,
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeInOutCubic,
              alignment: pivot,
              child: CustomPaint(painter: _ArmPainter(d)),
            ),
          ),
        ],
      ),
    );
  }
}

class _VinylPainter extends CustomPainter {
  const _VinylPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final rect = Rect.fromCircle(center: c, radius: r);

    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = const RadialGradient(
          colors: [Color(0xFF1C2532), Color(0xFF0B1118)],
          stops: [0.25, 1.0],
        ).createShader(rect),
    );

    final groove = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;
    for (var i = 0; i < 22; i++) {
      groove.color = Colors.white.withOpacity(i % 3 == 0 ? 0.075 : 0.035);
      canvas.drawCircle(c, r * (0.36 + i * 0.027), groove);
    }

    canvas.drawCircle(
      c,
      r * 0.97,
      Paint()
        ..shader = SweepGradient(
          colors: [
            Colors.transparent,
            Colors.white.withOpacity(0.10),
            Colors.transparent,
            Colors.transparent,
            Colors.white.withOpacity(0.07),
            Colors.transparent,
          ],
          stops: const [0.0, 0.08, 0.16, 0.5, 0.58, 0.66],
        ).createShader(rect),
    );

    canvas.drawCircle(
      c,
      r - 1,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF2A3A55),
    );
  }

  @override
  bool shouldRepaint(covariant _VinylPainter oldDelegate) => false;
}

class _ArmPainter extends CustomPainter {
  final double d;
  const _ArmPainter(this.d);

  @override
  void paint(Canvas canvas, Size size) {
    final pivot = Offset(size.width - 14, 14);
    final elbow = pivot + Offset(-0.033 * d, 0.22 * d);
    final tip = elbow + Offset(-0.083 * d, 0.175 * d);

    final arm = Paint()
      ..color = const Color(0xFFD3DDEA)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(pivot.dx, pivot.dy)
      ..lineTo(elbow.dx, elbow.dy)
      ..lineTo(tip.dx, tip.dy);
    canvas.drawPath(path, arm);

    // Cartridge at the tip, rotated along the last segment.
    final angle = math.atan2(tip.dy - elbow.dy, tip.dx - elbow.dx);
    canvas.save();
    canvas.translate(tip.dx, tip.dy);
    canvas.rotate(angle - math.pi / 2);
    final body = RRect.fromRectAndRadius(
      const Rect.fromLTWH(-8, -2, 16, 30),
      const Radius.circular(5),
    );
    canvas.drawRRect(body, Paint()..color = const Color(0xFF1B2434));
    canvas.drawRRect(
      body,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = const Color(0xFF3B4C68),
    );
    canvas.drawCircle(const Offset(0, 22), 3, Paint()..color = _blue);
    canvas.restore();

    // Pivot base on top.
    canvas.drawCircle(pivot, 14, Paint()..color = const Color(0xFF8196B4));
    canvas.drawCircle(
      pivot,
      14,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = const Color(0xFFB9C7DB),
    );
    canvas.drawCircle(pivot, 5, Paint()..color = const Color(0xFFDCE6F3));
  }

  @override
  bool shouldRepaint(covariant _ArmPainter oldDelegate) => oldDelegate.d != d;
}
