import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'music_player_service.dart';

/// Playlist lokal (disimpan di SharedPreferences).
class MusicPlaylist {
  final String id;
  String name;
  final List<MusicTrack> tracks;
  final DateTime createdAt;

  MusicPlaylist({
    required this.id,
    required this.name,
    List<MusicTrack>? tracks,
    DateTime? createdAt,
  })  : tracks = tracks ?? <MusicTrack>[],
        createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'createdAt': createdAt.toIso8601String(),
        'tracks': tracks.map((t) => t.toJson()).toList(),
      };

  factory MusicPlaylist.fromJson(Map<String, dynamic> json) {
    final raw = json['tracks'];
    final list = <MusicTrack>[];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map<String, dynamic>) {
          list.add(MusicTrack.fromJson(item));
        } else if (item is Map) {
          list.add(MusicTrack.fromJson(Map<String, dynamic>.from(item)));
        }
      }
    }
    return MusicPlaylist(
      id: (json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString())
          .toString(),
      name: (json['name'] ?? 'Playlist').toString(),
      tracks: list,
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ??
          DateTime.now(),
    );
  }
}

/// Penyimpanan lokal: favorit + playlist.
class MusicLibrary extends ChangeNotifier {
  MusicLibrary._();
  static final MusicLibrary instance = MusicLibrary._();

  static const _kFavorites = 'music_library_favorites_v1';
  static const _kPlaylists = 'music_library_playlists_v1';

  final List<MusicTrack> _favorites = <MusicTrack>[];
  final List<MusicPlaylist> _playlists = <MusicPlaylist>[];
  bool _loaded = false;

  List<MusicTrack> get favorites => List.unmodifiable(_favorites);
  List<MusicPlaylist> get playlists => List.unmodifiable(_playlists);
  bool get isLoaded => _loaded;

  Future<void> load() async {
    if (_loaded) return;
    try {
      final prefs = await SharedPreferences.getInstance();

      final favRaw = prefs.getString(_kFavorites);
      if (favRaw != null && favRaw.isNotEmpty) {
        final decoded = jsonDecode(favRaw);
        if (decoded is List) {
          _favorites
            ..clear()
            ..addAll(
              decoded
                  .whereType<Map>()
                  .map((e) => MusicTrack.fromJson(Map<String, dynamic>.from(e))),
            );
        }
      }

      final plRaw = prefs.getString(_kPlaylists);
      if (plRaw != null && plRaw.isNotEmpty) {
        final decoded = jsonDecode(plRaw);
        if (decoded is List) {
          _playlists
            ..clear()
            ..addAll(
              decoded.whereType<Map>().map(
                    (e) => MusicPlaylist.fromJson(Map<String, dynamic>.from(e)),
                  ),
            );
        }
      }
    } catch (_) {
      // ignore corrupt storage
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _kFavorites,
      jsonEncode(_favorites.map((t) => t.toJson()).toList()),
    );
  }

  Future<void> _savePlaylists() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _kPlaylists,
      jsonEncode(_playlists.map((p) => p.toJson()).toList()),
    );
  }

  bool isFavorite(MusicTrack track) {
    final k = track.key;
    return _favorites.any((t) => t.key == k);
  }

  Future<void> toggleFavorite(MusicTrack track) async {
    await load();
    final k = track.key;
    final idx = _favorites.indexWhere((t) => t.key == k);
    if (idx >= 0) {
      _favorites.removeAt(idx);
    } else {
      // simpan tanpa stream URL (bisa expired)
      _favorites.insert(
        0,
        MusicTrack(
          id: track.id,
          title: track.title,
          artist: track.artist,
          artwork: track.artwork,
          durationMs: track.durationMs,
          sourceUrl: track.sourceUrl,
          durationLabel: track.durationLabel,
        ),
      );
    }
    await _saveFavorites();
    notifyListeners();
  }

  Future<void> removeFavorite(MusicTrack track) async {
    await load();
    _favorites.removeWhere((t) => t.key == track.key);
    await _saveFavorites();
    notifyListeners();
  }

  Future<MusicPlaylist> createPlaylist(String name) async {
    await load();
    final pl = MusicPlaylist(
      id: 'pl_${DateTime.now().millisecondsSinceEpoch}',
      name: name.trim().isEmpty ? 'Playlist baru' : name.trim(),
    );
    _playlists.insert(0, pl);
    await _savePlaylists();
    notifyListeners();
    return pl;
  }

  Future<void> renamePlaylist(String id, String name) async {
    await load();
    final pl = _playlists.cast<MusicPlaylist?>().firstWhere(
          (p) => p?.id == id,
          orElse: () => null,
        );
    if (pl == null) return;
    pl.name = name.trim().isEmpty ? pl.name : name.trim();
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> deletePlaylist(String id) async {
    await load();
    _playlists.removeWhere((p) => p.id == id);
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> addToPlaylist(String playlistId, MusicTrack track) async {
    await load();
    final pl = _playlists.cast<MusicPlaylist?>().firstWhere(
          (p) => p?.id == playlistId,
          orElse: () => null,
        );
    if (pl == null) return;
    if (pl.tracks.any((t) => t.key == track.key)) return;
    pl.tracks.add(
      MusicTrack(
        id: track.id,
        title: track.title,
        artist: track.artist,
        artwork: track.artwork,
        durationMs: track.durationMs,
        sourceUrl: track.sourceUrl,
        durationLabel: track.durationLabel,
      ),
    );
    await _savePlaylists();
    notifyListeners();
  }

  Future<void> removeFromPlaylist(String playlistId, MusicTrack track) async {
    await load();
    final pl = _playlists.cast<MusicPlaylist?>().firstWhere(
          (p) => p?.id == playlistId,
          orElse: () => null,
        );
    if (pl == null) return;
    pl.tracks.removeWhere((t) => t.key == track.key);
    await _savePlaylists();
    notifyListeners();
  }

  MusicPlaylist? playlistById(String id) {
    try {
      return _playlists.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }
}
