import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

// Every colour in this file is derived from the active comic palette
// (Utama / Aksen / Latar / Garis) through the tokens on ThemeProvider, the
// same way `body.comic` in index.html derives --red, --yellow, --paper,
// --ink, --red-d, --paper2 and --muted. Picking another template (Samudra,
// Hutan, ...) therefore repaints the paper, the halftone dots, the sunburst
// and the doodles, not just the Material widgets.
//
// Each widget calls context.watch<ThemeProvider>() so it rebuilds by itself
// even when it is created as a `const` inside a parent that does not rebuild.

/// Paper background, a 1:1 port of `body.comic` in index.html:
///   - base colour --paper
///   - ink halftone dots  radial-gradient(circle, ink 14% 1.4px) on a 16px grid
///   - red halftone dots  body.comic:before, red 12% 5px dots on a 46px grid,
///                        opacity .5 (effective red alpha ~6%), offset 12px
/// It never intercepts taps.
class ComicThemeAtmosphere extends StatelessWidget {
  final Widget child;
  const ComicThemeAtmosphere({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    final paper = ThemeProvider.comicPaper;
    return Stack(
      fit: StackFit.expand,
      children: [
        ColoredBox(color: paper),
        IgnorePointer(
          child: CustomPaint(
            painter: _ComicPaperPainter(
              ink: ThemeProvider.comicInk,
              red: ThemeProvider.comicRed,
            ),
          ),
        ),
        child,
      ],
    );
  }
}

class _ComicPaperPainter extends CustomPainter {
  final Color ink;
  final Color red;
  const _ComicPaperPainter({required this.ink, required this.red});

  @override
  void paint(Canvas canvas, Size size) {
    // color-mix(in srgb, var(--ink) 14%, transparent)
    final inkPaint = Paint()..color = ink.withOpacity(.14);
    for (double y = 8; y < size.height + 16; y += 16) {
      for (double x = 8; x < size.width + 16; x += 16) {
        canvas.drawCircle(Offset(x, y), 1.4, inkPaint);
      }
    }

    // color-mix(in srgb, var(--red) 12%, transparent) at layer opacity .5
    final redPaint = Paint()..color = red.withOpacity(.12 * .5);
    for (double y = 35; y < size.height + 46; y += 46) {
      for (double x = 35; x < size.width + 46; x += 46) {
        canvas.drawCircle(Offset(x, y), 5, redPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ComicPaperPainter old) =>
      old.ink != ink || old.red != red;
}

/// Just the halftone-dot texture from `body.comic` — no solid paper fill
/// underneath, so it tints a real photo/background instead of covering it.
/// Used where a page wants to keep its own background (e.g. the dashboard's
/// mountain scene) while still reading as "comic paper".
class ComicPaperDotsOverlay extends StatelessWidget {
  const ComicPaperDotsOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    return CustomPaint(
      painter: _ComicPaperPainter(
        ink: ThemeProvider.comicInk,
        red: ThemeProvider.comicRed,
      ),
    );
  }
}

/// Replaces photo backgrounds (banners, profile card, drawer header) in comic
/// mode. 1:1 port of `body.comic #loader` in index.html:
///   radial-gradient(circle, rgba(0,0,0,.18) 2px, transparent 2.4px) 0 0/18px 18px,
///   repeating-conic-gradient(from 0deg at 50% 45%, --red 0 8deg, --red-d 8deg 16deg)
class ComicSunburstBackground extends StatelessWidget {
  const ComicSunburstBackground({super.key});

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    return SizedBox.expand(
      child: IgnorePointer(
        child: CustomPaint(
          painter: _ComicSunburstPainter(
            red: ThemeProvider.comicRed,
            redDark: ThemeProvider.comicRedDark,
          ),
        ),
      ),
    );
  }
}

class _ComicSunburstPainter extends CustomPainter {
  final Color red;
  final Color redDark;
  const _ComicSunburstPainter({required this.red, required this.redDark});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * 0.5, size.height * 0.45);
    final radius = size.longestSide * 1.5;
    final rect = Rect.fromCircle(center: center, radius: radius);

    // Base colour, then alternate dark wedges (8deg..16deg of every 16deg).
    canvas.drawRect(Offset.zero & size, Paint()..color = red);
    final dark = Paint()..color = redDark;
    const deg = math.pi / 180;
    for (double a = 8; a < 360; a += 16) {
      final sweep = (a + 8 > 360 ? 360 - a : 8) * deg;
      // CSS conic starts at the top (12 o'clock) and runs clockwise.
      canvas.drawArc(rect, (-90 + a) * deg, sweep, true, dark);
    }

    // Halftone dots: 18px tile, dot at tile centre, r = 2px, black @ 18%.
    final dot = Paint()..color = const Color(0x2E000000);
    for (double y = 9; y < size.height + 18; y += 18) {
      for (double x = 9; x < size.width + 18; x += 18) {
        canvas.drawCircle(Offset(x, y), 2, dot);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ComicSunburstPainter old) =>
      old.red != red || old.redDark != redDark;
}

/// Scattered comic-style doodle motifs: sparkle stars, hand-drawn scribble
/// dashes, a zigzag squiggle, a circle ring and a curved swoosh line.
/// Pure vector, follows the active comic palette, never intercepts taps.
/// Positions are fractional so the layout adapts to any screen.
class ComicDoodleLayer extends StatelessWidget {
  const ComicDoodleLayer({super.key});

  @override
  Widget build(BuildContext context) {
    context.watch<ThemeProvider>();
    return IgnorePointer(
      child: SizedBox.expand(
        child: RepaintBoundary(
          child: CustomPaint(
            painter: _ComicDoodlePainter(
              ink: ThemeProvider.comicInk,
              red: ThemeProvider.comicRed,
              yellow: ThemeProvider.comicYellow,
              redDark: ThemeProvider.comicRedDark,
              soft: Color.lerp(ThemeProvider.comicRed, Colors.white, .55)!,
            ),
          ),
        ),
      ),
    );
  }
}

class _ComicDoodlePainter extends CustomPainter {
  final Color ink;
  final Color red;
  final Color yellow;
  final Color redDark; // replaces the old fixed blue
  final Color soft; // replaces the old fixed pink
  const _ComicDoodlePainter({
    required this.ink,
    required this.red,
    required this.yellow,
    required this.redDark,
    required this.soft,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;

    // ── coretan / scribble dash marks ──────────────────────────────
    _scribble(canvas, Offset(w * .05, h * .065), 42, -16, ink.withOpacity(.16));
    _scribble(canvas, Offset(w * .07, h * .105), 26, -4, ink.withOpacity(.13));
    _scribble(canvas, Offset(w * .015, h * .40), 50, 76, ink.withOpacity(.14));
    _scribble(canvas, Offset(w * .90, h * .565), 46, 8, ink.withOpacity(.13));
    _scribble(canvas, Offset(w * .93, h * .145), 32, 100, ink.withOpacity(.11));
    _scribble(canvas, Offset(w * .10, h * .935), 36, -70, ink.withOpacity(.12));

    // ── bintang kerlip / sparkle stars ─────────────────────────────
    _sparkle(canvas, Offset(w * .30, h * .25), 9, red.withOpacity(.9));
    _sparkle(canvas, Offset(w * .115, h * .45), 13, red.withOpacity(.85));
    _sparkle(canvas, Offset(w * .105, h * .085), 7, redDark.withOpacity(.85));
    _sparkle(canvas, Offset(w * .915, h * .545), 11, soft.withOpacity(.85));
    _sparkle(canvas, Offset(w * .965, h * .295), 8, yellow.withOpacity(.9));
    _sparkle(canvas, Offset(w * .645, h * .095), 10, ink.withOpacity(.45));
    _sparkle(canvas, Offset(w * .50, h * .93), 8, red.withOpacity(.7));

    // ── lingkaran ring ──────────────────────────────────────────────
    _ring(canvas, Offset(w * .155, h * .80), 17, soft.withOpacity(.55));
    _ring(canvas, Offset(w * .915, h * .04), 8, yellow.withOpacity(.65));

    // ── zigzag ────────────────────────────────────────────────────
    _zigzag(canvas, Offset(w * .80, h * .505), w * .065, h * .015, redDark.withOpacity(.75));

    // ── lengkungan / swoosh ─────────────────────────────────────────
    _swoosh(canvas, Offset(w * .87, h * .735), w * .40, h * .16, soft.withOpacity(.45));
  }

  void _scribble(Canvas c, Offset center, double len, double angleDeg, Color color) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    c.save();
    c.translate(center.dx, center.dy);
    c.rotate(angleDeg * math.pi / 180);
    c.drawLine(Offset(-len / 2, 0), Offset(len / 2, 0), paint);
    c.restore();
  }

  void _sparkle(Canvas c, Offset center, double r, Color color) {
    final paint = Paint()..color = color;
    final path = Path();
    for (var i = 0; i < 4; i++) {
      final angle = i * math.pi / 2;
      final outer = Offset(center.dx + r * math.cos(angle), center.dy + r * math.sin(angle));
      final midAngle = angle + math.pi / 4;
      final inner = Offset(
        center.dx + (r * .35) * math.cos(midAngle),
        center.dy + (r * .35) * math.sin(midAngle),
      );
      if (i == 0) {
        path.moveTo(outer.dx, outer.dy);
      } else {
        path.lineTo(outer.dx, outer.dy);
      }
      path.lineTo(inner.dx, inner.dy);
    }
    path.close();
    c.drawPath(path, paint);
  }

  void _ring(Canvas c, Offset center, double r, Color color) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..color = color;
    c.drawCircle(center, r, paint);
  }

  void _zigzag(Canvas c, Offset start, double segment, double amplitude, Color color) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = color;
    final path = Path()..moveTo(start.dx, start.dy);
    for (var i = 1; i <= 4; i++) {
      final x = start.dx + segment * i;
      final y = start.dy + (i.isOdd ? -amplitude : amplitude);
      path.lineTo(x, y);
    }
    c.drawPath(path, paint);
  }

  void _swoosh(Canvas c, Offset start, double width, double height, Color color) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..color = color;
    final path = Path()..moveTo(start.dx, start.dy);
    path.quadraticBezierTo(
      start.dx - width * .5,
      start.dy - height,
      start.dx - width,
      start.dy + height * .3,
    );
    c.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _ComicDoodlePainter old) =>
      old.ink != ink || old.red != red || old.yellow != yellow ||
      old.redDark != redDark || old.soft != soft;
}
