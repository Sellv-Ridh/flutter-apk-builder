import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';
import 'theme_provider.dart';
import 'global_chat_page.dart';
import 'private_chat_page.dart';
import 'ai_chat_page.dart';
import 'room_chat_page.dart';
import 'story_page.dart';

const _waGreen = Color(0xFF00A884);
const _waDarkHeader = Color(0xFF111B21);
const _waDarkBg = Color(0xFF080D10);
const _waDarkCard = Color(0xFF10191E);
const _waMuted = Color(0xFF8696A0);
const _waSurface = Color(0xFF10191E);
const _waDivider = Color(0xFF1E2A30);

class ChatRoomPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  const ChatRoomPage({super.key, required this.username, required this.sessionKey});
  @override State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> with SingleTickerProviderStateMixin {
  late final TabController tabs;
  final search = TextEditingController();
  Timer? refresh;
  List<Map<String, dynamic>> rooms = [];
  List<Map<String, dynamic>> users = [];
  List<Map<String, dynamic>> channels = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    // Chat ships its own fixed dark theme: suppress the global comic/anime
    // skin for as long as this page is on screen.
    ThemeProvider.pushOwnTheme();
    tabs = TabController(length: 3, vsync: this);
    _load();
    refresh = Timer.periodic(const Duration(seconds: 8), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    ThemeProvider.popOwnTheme();
    refresh?.cancel();
    tabs.dispose();
    search.dispose();
    super.dispose();
  }

  Uri _u(String path, [Map<String, String>? q]) => Uri.parse('$baseUrl$path').replace(queryParameters: q);

  Future<void> _load({bool silent = false}) async {
    if (!silent && mounted) setState(() => loading = true);
    try {
      final results = await Future.wait([
        http.get(_u('/api/chat/rooms', {'session_key': widget.sessionKey})).timeout(const Duration(seconds: 10)),
        http.get(_u('/api/chat/private/users', {'session_key': widget.sessionKey})).timeout(const Duration(seconds: 10)),
        http.get(_u('/api/chat/channels', {'session_key': widget.sessionKey})).timeout(const Duration(seconds: 10)),
      ]);
      final rs = results[0], us = results[1], cs = results[2];
      if (rs.statusCode == 200) {
        final b = jsonDecode(rs.body);
        rooms = ((b is Map ? b['rooms'] : null) as List? ?? const [])
            .whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      }
      if (us.statusCode == 200) {
        final b = jsonDecode(us.body);
        users = ((b is Map ? b['users'] : null) as List? ?? const [])
            .whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      }
      if (cs.statusCode == 200) {
        final b = jsonDecode(cs.body);
        channels = ((b is Map ? b['channels'] : null) as List? ?? const [])
            .whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      }
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  void _open(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) => _load(silent: true));
  }

  Future<void> _newChat() async {
    _open(PrivateChatPage(username: widget.username, sessionKey: widget.sessionKey));
  }

  Future<void> _createGroup() async {
    final name = TextEditingController();
    final desc = TextEditingController();
    final chosen = <String>{};
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _waDarkCard,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (c) => StatefulBuilder(builder: (c, set) {
        return Padding(
          padding: EdgeInsets.fromLTRB(18, 12, 18, MediaQuery.of(c).viewInsets.bottom + 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            _SheetHandle(),
            const SizedBox(height: 10),
            const Text('Grup baru', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            _field(name, 'Nama grup', Icons.groups_rounded),
            const SizedBox(height: 9),
            _field(desc, 'Deskripsi (opsional)', Icons.info_outline_rounded),
            const SizedBox(height: 12),
            const Align(alignment: Alignment.centerLeft, child: Text('Tambah anggota', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700))),
            const SizedBox(height: 6),
            SizedBox(
              height: 190,
              child: ListView(
                children: users.where((u) => '${u['username'] ?? ''}' != widget.username).map((u) {
                  final n = '${u['username'] ?? ''}';
                  return CheckboxListTile(
                    value: chosen.contains(n),
                    onChanged: (v) => set(() => v == true ? chosen.add(n) : chosen.remove(n)),
                    activeColor: _waGreen,
                    title: Text('${u['display_name'] ?? n}', style: const TextStyle(color: Colors.white)),
                    subtitle: Text('@$n', style: const TextStyle(color: _waMuted)),
                    secondary: _Avatar(label: n),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: name.text.trim().isEmpty || chosen.isEmpty ? null : () => Navigator.pop(c, true),
              icon: const Icon(Icons.group_add_rounded), label: const Text('Buat grup'),
            )),
          ]),
        );
      }),
    );
    if (ok == true) {
      try {
        await http.post(_u('/api/chat/group/create'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({
          'session_key': widget.sessionKey, 'name': name.text.trim(), 'description': desc.text.trim(), 'members': chosen.toList(),
        }));
        await _load();
      } catch (_) {}
    }
    name.dispose();
    desc.dispose();
  }

  Future<void> _createChannel() async {
    final name = TextEditingController();
    final desc = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: _waDarkCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Saluran baru', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          _field(name, 'Nama saluran', Icons.campaign_rounded),
          const SizedBox(height: 10),
          _field(desc, 'Deskripsi', Icons.info_outline_rounded),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(c, name.text.trim().isNotEmpty), child: const Text('Buat')),
        ],
      ),
    );
    if (ok == true) {
      try {
        await http.post(_u('/api/chat/channel/create'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({
          'session_key': widget.sessionKey, 'name': name.text.trim(), 'description': desc.text.trim(),
        }));
        await _load();
      } catch (_) {}
    }
    name.dispose();
    desc.dispose();
  }

  InputDecoration _inputDecoration(String hint, IconData icon) => InputDecoration(
    hintText: hint, hintStyle: const TextStyle(color: _waMuted), prefixIcon: Icon(icon, color: _waMuted),
    filled: true, fillColor: const Color(0xFF2A3942), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
  );

  Widget _field(TextEditingController c, String hint, IconData icon) => TextField(controller: c, style: const TextStyle(color: Colors.white), decoration: _inputDecoration(hint, icon));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _waDarkBg,
      appBar: AppBar(
        backgroundColor: _waDarkHeader,
        foregroundColor: Colors.white,
        elevation: 0,
        titleSpacing: 16,
        title: const Text('Chats', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: -.2)),
        actions: [
          IconButton(onPressed: _newChat, tooltip: 'Chat baru', icon: const Icon(Icons.add_comment_outlined)),
          IconButton(onPressed: () => showSearch(context: context, delegate: _ChatSearchDelegate(rooms, channels, users, widget.username, widget.sessionKey)), icon: const Icon(Icons.search_rounded)),
          PopupMenuButton<String>(
            color: _waDarkCard,
            onSelected: (v) { if (v == 'group') _createGroup(); if (v == 'channel') _createChannel(); },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'group', child: ListTile(leading: Icon(Icons.groups_rounded, color: Colors.white), title: Text('Grup baru', style: TextStyle(color: Colors.white)))),
              PopupMenuItem(value: 'channel', child: ListTile(leading: Icon(Icons.campaign_rounded, color: Colors.white), title: Text('Saluran baru', style: TextStyle(color: Colors.white)))),
            ],
          ),
        ],
        bottom: TabBar(
          controller: tabs, indicatorColor: _waGreen, indicatorWeight: 2,
          labelColor: Colors.white, unselectedLabelColor: Colors.white54,
          labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
          tabs: const [
            Tab(text: 'Chats'),
            Tab(text: 'Updates'),
            Tab(text: 'Calls'),
          ],
        ),
      ),
      body: TabBarView(controller: tabs, children: [_chats(), _updates(), _calls()]),
      floatingActionButton: AnimatedBuilder(animation: tabs, builder: (_, __) => FloatingActionButton(
        backgroundColor: _waGreen, foregroundColor: Colors.white, elevation: 5,
        onPressed: tabs.index == 0 ? _newChat : tabs.index == 1 ? _createChannel : _newChat,
        child: Icon(tabs.index == 1 ? Icons.campaign_rounded : Icons.chat_rounded),
      )),
    );
  }

  Widget _chats() {
    final q = search.text.trim().toLowerCase();
    final filteredRooms = rooms.where((r) => q.isEmpty || '${r['name'] ?? ''}'.toLowerCase().contains(q)).toList();
    return RefreshIndicator(
      color: _waGreen,
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.only(top: 6, bottom: 90), children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 7),
          child: TextField(
            controller: search, onChanged: (_) => setState(() {}),
            style: const TextStyle(color: Colors.white),
            decoration: _inputDecoration('Cari chat', Icons.search_rounded),
          ),
        ),
        _chatEntry(icon: Icons.public_rounded, title: 'Chat Global', subtitle: 'Ruang publik darg ligh', onTap: () => _open(GlobalChatPage(username: widget.username, sessionKey: widget.sessionKey))),
        _chatEntry(icon: Icons.lock_rounded, title: 'Chat Privat', subtitle: 'Pesan pribadi, media, VN & panggilan', onTap: _newChat),
        _chatEntry(icon: Icons.auto_awesome_rounded, title: 'darg ligh AI', subtitle: 'Asisten AI', onTap: () => _open(AiChatPage(username: widget.username, sessionKey: widget.sessionKey))),
        if (filteredRooms.isNotEmpty) ...[
          const _SectionLabel('GRUP & SALURAN'),
          ...filteredRooms.map(_roomTile),
        ],
        if (!loading && filteredRooms.isEmpty) const _EmptyState(icon: Icons.chat_bubble_outline_rounded, title: 'Belum ada percakapan lain', subtitle: 'Mulai chat baru atau buat grup.'),
      ]),
    );
  }

  Widget _chatEntry({required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) => ListTile(
    onTap: onTap,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
    leading: CircleAvatar(radius: 27, backgroundColor: const Color(0xFF128C7E), child: Icon(icon, color: Colors.white, size: 22)),
    title: Row(children: [
      Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700))),
    ]),
    subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _waMuted, fontSize: 13)),
  );

  Widget _roomTile(Map<String, dynamic> r) {
    final isCh = r['type'] == 'channel';
    final last = '${r['last_message'] ?? ''}'.trim();
    final when = _roomTime(r['last_message_at']);
    return ListTile(
      onTap: () => _open(RoomChatPage(username: widget.username, sessionKey: widget.sessionKey, room: r)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
      leading: CircleAvatar(radius: 27, backgroundColor: isCh ? const Color(0xFF075E54) : const Color(0xFF128C7E), child: Icon(isCh ? Icons.campaign_rounded : Icons.groups_rounded, color: Colors.white, size: 22)),
      title: Row(children: [
        Expanded(child: Text('${r['name'] ?? 'Room'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700))),
        if (when.isNotEmpty) Text(when, style: const TextStyle(color: _waMuted, fontSize: 11)),
      ]),
      subtitle: Row(children: [
        if (isCh) const Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.campaign_outlined, size: 14, color: _waMuted)),
        Expanded(child: Text(last.isNotEmpty ? last : '${r['members_count'] ?? 0} ${isCh ? 'pengikut' : 'anggota'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _waMuted, fontSize: 13))),
      ]),
    );
  }

  String _roomTime(dynamic value) {
    final d = DateTime.tryParse(value?.toString() ?? '')?.toLocal();
    if (d == null) return '';
    final now = DateTime.now();
    if (d.year == now.year && d.month == now.month && d.day == now.day) return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return '${d.day}/${d.month}';
  }

  Widget _updates() => ListView(padding: const EdgeInsets.only(top: 8, bottom: 90), children: [
    const _SectionLabel('STATUS'),
    ListTile(
      onTap: () => _open(StoryPage(sessionKey: widget.sessionKey, username: widget.username)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
      leading: Stack(children: [const CircleAvatar(radius: 27, backgroundColor: Color(0xFF667781), child: Icon(Icons.person, color: Colors.white)), Positioned(right: 0, bottom: 0, child: Container(width: 20, height: 20, decoration: const BoxDecoration(color: _waGreen, shape: BoxShape.circle), child: const Icon(Icons.add, size: 16, color: Colors.white)))]),
      title: const Text('Status saya', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      subtitle: const Text('Tambahkan status foto atau video', style: TextStyle(color: _waMuted)),
    ),
    const _SectionLabel('SALURAN'),
    if (channels.isEmpty) const _EmptyState(icon: Icons.campaign_outlined, title: 'Belum ada saluran', subtitle: 'Buat saluran untuk mulai berbagi update.'),
    ...channels.map(_channelTile),
  ]);

  Widget _channelTile(Map<String, dynamic> r) {
    final following = r['is_member'] == true || (r['members'] is List && (r['members'] as List).contains(widget.username));
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      leading: const CircleAvatar(radius: 27, backgroundColor: Color(0xFF128C7E), child: Icon(Icons.campaign_rounded, color: Colors.white)),
      title: Text('${r['name'] ?? 'Saluran'}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      subtitle: Text('${r['members_count'] ?? 0} pengikut • ${r['description'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _waMuted)),
      trailing: following ? OutlinedButton(onPressed: () => _open(RoomChatPage(username: widget.username, sessionKey: widget.sessionKey, room: r)), child: const Text('Buka')) : FilledButton(
        onPressed: () async { try { final x = await http.post(_u('/api/chat/channel/follow'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'session_key': widget.sessionKey, 'room_id': r['id']})); if (x.statusCode < 300) await _load(); } catch (_) {} },
        child: const Text('Ikuti'),
      ),
    );
  }

  Widget _calls() => ListView(padding: const EdgeInsets.only(top: 8, bottom: 90), children: [
    ListTile(
      onTap: _newChat,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: const CircleAvatar(radius: 27, backgroundColor: _waGreen, child: Icon(Icons.add_call, color: Colors.white)),
      title: const Text('Buat panggilan baru', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      subtitle: const Text('Pilih kontak dari Chat Privat', style: TextStyle(color: _waMuted)),
    ),
    const _SectionLabel('PANGGILAN'),
    const _EmptyState(icon: Icons.call_outlined, title: 'Belum ada riwayat panggilan', subtitle: 'Riwayat panggilan akan muncul di sini.'),
  ]);
}

class _SheetHandle extends StatelessWidget { @override Widget build(BuildContext context) => Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))); }
class _SectionLabel extends StatelessWidget { final String text; const _SectionLabel(this.text); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(16, 15, 16, 7), child: Text(text, style: const TextStyle(color: _waGreen, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: .6))); }
class _Avatar extends StatelessWidget { final String label; const _Avatar({required this.label}); @override Widget build(BuildContext context) { final x = label.trim(); return CircleAvatar(backgroundColor: const Color(0xFF128C7E), child: Text(x.isEmpty ? '?' : x[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))); } }
class _EmptyState extends StatelessWidget { final IconData icon; final String title; final String subtitle; const _EmptyState({required this.icon, required this.title, required this.subtitle}); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(34), child: Column(children: [Icon(icon, color: _waMuted, size: 42), const SizedBox(height: 10), Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)), const SizedBox(height: 4), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: _waMuted, fontSize: 13))])); }

class _ChatSearchDelegate extends SearchDelegate<String> {
  final List<Map<String, dynamic>> rooms;
  final List<Map<String, dynamic>> channels;
  final List<Map<String, dynamic>> users;
  final String username;
  final String sessionKey;
  _ChatSearchDelegate(this.rooms, this.channels, this.users, this.username, this.sessionKey);
  @override List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext context) => _results(context);
  @override Widget buildSuggestions(BuildContext context) => _results(context);
  Widget _results(BuildContext context) {
    final q = query.trim().toLowerCase();
    final r = rooms.where((x) => '${x['name'] ?? ''}'.toLowerCase().contains(q));
    final c = channels.where((x) => '${x['name'] ?? ''}'.toLowerCase().contains(q));
    final u = users.where((x) => '${x['username'] ?? ''}'.toLowerCase().contains(q) || '${x['display_name'] ?? ''}'.toLowerCase().contains(q));
    return ListView(children: [
      ...u.map((x) => ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text('${x['display_name'] ?? x['username']}'), subtitle: Text('@${x['username'] ?? ''}'))),
      ...r.map((x) => ListTile(leading: const CircleAvatar(child: Icon(Icons.groups)), title: Text('${x['name'] ?? ''}'), subtitle: const Text('Grup'), onTap: () => close(context, '${x['id'] ?? ''}'))),
      ...c.map((x) => ListTile(leading: const CircleAvatar(child: Icon(Icons.campaign)), title: Text('${x['name'] ?? ''}'), subtitle: const Text('Saluran'), onTap: () => close(context, '${x['id'] ?? ''}'))),
    ]);
  }
}
