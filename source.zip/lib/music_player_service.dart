import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

/// Base API musik (YouTube search + stream via ikyyxd).
const String kMusicApiBase = 'https://api.ikyyxd.my.id';
const String kMusicApiKey = 'kyzz';

/// Track dari API search/youtube atau hasil play ytplayv3.
class MusicTrack {
  final String? id;
  final String title;
  final String artist;
  final String? artwork;
  final String? previewUrl;
  final int? durationMs;
  final String? sourceUrl;
  final String? uri;
  final String? durationLabel;

  const MusicTrack({
    this.id,
    required this.title,
    required this.artist,
    this.artwork,
    this.previewUrl,
    this.durationMs,
    this.sourceUrl,
    this.uri,
    this.durationLabel,
  });

  bool get hasPreview => previewUrl != null && previewUrl!.isNotEmpty;

  /// Identity untuk menandai baris yang sedang diputar.
  String get key => id ?? sourceUrl ?? previewUrl ?? '$title|$artist';

  Map<String, dynamic> toJson() => {
        if (id != null) 'id': id,
        'title': title,
        'artist': artist,
        if (artwork != null) 'artwork': artwork,
        // previewUrl/stream tidak disimpan (URL cepat expired)
        if (durationMs != null) 'durationMs': durationMs,
        if (sourceUrl != null) 'sourceUrl': sourceUrl,
        if (uri != null) 'uri': uri,
        if (durationLabel != null) 'durationLabel': durationLabel,
      };

  factory MusicTrack.fromJson(Map<String, dynamic> json) => MusicTrack(
        id: _str(json['id']),
        title: (json['title'] ?? 'Unknown').toString().trim(),
        artist: (json['artist'] ?? 'Unknown').toString().trim(),
        artwork: _validUrl(json['artwork']?.toString()),
        previewUrl: _validUrl(json['previewUrl']?.toString()),
        durationMs: json['durationMs'] is num
            ? (json['durationMs'] as num).round()
            : null,
        sourceUrl: _validUrl(json['sourceUrl']?.toString()),
        uri: _str(json['uri']),
        durationLabel: _str(json['durationLabel']),
      );

  factory MusicTrack.fromYoutubeSearch(Map<String, dynamic> item) {
    final link = _str(item['link']);
    final id = _youtubeIdFromLink(link) ?? _str(item['id']);
    final durationLabel = _str(item['duration']);
    return MusicTrack(
      id: id,
      title: (item['title'] ?? 'Unknown').toString().trim(),
      artist: (item['channel'] ?? item['artist'] ?? 'Unknown').toString().trim(),
      artwork: _validUrl(item['imageUrl']?.toString() ?? item['thumbnail']?.toString()),
      sourceUrl: _validUrl(link),
      durationLabel: durationLabel,
      durationMs: _parseDurationLabel(durationLabel),
    );
  }

  factory MusicTrack.fromPlayResult(Map<String, dynamic> result, {MusicTrack? base}) {
    final audio = result['audio'];
    String? stream;
    if (audio is Map) {
      stream = _validUrl(audio['url']?.toString()) ??
          _validUrl(audio['download']?.toString());
    } else if (audio is String) {
      stream = _validUrl(audio);
    }
    stream ??= _validUrl(result['download']?.toString());
    stream ??= _validUrl(result['url']?.toString());
    stream ??= _validUrl(result['media']?.toString());
    stream ??= _validUrl(result['mp3']?.toString());
    // kadang list of links
    if (stream == null) {
      final links = result['links'] ?? result['formats'];
      if (links is List) {
        for (final item in links) {
          if (item is String) {
            stream = _validUrl(item);
          } else if (item is Map) {
            stream = _validUrl(item['url']?.toString()) ??
                _validUrl(item['download']?.toString());
          }
          if (stream != null) break;
        }
      }
    }

    final dur = result['duration'];
    int? durationMs;
    if (dur is num) {
      durationMs = (dur * 1000).round();
    } else if (dur is String) {
      durationMs = _parseDurationLabel(dur);
    }

    final source = _validUrl(result['source']?.toString()) ?? base?.sourceUrl;
    final id = _str(result['id']) ??
        _youtubeIdFromLink(source) ??
        base?.id;

    return MusicTrack(
      id: id,
      title: (result['title'] ?? base?.title ?? 'Unknown').toString().trim(),
      artist: (result['channel'] ?? result['artist'] ?? base?.artist ?? 'YouTube')
          .toString()
          .trim(),
      artwork: _validUrl(result['thumbnail']?.toString()) ?? base?.artwork,
      previewUrl: stream,
      durationMs: durationMs ?? base?.durationMs,
      sourceUrl: source,
      durationLabel: base?.durationLabel,
    );
  }

  static String? _str(Object? v) {
    final s = v?.toString().trim();
    return (s == null || s.isEmpty) ? null : s;
  }

  static String? _validUrl(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final uri = Uri.tryParse(value.trim());
    if (uri == null ||
        !(uri.scheme == 'https' || uri.scheme == 'http') ||
        uri.host.isEmpty) {
      return null;
    }
    return uri.toString();
  }

  static String? _youtubeIdFromLink(String? link) {
    if (link == null || link.isEmpty) return null;
    final uri = Uri.tryParse(link);
    if (uri == null) return null;
    if (uri.host.contains('youtu.be')) {
      final seg = uri.pathSegments;
      return seg.isNotEmpty ? seg.first : null;
    }
    return uri.queryParameters['v'];
  }

  /// "3:31" / "1:09:02" → milliseconds
  static int? _parseDurationLabel(String? label) {
    if (label == null || label.isEmpty) return null;
    final parts = label.split(':').map((e) => int.tryParse(e.trim())).toList();
    if (parts.any((e) => e == null)) return null;
    if (parts.length == 2) {
      return (parts[0]! * 60 + parts[1]!) * 1000;
    }
    if (parts.length == 3) {
      return (parts[0]! * 3600 + parts[1]! * 60 + parts[2]!) * 1000;
    }
    return null;
  }
}

class MusicPlayerController extends ChangeNotifier {
  MusicPlayerController._() {
    _stateSub = _player.onPlayerStateChanged.listen((state) {
      _playing = state == PlayerState.playing;
      notifyListeners();
    });
    _durationSub = _player.onDurationChanged.listen((duration) {
      _duration = duration;
      notifyListeners();
    });
    _positionSub = _player.onPositionChanged.listen((position) {
      _position = position;
      notifyListeners();
    });
    _completeSub = _player.onPlayerComplete.listen((_) {
      _playing = false;
      _position = Duration.zero;
      notifyListeners();
    });
  }

  static final MusicPlayerController instance = MusicPlayerController._();

  final AudioPlayer _player = AudioPlayer();
  final List<MusicTrack> _results = <MusicTrack>[];
  Timer? _debounce;
  StreamSubscription<PlayerState>? _stateSub;
  StreamSubscription<Duration>? _durationSub;
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<void>? _completeSub;

  bool _playing = false;
  bool _loading = false;
  bool _searching = false;
  bool _apiConnected = true;
  String _query = '';
  String? _error;
  MusicTrack? _current;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  int _searchGeneration = 0;

  List<MusicTrack> get results => List.unmodifiable(_results);
  bool get playing => _playing;
  bool get loading => _loading;
  bool get searching => _searching;
  bool get apiConnected => _apiConnected;
  String get query => _query;
  String? get error => _error;
  MusicTrack? get current => _current;
  Duration get position => _position;
  Duration get duration => _duration;

  double get progress {
    if (_duration.inMilliseconds <= 0) return 0;
    return (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0);
  }

  void scheduleSearch(String value) {
    _query = value.trim();
    _debounce?.cancel();
    if (_query.isEmpty) {
      _results.clear();
      _error = null;
      notifyListeners();
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 700), () => search(_query));
  }

  Future<bool> checkApiConnection() async {
    try {
      final uri = Uri.parse('$kMusicApiBase/search/youtube').replace(
        queryParameters: <String, String>{
          'apikey': kMusicApiKey,
          'query': 'test',
        },
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 8));
      final ok = response.statusCode == 200;
      _apiConnected = ok;
      notifyListeners();
      return ok;
    } catch (_) {
      _apiConnected = false;
      notifyListeners();
      return false;
    }
  }

  /// Cari lagu via YouTube search API.
  Future<int> search(String value) async {
    final query = value.trim();
    if (query.isEmpty) return 0;

    final generation = ++_searchGeneration;
    _query = query;
    _searching = true;
    _error = null;
    notifyListeners();

    var found = 0;
    try {
      final uri = Uri.parse('$kMusicApiBase/search/youtube').replace(
        queryParameters: <String, String>{
          'apikey': kMusicApiKey,
          'query': query,
        },
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 20));

      Map<String, dynamic>? body;
      try {
        final decoded = jsonDecode(response.body);
        if (decoded is Map<String, dynamic>) body = decoded;
      } catch (_) {}

      if (response.statusCode != 200 || body == null || body['status'] != true) {
        _apiConnected = response.statusCode != 0;
        throw _MusicException(
          (body?['error'] ?? body?['message'] ?? 'Gagal mencari lagu (HTTP ${response.statusCode}).')
              .toString(),
        );
      }
      _apiConnected = true;

      final raw = body['result'];
      final tracks = (raw is List ? raw : const <dynamic>[])
          .whereType<Map<String, dynamic>>()
          .map(MusicTrack.fromYoutubeSearch)
          .toList(growable: false);

      if (generation != _searchGeneration) return 0;
      _results
        ..clear()
        ..addAll(tracks);
      found = tracks.length;
      if (tracks.isEmpty) {
        _error = 'Lagu tidak ditemukan. Coba judul atau nama artis lain.';
      }
    } on _MusicException catch (e) {
      if (generation == _searchGeneration) _error = e.message;
    } on TimeoutException {
      if (generation == _searchGeneration) {
        _error = 'Koneksi terlalu lama. Coba lagi.';
      }
    } catch (_) {
      if (generation == _searchGeneration) {
        _error = 'Gagal mencari lagu. Periksa koneksi internet.';
      }
    } finally {
      if (generation == _searchGeneration) {
        _searching = false;
        notifyListeners();
      }
    }
    return found;
  }

  /// Cari lalu putar hasil pertama (dengan stream audio).
  Future<MusicTrack?> searchAndPlay(String value) async {
    final found = await search(value);
    if (found == 0 || _results.isEmpty) return null;
    final target = _results.first;
    await play(target);
    return target;
  }

  /// Resolve stream URL: coba ytplayv3 → ytplayv2 → ytplay, lalu putar di app.
  Future<bool> play(MusicTrack track) async {
    _loading = true;
    _error = null;
    notifyListeners();
    var started = false;

    try {
      // Jika track sudah punya stream URL valid, langsung putar.
      String? stream = track.hasPreview ? track.previewUrl : null;

      if (stream == null || stream.isEmpty) {
        final q = track.title.isNotEmpty
            ? track.title
            : (track.id ?? track.sourceUrl ?? '');
        if (q.isEmpty) {
          throw const _MusicException('Tidak ada query untuk memutar lagu.');
        }

        final resolved = await _resolveStream(q, base: track);
        if (resolved == null ||
            resolved.previewUrl == null ||
            resolved.previewUrl!.isEmpty) {
          throw const _MusicException(
            'Audio stream tidak tersedia (ytplayv3/v2/v1 gagal).',
          );
        }
        stream = resolved.previewUrl;
        track = resolved;
      }

      final sameTrack = _current?.key == track.key && _position < _duration;
      if (sameTrack) {
        await _player.resume();
      } else {
        await _player.stop();
        _current = track;
        _position = Duration.zero;
        _duration = track.durationMs != null
            ? Duration(milliseconds: track.durationMs!)
            : Duration.zero;
        await _player.setReleaseMode(ReleaseMode.stop);
        await _player.setPlayerMode(PlayerMode.mediaPlayer);
        await _player.play(UrlSource(stream!));
      }
      _playing = true;
      started = true;
    } on _MusicException catch (e) {
      _playing = false;
      _error = e.message;
    } on TimeoutException {
      _playing = false;
      _error = 'Mengambil audio terlalu lama. Coba lagi.';
    } catch (_) {
      _playing = false;
      _error = 'Lagu gagal diputar. Coba lagu lain.';
    } finally {
      _loading = false;
      notifyListeners();
    }
    return started;
  }

  /// Urutan: ytplayv3 → ytplayv2 → ytplay. Ambil yang pertama berhasil.
  Future<MusicTrack?> _resolveStream(String query, {MusicTrack? base}) async {
    const endpoints = <String>[
      'ytplayv3',
      'ytplayv2',
      'ytplay',
    ];

    for (final name in endpoints) {
      try {
        final uri = Uri.parse('$kMusicApiBase/search/$name').replace(
          queryParameters: <String, String>{'q': query},
        );
        final response =
            await http.get(uri).timeout(const Duration(seconds: 25));
        if (response.statusCode != 200) continue;

        Map<String, dynamic>? body;
        try {
          final decoded = jsonDecode(response.body);
          if (decoded is Map<String, dynamic>) {
            body = decoded;
          } else if (decoded is Map) {
            body = Map<String, dynamic>.from(decoded);
          }
        } catch (_) {
          continue;
        }
        if (body == null) continue;

        // status false / error message → coba endpoint berikutnya
        final status = body['status'];
        if (status == false || status == 'false') continue;

        final resultMap = _extractPlayResultMap(body);
        if (resultMap == null) continue;

        final resolved = MusicTrack.fromPlayResult(resultMap, base: base);
        if (resolved.hasPreview) return resolved;
      } on TimeoutException {
        // coba endpoint berikutnya
        continue;
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  /// Normalisasi body dari berbagai bentuk ytplay / ytplayv2 / ytplayv3.
  Map<String, dynamic>? _extractPlayResultMap(Map<String, dynamic> body) {
    final result = body['result'];
    if (result is Map<String, dynamic>) return result;
    if (result is Map) return Map<String, dynamic>.from(result);

    // Kadang result = list → ambil item pertama
    if (result is List && result.isNotEmpty) {
      final first = result.first;
      if (first is Map<String, dynamic>) return first;
      if (first is Map) return Map<String, dynamic>.from(first);
    }

    // Kadang field stream ada di root
    if (body.containsKey('download') ||
        body.containsKey('audio') ||
        body.containsKey('url')) {
      return body;
    }
    return null;
  }

  /// Buka link YouTube di browser / app eksternal.
  Future<void> openInYoutube(MusicTrack track) async {
    final link = track.sourceUrl ??
        (track.id != null ? 'https://youtube.com/watch?v=${track.id}' : null);
    if (link == null) {
      _error = 'Lagu ini tidak punya tautan YouTube.';
      notifyListeners();
      return;
    }
    try {
      final ok =
          await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
      _error = ok ? null : 'Tidak bisa membuka YouTube.';
    } catch (_) {
      _error = 'Tidak bisa membuka YouTube.';
    }
    notifyListeners();
  }

  /// Alias lama (overlay masih memanggil openInSpotify di beberapa tempat).
  Future<void> openInSpotify(MusicTrack track) => openInYoutube(track);

  Future<void> toggle() async {
    if (_current == null || _loading) return;
    try {
      if (_playing) {
        await _player.pause();
        _playing = false;
      } else {
        await _player.resume();
        _playing = true;
      }
    } catch (_) {
      _error = 'Player tidak dapat dilanjutkan.';
      _playing = false;
    }
    notifyListeners();
  }

  Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
    _playing = false;
    _position = Duration.zero;
    _current = null;
    notifyListeners();
  }

  Future<void> seek(double value) async {
    if (_duration.inMilliseconds <= 0) return;
    final clamped = value.clamp(0.0, 1.0);
    final target =
        Duration(milliseconds: (_duration.inMilliseconds * clamped).round());
    try {
      await _player.seek(target);
    } catch (_) {}
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _stateSub?.cancel();
    _durationSub?.cancel();
    _positionSub?.cancel();
    _completeSub?.cancel();
    _player.dispose();
    super.dispose();
  }
}

class _MusicException implements Exception {
  final String message;
  const _MusicException(this.message);
}
