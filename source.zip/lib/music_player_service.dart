import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import 'api_config.dart' as api_config;

/// A track returned by the Spotify Web API (developer.spotify.com), fetched
/// through the backend proxy `/api/spotify/search` so the Client Secret never
/// ships inside the app.
///
/// [previewUrl] is Spotify's 30-second preview. Spotify no longer fills it for
/// apps created after 27 Nov 2024, so it is often null. A track without a
/// preview cannot be played inside the app and is opened in Spotify instead.
class MusicTrack {
  final String? id;
  final String title;
  final String artist;
  final String? artwork;
  final String? previewUrl;
  final int? durationMs;
  final String? sourceUrl;
  final String? uri;

  const MusicTrack({
    this.id,
    required this.title,
    required this.artist,
    this.artwork,
    this.previewUrl,
    this.durationMs,
    this.sourceUrl,
    this.uri,
  });

  bool get hasPreview => previewUrl != null && previewUrl!.isNotEmpty;

  /// Stable identity used to tell which row is the one currently playing.
  String get key => id ?? previewUrl ?? '$title|$artist';

  factory MusicTrack.fromApi(Map<String, dynamic> item) => MusicTrack(
        id: _str(item['id']),
        title: (item['title'] ?? 'Unknown').toString().trim(),
        artist: (item['artist'] ?? 'Unknown Artist').toString().trim(),
        artwork: _validUrl(item['artwork']?.toString()),
        previewUrl: _validUrl(item['previewUrl']?.toString()),
        durationMs:
            item['durationMs'] is num ? (item['durationMs'] as num).round() : null,
        sourceUrl: _validUrl(item['sourceUrl']?.toString()),
        uri: _str(item['uri']),
      );

  static String? _str(Object? v) {
    final s = v?.toString().trim();
    return (s == null || s.isEmpty) ? null : s;
  }

  static String? _validUrl(String? value) {
    if (value == null || value.trim().isEmpty) return null;
    final uri = Uri.tryParse(value.trim());
    if (uri == null ||
        !(uri.scheme == 'https' || uri.scheme == 'http') ||
        uri.host.isEmpty) {
      return null;
    }
    return uri.toString();
  }
}

class MusicPlayerController extends ChangeNotifier {
  MusicPlayerController._() {
    _stateSub = _player.onPlayerStateChanged.listen((state) {
      _playing = state == PlayerState.playing;
      notifyListeners();
    });
    _durationSub = _player.onDurationChanged.listen((duration) {
      _duration = duration;
      notifyListeners();
    });
    _positionSub = _player.onPositionChanged.listen((position) {
      _position = position;
      notifyListeners();
    });
    _completeSub = _player.onPlayerComplete.listen((_) {
      _playing = false;
      _position = Duration.zero;
      notifyListeners();
    });
  }

  static final MusicPlayerController instance = MusicPlayerController._();

  final AudioPlayer _player = AudioPlayer();
  final List<MusicTrack> _results = <MusicTrack>[];
  Timer? _debounce;
  StreamSubscription<PlayerState>? _stateSub;
  StreamSubscription<Duration>? _durationSub;
  StreamSubscription<Duration>? _positionSub;
  StreamSubscription<void>? _completeSub;

  bool _playing = false;
  bool _loading = false;
  bool _searching = false;
  bool _apiConnected = false;
  String _query = '';
  String? _error;
  MusicTrack? _current;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  int _searchGeneration = 0;

  List<MusicTrack> get results => List.unmodifiable(_results);
  bool get playing => _playing;
  bool get loading => _loading;
  bool get searching => _searching;

  /// True when the backend answered and has Spotify credentials configured.
  bool get apiConnected => _apiConnected;
  String get query => _query;

  /// Last message for the user (error or a hint such as "opened in Spotify").
  String? get error => _error;
  MusicTrack? get current => _current;
  Duration get position => _position;
  Duration get duration => _duration;

  double get progress {
    if (_duration.inMilliseconds <= 0) return 0;
    return (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0);
  }

  void scheduleSearch(String value) {
    _query = value.trim();
    _debounce?.cancel();
    if (_query.isEmpty) {
      _results.clear();
      _error = null;
      notifyListeners();
      return;
    }
    // Spotify is rate limited, so wait until the user pauses typing.
    _debounce = Timer(const Duration(milliseconds: 800), () => search(_query));
  }

  Future<bool> checkApiConnection() async {
    try {
      final uri = Uri.parse('${api_config.baseUrl}/api/spotify/health');
      final response = await http.get(uri).timeout(const Duration(seconds: 5));
      final decoded = jsonDecode(response.body);
      final ok = response.statusCode == 200 &&
          decoded is Map<String, dynamic> &&
          decoded['valid'] == true &&
          decoded['configured'] == true;
      _apiConnected = ok;
      notifyListeners();
      return ok;
    } catch (_) {
      _apiConnected = false;
      notifyListeners();
      return false;
    }
  }

  /// Searches Spotify. Returns the number of tracks found (0 on error).
  Future<int> search(String value) async {
    final query = value.trim();
    if (query.isEmpty) return 0;

    final generation = ++_searchGeneration;
    _query = query;
    _searching = true;
    _error = null;
    notifyListeners();

    var found = 0;
    try {
      final uri = Uri.parse('${api_config.baseUrl}/api/spotify/search').replace(
        queryParameters: <String, String>{'q': query, 'limit': '10'},
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 15));

      Map<String, dynamic>? body;
      try {
        final decoded = jsonDecode(response.body);
        if (decoded is Map<String, dynamic>) body = decoded;
      } catch (_) {}

      if (response.statusCode != 200 || body == null || body['valid'] != true) {
        _apiConnected = response.statusCode != 503;
        throw _MusicException(
          (body?['message'] ?? 'Spotify tidak dapat dihubungi (HTTP ${response.statusCode}).')
              .toString(),
        );
      }
      _apiConnected = true;

      final raw = body['results'];
      final tracks = (raw is List ? raw : const <dynamic>[])
          .whereType<Map<String, dynamic>>()
          .map(MusicTrack.fromApi)
          .toList(growable: false);

      if (generation != _searchGeneration) return 0;
      _results
        ..clear()
        ..addAll(tracks);
      found = tracks.length;
      if (tracks.isEmpty) {
        _error = 'Lagu tidak ditemukan. Coba judul atau nama artis lain.';
      }
    } on _MusicException catch (e) {
      if (generation == _searchGeneration) _error = e.message;
    } on TimeoutException {
      if (generation == _searchGeneration) {
        _error = 'Koneksi terlalu lama. Coba lagi.';
      }
    } catch (_) {
      if (generation == _searchGeneration) {
        _error = 'Gagal mencari lagu. Periksa koneksi internet.';
      }
    } finally {
      if (generation == _searchGeneration) {
        _searching = false;
        notifyListeners();
      }
    }
    return found;
  }

  /// "CARI & PUTAR": search, then play the first result that has an in-app
  /// preview. If none has one, the top result is opened in Spotify instead.
  Future<MusicTrack?> searchAndPlay(String value) async {
    final found = await search(value);
    if (found == 0 || _results.isEmpty) return null;
    final target =
        _results.firstWhere((t) => t.hasPreview, orElse: () => _results.first);
    await play(target);
    return target;
  }

  /// Plays [track] inside the app when Spotify gave a preview, otherwise opens
  /// it in the Spotify app/website. Returns true if audio started in the app.
  Future<bool> play(MusicTrack track) async {
    if (!track.hasPreview) {
      await openInSpotify(track);
      return false;
    }

    final url = track.previewUrl!;
    _loading = true;
    _error = null;
    notifyListeners();
    var started = false;
    try {
      final sameTrack = _current?.key == track.key && _position < _duration;
      if (sameTrack) {
        await _player.resume();
      } else {
        await _player.stop();
        _current = track;
        _position = Duration.zero;
        _duration = Duration.zero;
        await _player.setReleaseMode(ReleaseMode.stop);
        await _player.setPlayerMode(PlayerMode.mediaPlayer);
        await _player.play(UrlSource(url));
      }
      _playing = true;
      started = true;
    } catch (_) {
      _playing = false;
      _error = 'Lagu gagal diputar. Coba lagu lain.';
    } finally {
      _loading = false;
      notifyListeners();
    }
    return started;
  }

  /// Opens the track in the Spotify app (or open.spotify.com if not installed).
  Future<void> openInSpotify(MusicTrack track) async {
    final link = track.sourceUrl ??
        (track.id != null ? 'https://open.spotify.com/track/${track.id}' : null);
    if (link == null) {
      _error = 'Lagu ini tidak punya tautan Spotify.';
      notifyListeners();
      return;
    }
    try {
      final ok = await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
      _error = ok
          ? 'Lagu ini tidak punya preview, jadi dibuka di Spotify.'
          : 'Tidak bisa membuka Spotify.';
    } catch (_) {
      _error = 'Tidak bisa membuka Spotify.';
    }
    notifyListeners();
  }

  Future<void> toggle() async {
    if (_current == null || _loading) return;
    try {
      if (_playing) {
        await _player.pause();
        _playing = false;
      } else {
        await _player.resume();
        _playing = true;
      }
    } catch (_) {
      _error = 'Player tidak dapat dilanjutkan.';
      _playing = false;
    }
    notifyListeners();
  }

  Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
    _playing = false;
    _position = Duration.zero;
    _current = null;
    notifyListeners();
  }

  Future<void> seek(double value) async {
    if (_duration.inMilliseconds <= 0) return;
    final clamped = value.clamp(0.0, 1.0);
    final target =
        Duration(milliseconds: (_duration.inMilliseconds * clamped).round());
    try {
      await _player.seek(target);
    } catch (_) {}
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _stateSub?.cancel();
    _durationSub?.cancel();
    _positionSub?.cancel();
    _completeSub?.cancel();
    _player.dispose();
    super.dispose();
  }
}

class _MusicException implements Exception {
  final String message;
  const _MusicException(this.message);
}
