import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/scheduler.dart';

/// DarkLight Football V6 — a self-contained, touch-first 2.5D football mode.
/// The football module is isolated to this file so the rest of the app stays intact.
class FootballGamePage extends StatefulWidget {
  const FootballGamePage({super.key});
  @override
  State<FootballGamePage> createState() => _FootballGamePageState();
}

class _FootballGamePageState extends State<FootballGamePage>
    with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  Duration? _last;
  final _game = _FootballGame();
  Offset _stick = Offset.zero;
  Offset? _stickStart;
  bool _sprint = false;
  bool _started = false;
  bool _paused = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _ticker = createTicker((elapsed) {
      final previous = _last ?? elapsed;
      final dt = ((elapsed - previous).inMicroseconds / 1000000.0)
          .clamp(0.0, 0.033)
          .toDouble();
      _last = elapsed;
      if (_started && !_paused) {
        _game.setInput(_stick, _sprint);
        _game.update(dt);
      }
      if (mounted) setState(() {});
    })..start();
  }

  @override
  void dispose() {
    _ticker.dispose();
    SystemChrome.setPreferredOrientations(const [DeviceOrientation.portraitUp]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _start() => setState(() {
        _started = true;
        _game.banner = 'KICK OFF';
        _game.bannerT = 1.2;
      });

  void _reset() => setState(() {
        _game.reset();
        _started = false;
        _paused = false;
        _stick = Offset.zero;
        _sprint = false;
      });

  void _action(VoidCallback action) {
    if (!_started || _paused) return;
    action();
    setState(() {});
  }

  void _openSquad() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF081015),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              const Expanded(
                child: Text('SQUAD • GANTI PEMAIN',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              ),
              Text('${_game.home.length} ON FIELD',
                  style: const TextStyle(color: Colors.white38, fontSize: 9)),
            ]),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: List.generate(_game.home.length - 1, (i) {
                final p = _game.home[i];
                return ChoiceChip(
                  label: Text('#${p.number}  ${p.name}'),
                  selected: i == _game.active,
                  onSelected: (_) {
                    setState(() => _game.active = i);
                    Navigator.pop(ctx);
                  },
                  selectedColor: const Color(0xFF42E3A5),
                  backgroundColor: Colors.white.withOpacity(.07),
                  labelStyle: TextStyle(
                    color: i == _game.active ? Colors.black : Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                );
              }),
            ),
          ]),
        ),
      ),
    );
  }

  void _openStadiums() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF081015),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('STADIUM SELECT',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: List.generate(_stadiums.length, (i) {
                final s = _stadiums[i];
                return ChoiceChip(
                  label: Text(s.name),
                  selected: i == _game.stadium,
                  onSelected: (_) {
                    setState(() => _game.stadium = i);
                    Navigator.pop(ctx);
                  },
                  selectedColor: s.accent,
                  backgroundColor: Colors.white.withOpacity(.07),
                  labelStyle: TextStyle(
                    color: i == _game.stadium ? Colors.black : Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                );
              }),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: LayoutBuilder(builder: (context, box) {
          final size = Size(box.maxWidth, box.maxHeight);
          return Stack(children: [
            Positioned.fill(child: CustomPaint(painter: _FootballPainter(_game))),
            if (_started) ...[
              _hud(size),
              _joystick(size),
              _actions(size),
            ] else
              _preMatch(size),
          ]);
        }),
      ),
    );
  }

  Widget _hud(Size size) {
    return Positioned(
      top: 7,
      left: 10,
      right: 10,
      child: Row(children: [
        _hudButton(Icons.close_rounded, 'EXIT', () => Navigator.maybePop(context)),
        const SizedBox(width: 6),
        _score('DarkLight FC', _game.userScore, const Color(0xFF5CF0BA)),
        Expanded(
          child: Column(children: [
            Text(_game.clockText,
                style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
            Text('${_game.stadiumName}  •  MATCH DAY',
                style: const TextStyle(color: Colors.white54, fontSize: 7, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          ]),
        ),
        _score('CPU', _game.cpuScore, const Color(0xFFFF687B)),
        const SizedBox(width: 6),
        _hudButton(Icons.groups_rounded, 'SQUAD', _openSquad),
        const SizedBox(width: 4),
        _hudButton(Icons.stadium_rounded, 'STADIUM', _openStadiums),
        const SizedBox(width: 4),
        _hudButton(_paused ? Icons.play_arrow_rounded : Icons.pause_rounded, '', () => setState(() => _paused = !_paused)),
        const SizedBox(width: 4),
        _hudButton(Icons.restart_alt_rounded, '', _reset),
      ]),
    );
  }

  Widget _score(String label, int score, Color accent) => Container(
        width: 72,
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 6),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(.70),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: accent.withOpacity(.34)),
        ),
        child: Column(children: [
          Text(label, style: TextStyle(color: accent, fontSize: 7, fontWeight: FontWeight.w900)),
          Text('$score', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
        ]),
      );

  Widget _hudButton(IconData icon, String label, VoidCallback tap) => Material(
        color: Colors.black.withOpacity(.62),
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: tap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, color: Colors.white, size: 16),
              if (label.isNotEmpty) ...[
                const SizedBox(width: 4),
                Text(label, style: const TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.w900)),
              ],
            ]),
          ),
        ),
      );

  Widget _joystick(Size size) {
    return Positioned(
      left: 17,
      bottom: 20,
      child: GestureDetector(
        onPanStart: (d) => setState(() {
          _stickStart = d.localPosition;
          _stick = Offset.zero;
        }),
        onPanUpdate: (d) => setState(() {
          final start = _stickStart ?? const Offset(70, 70);
          var v = d.localPosition - start;
          final len = v.distance;
          if (len > 58) v = v / len * 58;
          _stick = v / 58;
        }),
        onPanEnd: (_) => setState(() {
          _stick = Offset.zero;
          _stickStart = null;
        }),
        onPanCancel: () => setState(() {
          _stick = Offset.zero;
          _stickStart = null;
        }),
        child: SizedBox(
          width: 142,
          height: 142,
          child: Stack(alignment: Alignment.center, children: [
            Container(
              width: 138,
              height: 138,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.black.withOpacity(.54),
                border: Border.all(color: Colors.white.withOpacity(.23), width: 1.5),
                boxShadow: const [BoxShadow(color: Colors.black87, blurRadius: 18, offset: Offset(0, 7))],
              ),
            ),
            Transform.translate(
              offset: _stick * 36,
              child: Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(colors: [Color(0xFF78F4C5), Color(0xFF162127)]),
                  border: Border.all(color: Colors.white.withOpacity(.42), width: 2),
                ),
                child: const Icon(Icons.gamepad_rounded, color: Colors.white70, size: 25),
              ),
            ),
            const Positioned(bottom: 6, child: Text('MOVE', style: TextStyle(color: Colors.white38, fontSize: 7, fontWeight: FontWeight.w900, letterSpacing: 1.2))),
          ]),
        ),
      ),
    );
  }

  Widget _actions(Size size) {
    return Positioned(
      right: 14,
      bottom: 16,
      child: SizedBox(
        width: 300,
        height: 220,
        child: Stack(children: [
          Positioned(right: 0, bottom: 0, child: _actionButton('TEMBAK', Icons.sports_soccer_rounded, 84, const Color(0xFFF1F4F5), () => _actionGame(_game.shoot))),
          Positioned(right: 96, bottom: 48, child: _actionButton('OPER', Icons.compare_arrows_rounded, 69, const Color(0xFF5BE6B0), () => _actionGame(_game.pass))),
          Positioned(right: 0, bottom: 116, child: _hold('LARI', Icons.bolt_rounded, 62)),
          Positioned(right: 104, bottom: 122, child: _actionButton('TEKEL', Icons.shield_rounded, 60, const Color(0xFFFFCA5C), () => _actionGame(_game.tackle))),
          Positioned(right: 184, bottom: 28, child: _actionButton('MAJU', Icons.keyboard_double_arrow_up_rounded, 59, const Color(0xFF74A9FF), () => _actionGame(_game.forward))),
          Positioned(right: 193, bottom: 108, child: _actionButton('GANTI', Icons.swap_horiz_rounded, 53, const Color(0xFFC89BFF), () => _actionGame(_game.switchPlayer))),
        ]),
      ),
    );
  }

  void _actionGame(VoidCallback fn) => _action(fn);

  Widget _hold(String text, IconData icon, double size) => GestureDetector(
        onTapDown: (_) => setState(() => _sprint = true),
        onTapUp: (_) => setState(() => _sprint = false),
        onTapCancel: () => setState(() => _sprint = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _sprint ? const Color(0xFF5CEBB5) : Colors.black.withOpacity(.68),
            border: Border.all(color: const Color(0xFF65F0BB).withOpacity(.8), width: 1.7),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: _sprint ? Colors.black : Colors.white, size: size * .31),
            Text(text, style: TextStyle(color: _sprint ? Colors.black : Colors.white, fontSize: size * .115, fontWeight: FontWeight.w900)),
          ]),
        ),
      );

  Widget _actionButton(String text, IconData icon, double size, Color accent, VoidCallback tap) => GestureDetector(
        onTap: tap,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.black.withOpacity(.68),
            border: Border.all(color: accent.withOpacity(.85), width: 1.7),
            boxShadow: [BoxShadow(color: accent.withOpacity(.12), blurRadius: 16)],
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: Colors.white, size: size * .29),
            const SizedBox(height: 2),
            Text(text, style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: .3)),
          ]),
        ),
      );

  Widget _preMatch(Size s) => Positioned.fill(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black.withOpacity(.10), Colors.black.withOpacity(.82)],
            ),
          ),
          child: Center(
            child: Container(
              width: math.min(720, s.width * .82),
              padding: const EdgeInsets.fromLTRB(24, 22, 24, 20),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.74),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withOpacity(.14)),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('MATCH DAY', style: TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.w900, letterSpacing: 3)),
                const SizedBox(height: 5),
                Text(_game.stadiumName, style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
                const SizedBox(height: 15),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _team('DarkLight FC', const Color(0xFF5CEBB5), Icons.shield_rounded),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 24), child: Text('VS', style: TextStyle(color: Colors.white38, fontSize: 17, fontWeight: FontWeight.w900))),
                  _team('CPU UNITED', const Color(0xFFFF687B), Icons.sports_soccer_rounded),
                ]),
                const SizedBox(height: 17),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _menu('SQUAD', Icons.groups_rounded, _openSquad),
                  const SizedBox(width: 9),
                  _menu('STADIUM', Icons.stadium_rounded, _openStadiums),
                  const SizedBox(width: 9),
                  _menu('KICK OFF', Icons.play_arrow_rounded, _start, filled: true),
                ]),
              ]),
            ),
          ),
        ),
      );

  Widget _team(String name, Color color, IconData icon) => Column(children: [
        Container(width: 60, height: 60, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(.12), border: Border.all(color: color.withOpacity(.58))), child: Icon(icon, color: color, size: 30)),
        const SizedBox(height: 6),
        Text(name, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900)),
      ]);

  Widget _menu(String text, IconData icon, VoidCallback tap, {bool filled = false}) => GestureDetector(
        onTap: tap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(color: filled ? const Color(0xFF5CEBB5) : Colors.white.withOpacity(.07), borderRadius: BorderRadius.circular(11), border: Border.all(color: filled ? Colors.transparent : Colors.white.withOpacity(.14))),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 17, color: filled ? Colors.black : Colors.white),
            const SizedBox(width: 6),
            Text(text, style: TextStyle(color: filled ? Colors.black : Colors.white, fontSize: 8, fontWeight: FontWeight.w900)),
          ]),
        ),
      );
}

class _Stadium {
  final String name;
  final Color accent;
  final Color grass;
  final Color sky;
  final Color stand;
  final bool night;
  const _Stadium(this.name, this.accent, this.grass, this.sky, this.stand, this.night);
}

const _stadiums = <_Stadium>[
  _Stadium('DarkLight NATIONAL', Color(0xFF54EAB0), Color(0xFF176B42), Color(0xFF102631), Color(0xFF26333A), true),
  _Stadium('ROYAL PARK', Color(0xFFFFCF62), Color(0xFF397E39), Color(0xFF78A0B2), Color(0xFF47535A), false),
  _Stadium('NEON NIGHT', Color(0xFF80AAFF), Color(0xFF155D54), Color(0xFF07172A), Color(0xFF18263A), true),
  _Stadium('SUNSET ARENA', Color(0xFFFF815F), Color(0xFF2D7740), Color(0xFF9C614E), Color(0xFF473B3B), false),
];

class _Player {
  final bool home;
  final int number;
  final String name;
  final String role;
  final bool keeper;
  Offset p;
  Offset v = Offset.zero;
  double stamina = 1;
  double phase = 0;
  double facing = -math.pi / 2;
  bool hasBall = false;
  double actionCooldown = 0;

  _Player({required this.home, required this.number, required this.name, required this.role, required this.p, this.keeper = false});
}

class _FootballGame {
  static const double fieldW = 105;
  static const double fieldH = 160;
  final home = <_Player>[];
  final away = <_Player>[];
  int active = 0;
  int stadium = 0;
  int userScore = 0;
  int cpuScore = 0;
  double realTime = 0;
  double matchTime = 0;
  double bannerT = 0;
  double flashT = 0;
  double cameraX = fieldW / 2;
  double cameraY = 118;
  double cameraZoom = 1;
  double tackleLock = 0;
  double ballSpin = 0;
  Offset ball = const Offset(_FootballGame.fieldW / 2, 80.0);
  Offset ballV = Offset.zero;
  Offset input = Offset.zero;
  bool sprint = false;
  String banner = '';

  String get stadiumName => _stadiums[stadium].name;
  int get minute => (matchTime * 1.35).floor().clamp(0, 90);
  String get clockText => '${minute.toString().padLeft(2, '0')}:${((matchTime * 81) % 60).floor().toString().padLeft(2, '0')}';

  _FootballGame() { reset(); }

  void reset() {
    home
      ..clear()
      ..addAll([
        _Player(home: true, number: 9, name: 'DEY', role: 'CF', p: const Offset(52, 105)),
        _Player(home: true, number: 7, name: 'RAJAN', role: 'LW', p: const Offset(28, 91)),
        _Player(home: true, number: 10, name: 'NEKO', role: 'RW', p: const Offset(77, 91)),
        _Player(home: true, number: 8, name: 'KYO', role: 'CM', p: const Offset(39, 112)),
        _Player(home: true, number: 6, name: 'ARES', role: 'CM', p: const Offset(66, 112)),
        _Player(home: true, number: 3, name: 'RIN', role: 'CB', p: const Offset(34, 137)),
        _Player(home: true, number: 2, name: 'KAI', role: 'CB', p: const Offset(70, 137)),
        _Player(home: true, number: 1, name: 'GK', role: 'GK', p: const Offset(52, 153), keeper: true),
      ]);
    away
      ..clear()
      ..addAll([
        _Player(home: false, number: 9, name: 'CPU 9', role: 'CF', p: const Offset(52, 55)),
        _Player(home: false, number: 7, name: 'CPU 7', role: 'LW', p: const Offset(28, 69)),
        _Player(home: false, number: 10, name: 'CPU 10', role: 'RW', p: const Offset(77, 69)),
        _Player(home: false, number: 8, name: 'CPU 8', role: 'CM', p: const Offset(39, 48)),
        _Player(home: false, number: 6, name: 'CPU 6', role: 'CM', p: const Offset(66, 48)),
        _Player(home: false, number: 3, name: 'CPU 3', role: 'CB', p: const Offset(34, 23)),
        _Player(home: false, number: 2, name: 'CPU 2', role: 'CB', p: const Offset(70, 23)),
        _Player(home: false, number: 1, name: 'GK', role: 'GK', p: const Offset(52, 7), keeper: true),
      ]);
    ball = const Offset(52, 80);
    ballV = Offset.zero;
    for (final p in [...home, ...away]) {
      p.hasBall = false;
      p.v = Offset.zero;
      p.stamina = 1;
      p.actionCooldown = 0;
    }
    active = 0;
    home[0].hasBall = true;
    cameraX = 52;
    cameraY = 106;
    cameraZoom = 1;
    userScore = 0;
    cpuScore = 0;
    realTime = 0;
    matchTime = 0;
    banner = 'KICK OFF';
    bannerT = 1.1;
    flashT = 0;
    tackleLock = 0;
  }

  void setInput(Offset value, bool running) {
    input = value;
    sprint = running;
  }

  _Player get user => home[active];
  _Player? get ballOwner {
    for (final p in [...home, ...away]) {
      if (p.hasBall) return p;
    }
    return null;
  }

  void switchPlayer() {
    var best = -1;
    var distance = double.infinity;
    for (var i = 0; i < home.length - 1; i++) {
      final d = (home[i].p - ball).distance;
      if (d < distance) {
        distance = d;
        best = i;
      }
    }
    if (best < 0) return;
    active = best == active ? (active + 1) % (home.length - 1) : best;
    banner = 'PLAYER #${home[active].number}';
    bannerT = .55;
  }

  void pass() {
    final p = user;
    if (!p.hasBall) return;
    _Player? target;
    var best = double.infinity;
    for (var i = 0; i < home.length - 1; i++) {
      if (i == active) continue;
      final q = home[i];
      final d = (q.p - p.p).distance;
      final forward = p.p.dy - q.p.dy;
      final score = d - forward.clamp(-8.0, 12.0) * .10;
      if (score < best) {
        best = score;
        target = q;
      }
    }
    if (target == null) return;
    _releaseBall(p, target.p - p.p, 34, 'OPER');
  }

  void shoot() {
    final p = user;
    if (!p.hasBall) return;
    final target = Offset(fieldW / 2 + (p.p.dx - fieldW / 2) * .22, 2.5);
    _releaseBall(p, target - p.p, sprint ? 67 : 55, sprint ? 'POWER SHOT' : 'TEMBAK');
  }

  void forward() {
    final p = user;
    if (!p.hasBall) return;
    final dir = Offset(math.sin(p.facing), math.cos(p.facing));
    _releaseBall(p, dir, 23, 'MAJU');
  }

  void tackle() {
    final p = user;
    if (tackleLock > 0) return;
    tackleLock = .42;
    _Player? target;
    var dBest = 5.2;
    for (final e in away) {
      final d = (e.p - p.p).distance;
      if (d < dBest && (e.hasBall || (ball - e.p).distance < 3.8)) {
        target = e;
        dBest = d;
      }
    }
    if (target == null) return;
    p.v += (target.p - p.p) / math.max(.001, dBest) * 9;
    if (dBest < 3.5) {
      _clearOwners();
      p.hasBall = true;
      ball = p.p + Offset(math.sin(p.facing), math.cos(p.facing)) * 1.8;
      ballV = Offset.zero;
      banner = 'BALL WON';
      bannerT = .65;
    }
  }

  void _releaseBall(_Player p, Offset raw, double power, String text) {
    if (!p.hasBall || raw.distance < .001) return;
    final dir = raw / raw.distance;
    _clearOwners();
    ball = p.p + dir * 2.0;
    ballV = dir * power;
    p.facing = math.atan2(dir.dx, dir.dy);
    p.stamina = math.max(0, p.stamina - .018).toDouble();
    banner = text;
    bannerT = .55;
  }

  void _clearOwners() {
    for (final p in [...home, ...away]) p.hasBall = false;
  }

  void update(double dt) {
    realTime += dt;
    matchTime = (matchTime + dt * .0111).clamp(0.0, 100.0).toDouble();
    bannerT = math.max(0, bannerT - dt).toDouble();
    flashT = math.max(0, flashT - dt).toDouble();
    tackleLock = math.max(0, tackleLock - dt).toDouble();
    ballSpin += ballV.distance * dt * 4;
    _userUpdate(dt);
    _cpuUpdate(dt);
    _ballUpdate(dt);
    _cameraUpdate(dt);
    _clampPlayers();
  }

  void _userUpdate(double dt) {
    final p = user;
    final len = input.distance.clamp(0.0, 1.0).toDouble();
    if (len > .035) {
      final staminaFactor = .68 + p.stamina * .32;
      final speed = (sprint ? 25.0 : 17.0) * staminaFactor * len;
      final desired = input / len * speed;
      p.v = Offset.lerp(p.v, desired, .22)!;
      p.p += p.v * dt;
      p.facing = math.atan2(p.v.dx, p.v.dy);
      p.phase += dt * (6 + p.v.distance * .22);
      p.stamina = math.max(0, p.stamina - (sprint ? .075 : .018) * dt).toDouble();
    } else {
      p.v *= math.pow(.12, dt).toDouble();
      p.stamina = math.min(1, p.stamina + .045 * dt).toDouble();
      p.phase += dt * 2;
    }
    if (p.hasBall) {
      final dribbleDir = p.v.distance > .5
          ? p.v / p.v.distance
          : Offset(math.sin(p.facing), math.cos(p.facing));
      ball = p.p + dribbleDir * 2.1;
      ballV = p.v * .75;
    } else if ((ball - p.p).distance < 3.2 && ballV.distance < 10) {
      _clearOwners();
      p.hasBall = true;
      banner = 'POSSESSION';
      bannerT = .45;
    }

    final anchors = <Offset>[
      const Offset(52, 105),
      const Offset(28, 91),
      const Offset(77, 91),
      const Offset(39, 112),
      const Offset(66, 112),
      const Offset(34, 137),
      const Offset(70, 137),
    ];
    for (var i = 0; i < home.length - 1; i++) {
      if (i == active) continue;
      final mate = home[i];
      final a = anchors[i];
      final ballInfluence = Offset.lerp(a, Offset(ball.dx, ball.dy.clamp(55.0, 125.0)), .13)!;
      final d = ballInfluence - mate.p;
      if (d.distance > 1.2) {
        final v = d / d.distance * 10;
        mate.v = Offset.lerp(mate.v, v, .055)!;
        mate.p += mate.v * dt;
        mate.facing = math.atan2(mate.v.dx, mate.v.dy);
      } else {
        mate.v *= .8;
      }
      mate.phase += dt * (3.5 + mate.v.distance * .15);
    }
  }

  void _cpuUpdate(double dt) {
    _cpuPossession(dt);
    for (var i = 0; i < away.length; i++) {
      final p = away[i];
      Offset target;
      double speed;
      if (p.hasBall) {
        target = Offset(fieldW / 2 + (p.p.dx - fieldW / 2) * .35, fieldH - 3);
        speed = 13.5;
      } else if (i == 0) {
        target = ball;
        speed = 16.5;
      } else if (i == away.length - 1) {
        target = Offset(fieldW / 2 + (ball.dx - fieldW / 2) * .42, 7);
        speed = 8.2;
      } else {
        final opponent = home[i % (home.length - 1)];
        target = Offset.lerp(opponent.p, ball, .18)!;
        speed = 8.8;
      }
      final d = target - p.p;
      if (d.distance > 1.1) {
        final desired = d / d.distance * speed;
        p.v = Offset.lerp(p.v, desired, .075)!;
        p.p += p.v * dt;
        p.facing = math.atan2(p.v.dx, p.v.dy);
        p.phase += dt * (5 + p.v.distance * .20);
      } else {
        p.v *= .78;
        p.phase += dt * 2.5;
      }
      p.actionCooldown = math.max(0, p.actionCooldown - dt).toDouble();
      if (p.hasBall && (p.p.dy > 122 || (p.p - ball).distance < 1.5)) {
        if (p.p.dy > 105 && p.actionCooldown <= 0) {
          final goal = Offset(fieldW / 2 + (p.p.dx - fieldW / 2) * .18, fieldH + 3);
          final dir = goal - p.p;
          _releaseBall(p, dir, 50, 'CPU SHOT');
          p.actionCooldown = 1.0;
        }
      }
    }

    // CPU press/tackle: nearest opponent actively tries to take possession.
    final owner = ballOwner;
    if (owner != null && owner.home) {
      _Player? chaser;
      var best = double.infinity;
      for (final e in away) {
        if (e.keeper) continue;
        final d = (e.p - owner.p).distance;
        if (d < best) {
          best = d;
          chaser = e;
        }
      }
      if (chaser != null && best < 3.8 && chaser.actionCooldown <= 0) {
        chaser.actionCooldown = .65;
        if (best < 2.25 && owner.v.distance < 18) {
          _clearOwners();
          chaser.hasBall = true;
          ball = chaser.p + Offset(math.sin(chaser.facing), math.cos(chaser.facing)) * 1.8;
          ballV = Offset.zero;
          banner = 'CPU WON BALL';
          bannerT = .65;
        }
      }
    }
  }

  void _cpuPossession(double dt) {
    if (ballOwner != null) return;
    var best = double.infinity;
    _Player? candidate;
    for (final p in away) {
      final d = (p.p - ball).distance;
      if (d < best) {
        best = d;
        candidate = p;
      }
    }
    if (candidate != null && best < 2.5 && ballV.distance < 9) {
      _clearOwners();
      candidate.hasBall = true;
      banner = 'CPU POSSESSION';
      bannerT = .45;
    }
  }

  void _ballUpdate(double dt) {
    if (ballOwner != null) return;
    ball += ballV * dt;
    ballV *= math.pow(.955, dt * 60).toDouble();
    if (ball.dx < 2 || ball.dx > fieldW - 2) {
      ballV = Offset(-ballV.dx * .68, ballV.dy);
      ball = Offset(ball.dx.clamp(2.0, fieldW - 2).toDouble(), ball.dy);
    }
    // Goal is outside the visible pitch at both ends. The net is 14m wide.
    final inMouth = ball.dx > 45.5 && ball.dx < 59.5;
    if (inMouth && ball.dy < -1.5) {
      cpuScore++;
      _goal(false);
    } else if (inMouth && ball.dy > fieldH + 1.5) {
      userScore++;
      _goal(true);
    }
    if (ball.dy < -4 || ball.dy > fieldH + 4) {
      ball = Offset(fieldW / 2, fieldH / 2);
      ballV = Offset.zero;
    }
  }

  void _goal(bool userGoal) {
    _clearOwners();
    flashT = 1.0;
    banner = userGoal ? 'GOOOOOAL!' : 'CPU GOAL';
    bannerT = 1.6;
    ball = const Offset(fieldW / 2, fieldH / 2);
    ballV = Offset.zero;
    home[0].p = const Offset(52, 105);
    away[0].p = const Offset(52, 55);
    home[0].hasBall = userGoal;
    if (!userGoal) away[0].hasBall = true;
  }

  void _cameraUpdate(double dt) {
    final owner = ballOwner;
    final target = owner?.p ?? ball;
    final targetY = target.dy.clamp(30.0, 130.0).toDouble();
    final targetX = target.dx.clamp(30.0, 75.0).toDouble();
    cameraX += (targetX - cameraX) * math.min(1, dt * 4.8);
    cameraY += (targetY - cameraY) * math.min(1, dt * 4.2);
    final speed = ballV.distance;
    final targetZoom = speed > 32 ? .92 : 1.0;
    cameraZoom += (targetZoom - cameraZoom) * math.min(1, dt * 3);
  }

  void _clampPlayers() {
    for (final p in [...home, ...away]) {
      p.p = Offset(p.p.dx.clamp(3.0, fieldW - 3.0).toDouble(), p.p.dy.clamp(2.0, fieldH - 2.0).toDouble());
    }
  }
}

class _FootballPainter extends CustomPainter {
  final _FootballGame game;
  _FootballPainter(this.game);

  @override
  void paint(Canvas c, Size s) {
    _drawStadium(c, s);
    final view = _viewRect(s);
    _drawPitch(c, s, view);
    _drawPlayers(c, s, view, game.away);
    _drawPlayers(c, s, view, game.home);
    _drawBall(c, s, view);
    _drawGoalOverlays(c, s, view);
    if (game.bannerT > 0) _drawBanner(c, s);
    if (game.flashT > 0) {
      c.drawRect(Offset.zero & s, Paint()..color = Colors.white.withOpacity(game.flashT * .10));
    }
  }

  Rect _viewRect(Size s) {
    final top = 46.0;
    final bottom = s.height - 6;
    return Rect.fromLTWH(18, top, s.width - 36, math.max(120, bottom - top));
  }

  Offset _worldToScreen(Rect r, double x, double y) {
    final visibleH = 74 / game.cameraZoom;
    final visibleW = visibleH * r.width / r.height;
    final left = game.cameraX - visibleW / 2;
    final top = game.cameraY - visibleH / 2;
    final nx = (x - left) / visibleW;
    final ny = (y - top) / visibleH;
    return Offset(r.left + nx * r.width, r.top + ny * r.height);
  }

  double _scale(Rect r, double y) {
    final visibleH = 74 / game.cameraZoom;
    final top = game.cameraY - visibleH / 2;
    final n = ((y - top) / visibleH).clamp(0.0, 1.0).toDouble();
    return .72 + n * .42;
  }

  void _drawStadium(Canvas c, Size s) {
    final st = _stadiums[game.stadium];
    final full = Offset.zero & s;
    c.drawRect(full, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [st.sky, st.stand, Colors.black]).createShader(full));

    // Large roof and upper bowl.
    final roof = Path()
      ..moveTo(0, 0)
      ..lineTo(s.width, 0)
      ..lineTo(s.width - 24, 37)
      ..lineTo(24, 37)
      ..close();
    c.drawPath(roof, Paint()..color = Colors.black.withOpacity(.52));

    final rows = Paint();
    for (var row = 0; row < 8; row++) {
      final y = 6 + row * 4.2;
      rows.color = Colors.white.withOpacity(.035 + row * .008);
      c.drawRect(Rect.fromLTWH(0, y, s.width, 3), rows);
    }
    for (var row = 0; row < 7; row++) {
      final y = s.height - 5 - row * 4.5;
      rows.color = Colors.white.withOpacity(.035 + row * .008);
      c.drawRect(Rect.fromLTWH(0, y, s.width, 3), rows);
    }

    // Dense spectators: head + body, varied scale and animation.
    for (var row = 0; row < 8; row++) {
      for (var i = 0; i < 120; i++) {
        final x = (i + .35) * s.width / 120;
        final bob = math.sin(game.realTime * (1.2 + (i % 4) * .18) + row * .8 + i * .37) * .8;
        final y = 7 + row * 4.2 + bob;
        _spectator(c, Offset(x, y), 1.0 + ((i + row) % 3) * .13, i, row, st.accent);
      }
    }
    for (var row = 0; row < 7; row++) {
      for (var i = 0; i < 120; i++) {
        final x = (i + .35) * s.width / 120;
        final bob = math.sin(game.realTime * 1.45 + row + i * .27) * .7;
        final y = s.height - 7 - row * 4.5 + bob;
        _spectator(c, Offset(x, y), .95 + ((i + row) % 4) * .12, i + 17, row, st.accent);
      }
    }

    // Side stands to make the stadium feel continuous around the pitch.
    final side = Paint()..color = Colors.black.withOpacity(.36);
    c.drawRect(Rect.fromLTWH(0, 39, 12, s.height - 78), side);
    c.drawRect(Rect.fromLTWH(s.width - 12, 39, 12, s.height - 78), side);

    // LED advertising boards.
    final led = Paint()..color = st.accent.withOpacity(.62);
    c.drawRect(Rect.fromLTWH(13, 39, s.width - 26, 4), led);
    c.drawRect(Rect.fromLTWH(13, s.height - 9, s.width - 26, 4), led);
    for (var i = 0; i < 18; i++) {
      final x = 20 + i * (s.width - 40) / 18;
      c.drawRect(Rect.fromLTWH(x, 39, 20, 1), Paint()..color = Colors.white.withOpacity(.25));
      c.drawRect(Rect.fromLTWH(x, s.height - 8, 20, 1), Paint()..color = Colors.white.withOpacity(.22));
    }

    // Floodlights.
    for (final x in [s.width * .07, s.width * .93]) {
      c.drawRect(Rect.fromLTWH(x - 1.5, 4, 3, 35), Paint()..color = Colors.white.withOpacity(.18));
      for (var j = 0; j < 8; j++) {
        c.drawCircle(Offset(x - 13 + j * 4, 7), 1.5, Paint()..color = Colors.white.withOpacity(.72));
      }
      final beam = Path()
        ..moveTo(x - 6, 12)
        ..lineTo(x + 6, 12)
        ..lineTo(x + (x < s.width / 2 ? 130 : -130), s.height * .65)
        ..lineTo(x + (x < s.width / 2 ? -130 : 130), s.height * .65)
        ..close();
      c.drawPath(beam, Paint()..shader = LinearGradient(colors: [Colors.white.withOpacity(.045), Colors.transparent]).createShader(beam.getBounds()));
    }
  }

  void _spectator(Canvas c, Offset p, double scale, int i, int row, Color accent) {
    final lit = (i * 7 + row * 3) % 13 == 0;
    final body = Paint()..color = lit ? accent.withOpacity(.72) : Colors.white.withOpacity(.13 + (i % 3) * .018);
    c.drawCircle(p, 1.15 * scale, body);
    c.drawOval(Rect.fromCenter(center: p + Offset(0, 2.0 * scale), width: 3.0 * scale, height: 3.8 * scale), body);
  }

  void _drawPitch(Canvas c, Size s, Rect r) {
    final st = _stadiums[game.stadium];
    c.drawRect(r, Paint()..color = st.grass);
    final visibleH = 74 / game.cameraZoom;
    final left = game.cameraX - (visibleH * r.width / r.height) / 2;
    final top = game.cameraY - visibleH / 2;
    final right = game.cameraX + (visibleH * r.width / r.height) / 2;
    final bottom = game.cameraY + visibleH / 2;

    // Mowing stripes.
    for (var y = (top / 8).floor() * 8; y <= bottom + 8; y += 8) {
      final yy = _worldToScreen(r, 0.0, y.toDouble()).dy;
      if (yy < r.top - 20 || yy > r.bottom + 20) continue;
      final band = Paint()..color = ((y / 8).round().isEven ? Colors.white : Colors.black).withOpacity(.028);
      c.drawRect(Rect.fromLTWH(r.left, yy, r.width, 8 * r.height / visibleH), band);
    }

    final line = Paint()..color = Colors.white.withOpacity(.72)..style = PaintingStyle.stroke..strokeWidth = 1.7;
    void lineWorld(Offset a, Offset b) {
      final aa = _worldToScreen(r, a.dx, a.dy);
      final bb = _worldToScreen(r, b.dx, b.dy);
      c.drawLine(aa, bb, line);
    }
    void rectWorld(double l, double t, double w, double h) {
      final a = _worldToScreen(r, l, t);
      final b = _worldToScreen(r, l + w, t + h);
      c.drawRect(Rect.fromLTRB(a.dx, a.dy, b.dx, b.dy), line);
    }

    lineWorld(const Offset(0.0, 0.0), Offset(_FootballGame.fieldW, 0.0));
    lineWorld(Offset(0.0, _FootballGame.fieldH), Offset(_FootballGame.fieldW, _FootballGame.fieldH));
    lineWorld(const Offset(0.0, 0.0), Offset(0.0, _FootballGame.fieldH));
    lineWorld(Offset(_FootballGame.fieldW, 0.0), Offset(_FootballGame.fieldW, _FootballGame.fieldH));
    lineWorld(const Offset(0.0, 80.0), Offset(_FootballGame.fieldW, 80.0));

    final center = _worldToScreen(r, _FootballGame.fieldW / 2, 80.0);
    final radius = (13.5 / visibleH * r.height).abs();
    c.drawCircle(center, radius, line);
    c.drawCircle(center, 2.2, Paint()..color = Colors.white);

    rectWorld(0.0, 0.0, _FootballGame.fieldW, 21.0);
    rectWorld(0.0, _FootballGame.fieldH - 21.0, _FootballGame.fieldW, 21.0);
    rectWorld(0.0, 0.0, _FootballGame.fieldW, 8.0);
    rectWorld(0.0, _FootballGame.fieldH - 8.0, _FootballGame.fieldW, 8.0);

    final spotTop = _worldToScreen(r, _FootballGame.fieldW / 2, 11.0);
    final spotBottom = _worldToScreen(r, _FootballGame.fieldW / 2, _FootballGame.fieldH - 11.0);
    c.drawCircle(spotTop, 2, Paint()..color = Colors.white);
    c.drawCircle(spotBottom, 2, Paint()..color = Colors.white);

    // Penalty arcs.
    final arcR = (13.5 / visibleH * r.height);
    final topCenter = _worldToScreen(r, _FootballGame.fieldW / 2, 21.0);
    final bottomCenter = _worldToScreen(r, _FootballGame.fieldW / 2, _FootballGame.fieldH - 21.0);
    c.drawArc(Rect.fromCircle(center: topCenter, radius: arcR), .22, math.pi - .44, false, line);
    c.drawArc(Rect.fromCircle(center: bottomCenter, radius: arcR), math.pi + .22, math.pi - .44, false, line);

    // Touchline shadows for depth.
    c.drawRect(r, Paint()..color = Colors.black.withOpacity(.10)..style = PaintingStyle.stroke..strokeWidth = 8);
    if (left < 0 || right > _FootballGame.fieldW) {
      // Nothing: the camera intentionally crops the long pitch like a mobile broadcast camera.
    }
  }

  void _drawPlayers(Canvas c, Size s, Rect r, List<_Player> players) {
    final ordered = [...players]..sort((a, b) => a.p.dy.compareTo(b.p.dy));
    for (final p in ordered) {
      final pos = _worldToScreen(r, p.p.dx, p.p.dy);
      if (pos.dx < -50 || pos.dx > s.width + 50 || pos.dy < 35 || pos.dy > s.height + 40) continue;
      final scale = _scale(r, p.p.dy);
      final active = p.home && game.home[game.active] == p;
      final body = p.home ? const Color(0xFF52E8B0) : const Color(0xFFFF667B);
      final dark = p.home ? const Color(0xFF0A4B38) : const Color(0xFF641D2B);
      final bob = math.sin(p.phase) * 1.5 * scale;

      c.drawOval(Rect.fromCenter(center: Offset(pos.dx, pos.dy + 15 * scale), width: 24 * scale, height: 7 * scale), Paint()..color = Colors.black.withOpacity(.42));
      if (active) {
        c.drawCircle(pos, 21 * scale, Paint()..color = const Color(0xFF9BFFDE).withOpacity(.09));
        c.drawArc(Rect.fromCircle(center: pos, radius: 19 * scale), game.realTime * 2, math.pi * 1.55, false, Paint()..color = const Color(0xFF9BFFDE).withOpacity(.88)..style = PaintingStyle.stroke..strokeWidth = 2);
      }
      if (p.hasBall) {
        c.drawCircle(Offset(pos.dx, pos.dy + 8), 13 * scale, Paint()..color = Colors.white.withOpacity(.09));
      }

      final stride = math.sin(p.phase) * 5.0 * scale;
      final limb = Paint()..color = dark..strokeWidth = 4.5 * scale..strokeCap = StrokeCap.round;
      c.drawLine(Offset(pos.dx - 4 * scale, pos.dy + 7 * scale + bob), Offset(pos.dx - 6 * scale - stride, pos.dy + 18 * scale + bob), limb);
      c.drawLine(Offset(pos.dx + 4 * scale, pos.dy + 7 * scale + bob), Offset(pos.dx + 6 * scale + stride, pos.dy + 18 * scale + bob), limb);

      c.save();
      c.translate(pos.dx, pos.dy + bob);
      c.rotate(p.facing);
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(-9 * scale, -9 * scale, 18 * scale, 21 * scale), Radius.circular(5 * scale)), Paint()..color = body);
      c.drawRect(Rect.fromLTWH(-10 * scale, -2 * scale, 20 * scale, 4 * scale), Paint()..color = dark.withOpacity(.75));
      c.drawLine(Offset(-9 * scale, 0), Offset(-14 * scale, 8 * scale), limb);
      c.drawLine(Offset(9 * scale, 0), Offset(14 * scale, 8 * scale), limb);
      c.drawCircle(Offset(0, -14 * scale), 5.5 * scale, Paint()..color = const Color(0xFFF0C7A7));
      c.drawArc(Rect.fromLTWH(-5 * scale, -19 * scale, 10 * scale, 7 * scale), math.pi, math.pi, false, Paint()..color = Colors.black.withOpacity(.62)..style = PaintingStyle.stroke..strokeWidth = 2.2 * scale);
      c.restore();

      final tp = TextPainter(
        text: TextSpan(text: '${p.number}', style: TextStyle(color: Colors.white, fontSize: 7.5 * scale, fontWeight: FontWeight.w900)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(c, Offset(pos.dx - tp.width / 2, pos.dy - 3 * scale));
    }
  }

  void _drawBall(Canvas c, Size s, Rect r) {
    final pos = _worldToScreen(r, game.ball.dx, game.ball.dy);
    if (pos.dx < -30 || pos.dx > s.width + 30 || pos.dy < 25 || pos.dy > s.height + 30) return;
    final scale = _scale(r, game.ball.dy);
    final radius = 5.6 * scale;
    if (game.ballV.distance > 12) {
      final d = game.ballV / game.ballV.distance;
      for (var i = 5; i >= 1; i--) {
        c.drawCircle(pos - d * (i * 4), radius * (.25 + .11 * (5 - i)), Paint()..color = Colors.white.withOpacity(.035));
      }
    }
    c.drawOval(Rect.fromCenter(center: pos + Offset(2, 4 * scale), width: radius * 2.5, height: radius * .75), Paint()..color = Colors.black.withOpacity(.38));
    c.drawCircle(pos, radius, Paint()..shader = RadialGradient(center: const Alignment(-.35, -.4), colors: const [Colors.white, Color(0xFFD7DDE0), Color(0xFF858E92)]).createShader(Rect.fromCircle(center: pos, radius: radius)));
    final seam = Paint()..color = Colors.black.withOpacity(.28)..style = PaintingStyle.stroke..strokeWidth = .65 * scale;
    c.drawArc(Rect.fromCircle(center: pos, radius: radius * .58), game.ballSpin, 3.4, false, seam);
    c.drawCircle(pos, radius, Paint()..color = Colors.white.withOpacity(.72)..style = PaintingStyle.stroke..strokeWidth = .55 * scale);
  }

  void _drawGoalOverlays(Canvas c, Size s, Rect r) {
    // Only draw a goal when the camera is near that end; this prevents the old bug where both goals sit inside the pitch.
    final visibleH = 74 / game.cameraZoom;
    final top = game.cameraY - visibleH / 2;
    final bottom = game.cameraY + visibleH / 2;
    if (top < 12) _goal(c, r, true);
    if (bottom > _FootballGame.fieldH - 12) _goal(c, r, false);
  }

  void _goal(Canvas c, Rect r, bool top) {
    final yWorld = top ? 0.0 : _FootballGame.fieldH;
    final center = _worldToScreen(r, _FootballGame.fieldW / 2, yWorld);
    final width = (14 / (74 / game.cameraZoom) * r.height).toDouble();
    final depth = (6 / (74 / game.cameraZoom) * r.height).toDouble();
    final x = center.dx - width / 2;
    final y = center.dy + (top ? -depth : 0);
    final rect = Rect.fromLTWH(x, y, width, depth);
    final paint = Paint()..color = Colors.white.withOpacity(.90)..style = PaintingStyle.stroke..strokeWidth = 2.4;
    c.drawRect(rect, paint);
    for (var i = 1; i < 8; i++) {
      final xx = x + width * i / 8.0;
      c.drawLine(Offset(xx, rect.top), Offset(xx, rect.bottom), Paint()..color = Colors.white.withOpacity(.13));
    }
    for (var i = 1; i < 4; i++) {
      final yy = rect.top + rect.height * i / 4.0;
      c.drawLine(Offset(rect.left, yy), Offset(rect.right, yy), Paint()..color = Colors.white.withOpacity(.10));
    }
    final post = Paint()..color = Colors.white.withOpacity(.92)..strokeWidth = 3.2;
    c.drawLine(Offset(x, top ? rect.bottom : rect.top), Offset(x, top ? rect.top : rect.bottom), post);
    c.drawLine(Offset(x + width, top ? rect.bottom : rect.top), Offset(x + width, top ? rect.top : rect.bottom), post);
  }

  void _drawBanner(Canvas c, Size s) {
    final opacity = game.bannerT.clamp(0.0, 1.0).toDouble();
    final goal = game.banner.contains('GOAL');
    final tp = TextPainter(
      text: TextSpan(text: game.banner, style: TextStyle(color: Colors.white.withOpacity(opacity), fontSize: goal ? 34 : 20, fontWeight: FontWeight.w900, letterSpacing: goal ? 2.4 : 1.5)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(c, Offset(s.width / 2 - tp.width / 2, s.height * (goal ? .39 : .46)));
  }

  @override
  bool shouldRepaint(covariant _FootballPainter oldDelegate) => true;
}
