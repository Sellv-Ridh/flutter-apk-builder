# ───────────────────────────────────────────────────────────────────────
# Paksa semua class awesome_notifications (termasuk BroadcastReceiver-nya)
# masuk ke classes.dex UTAMA, bukan dex sekunder.
#
# Kenapa perlu: ScheduledNotificationReceiver di-trigger oleh OS lewat
# BOOT_COMPLETED, yang bisa menjalankan proses app dari kondisi benar-benar
# mati (cold start khusus broadcast, tanpa Application.onCreate() jalan
# dulu). Kalau class receiver itu kebetulan ada di dex sekunder, Android
# bisa gagal menemukannya di titik waktu itu → ClassNotFoundException.
# Mengunci ke dex utama menghilangkan race condition ini sepenuhnya.
# ───────────────────────────────────────────────────────────────────────
-keep class me.carda.awesome_notifications.** { *; }
