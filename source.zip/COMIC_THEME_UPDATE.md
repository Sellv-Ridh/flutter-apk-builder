# 3D Comic Theme Update

Perubahan utama:
- Menambahkan mode visual `CLASSIC` dan `3D COMIC`.
- Mode 3D Comic tersimpan per akun melalui SharedPreferences dan API theme yang sudah ada.
- Preset warna tetap bisa dipilih; custom HEX/HSL/gradient tetap tersedia.
- ThemeData global berubah ke paper/cream + ink black + red/yellow accent saat Comic aktif.
- Login dan splash mengikuti mode Comic.
- Dashboard bottom navigation menjadi 5 tab dan tab `Theme` membuka pengaturan tema.
- Menambahkan dekorasi paper/halftone comic global tanpa menghalangi interaksi.

File utama:
- `lib/theme_provider.dart`
- `lib/theme_settings_page.dart`
- `lib/main.dart`
- `lib/comic_theme.dart`
- `lib/login_page.dart`
- `lib/splash.dart`
- `lib/landing.dart`
- `lib/dashboard_page.dart`

Catatan:
Mode global akan mempengaruhi widget Material dan halaman yang memakai ThemeProvider/ThemeData. Halaman lama yang masih memiliki warna hardcoded khusus dapat memerlukan penyesuaian manual tambahan jika ingin 100% identik dengan mockup comic.
